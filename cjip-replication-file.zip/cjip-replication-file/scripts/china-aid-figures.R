#------------------------------------------------------------
# Data generation for:
# "Political Turnover and Chinese Development Cooperation"
# Forthcoming in The Chinese Journal of International Politics
# 07-31-2017
# Matthew DiLorenzo and Mengfan Cheng
#------------------------------------------------------------


library(rvest)
library(foreign)
library(tidyverse)
library(countrycode)
library(WDI)
library(readstata13)
library(readxl)
library(foreach)
library(countrycode)
library(ggthemes)


#--------------------------------------------------------------
# Load Chinese aid data
#--------------------------------------------------------------
setwd("~/Dropbox/working-papers/china-aid-turnover/data/")

china <- read_xlsx("~/Dropbox/Data/AidData/china-global/ChineseGlobalOfficialFinance_ResearchRelease_v1.0.xlsx",
                   sheet = 4)


## Filter, summarise
china <- china %>%
  filter(flow_class %in% c("OOF-like", 
                           "ODA-like") & !year_uncertain) %>%
  filter(recipient_count == 1) %>% ## Remove cases with multiple recipients
  filter(!status %in% c("Suspended", "Cancelled")) %>%
  group_by(recipient_iso3, year) %>%
  summarise(
    china_total_finance = sum(usd_defl_2014, na.rm = T),
    china_aid_usd_defl_2014_total = sum(usd_defl_2014[flow_class == "ODA-like"], 
                                        na.rm = T),
    china_oof_usd_defl_2014_total = sum(usd_defl_2014[
      flow_class %in% c("OOF-like", "Vague (Official Finance)")], 
      na.rm = T),
    n_chinese_projects = length(unique(project_id)),
    n_chinese_oda_projects = length(
      unique(project_id[flow_class == "ODA-like"])
    ),
    n_chinese_oof_projects = length(
      unique(project_id[flow_class %in% c("OOF-like",
                                          "Vague (Official Finance)")])
    ),
    n_chinese_grants = length(
      unique(project_id[flow == "Grant"])
    ),
    n_chinese_loans = length(
      unique(project_id[flow == "Loan (excluding debt rescheduling)"])
    ),
    china_budget_support = sum(usd_defl_2014[crs_sector_code == 510],
                               na.rm = T),
    china_grants = sum(usd_defl_2014[flow == "Grant"], na.rm = T),
    china_loans = sum(
      usd_defl_2014[flow == "Loan (excluding debt rescheduling)"],
      na.rm = T)) %>%
  filter(!recipient_iso3 == "") %>%
  rename(iso3c = recipient_iso3) %>%
  filter(!grepl("regional", iso3c))





#-------------------------------------------------------------------------
# Figure 1: Total amounts / share by year
#-------------------------------------------------------------------------

writeLines(names(china))

type_year <- china %>%
  group_by(year) %>%
  summarise_at(vars(china_aid_usd_defl_2014_total,
                    china_oof_usd_defl_2014_total,
                    china_grants,
                    china_loans),
               funs(sum(., na.rm = T))) %>%
  gather(key = "type",
         value = "amount",
         -year) %>%
  mutate(`Flow type` = recode(type,
                              china_aid_usd_defl_2014_total = "ODA-like",
                              china_oof_usd_defl_2014_total = "OOF-like",
                              china_grants = "Grants",
                              china_loans = "Loans"))


ggplot(type_year %>% filter(`Flow type` %in% c("ODA-like", "OOF-like")),
       aes(x = factor(year),
           y = amount / 10^9,
           group = `Flow type`,
           fill = `Flow type`)) +
  geom_bar(stat = "identity") +
  scale_fill_manual(values = c("gray25", "gray65")) +
  labs(x = "\nYear",
       y = "Finance (2014 constant US$, billions)",
       title = "ODA-like and OOF-like flows") +
  theme_aiddata_plain()
  
ggsave("~/Dropbox/working-papers/china-aid-turnover/figures/oda-vs-oof-2000-2014.jpeg",
       scale = 1.15)


ggplot(type_year %>% filter(`Flow type` %in% c("Grants", "Loans")),
       aes(x = factor(year),
           y = amount / 10^9,
           group = `Flow type`,
           fill = `Flow type`)) +
  geom_bar(stat = "identity") +
  scale_fill_manual(values = c("gray25", "gray65")) +
  labs(x = "\nYear",
       y = "Finance (2014 constant US$, billions)",
       title = "Grants and loans") +
  theme_aiddata_plain()

ggsave("~/Dropbox/working-papers/china-aid-turnover/figures/grants-vs-loans-2000-2014.jpeg",
       scale = 1.15)











#------------------------------------------------------------------------------
# Maps
#------------------------------------------------------------------------------


## Get map data for whole world
world_data <- map_data("world")
world_data <- world_data[world_data$region != "Antarctica",] # Remove Antarctica

## Add country names and codes for consistency
world_data$country <- countrycode(world_data$region, "country.name", "country.name", warn = T)
world_data$iso3c <- countrycode(world_data$country, "country.name", "iso3c", warn = T)

## China country_level
china_country_level <- china %>%
  group_by(iso3c) %>%
  summarise_all(funs(sum(., na.rm = T)))

world <- left_join(world_data, china_country_level, by = "iso3c")

## Replace missing values with zero so they show up white on the map
world[is.na(world)] <- 0

#----------------------------------------------------------------------
# Global maps of Chinese ODA and OOF, 2000-2015
#----------------------------------------------------------------------


ggplot() +
  geom_map(data = world, map = world, 
           aes(map_id = region, x = long, y = lat, 
               fill = log(china_aid_usd_defl_2014_total + 1))) +
  borders(colour = "black", size = .25) +
  theme_bw() +
  theme(plot.title = element_text(lineheight=.8, face = "bold"),
        plot.margin = unit(c(0, 0, 0, 0), "cm"),
        panel.border = element_blank(), 
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        axis.ticks = element_blank(),
        axis.text.y = element_blank(),
        axis.text.x = element_blank(),
        axis.line = element_line(colour = "black")) +
  scale_fill_gradient(low = "white", high = "dodgerblue4", 
                      guide = "colourbar",
                      name = "log(Chinese ODA-like flows + 1)") +
  coord_equal() +
  ggtitle("Chinese ODA-like flows, 2000-2014") +
  annotate("text", x = -140, y = -50, 
           label = "Source: Dreher et al. (2017a).",
           cex = 2.55) 

getwd()
ggsave("../figures/oda-map.jpeg")


ggplot() +
  geom_map(data = world, map = world, 
           aes(map_id = region, x = long, y = lat, 
               fill = log(china_oof_usd_defl_2014_total + 1))) +
  borders(colour = "black", size = .25) +
  theme_bw() +
  theme(plot.title = element_text(lineheight=.8, face = "bold"),
        plot.margin = unit(c(0, 0, 0, 0), "cm"),
        panel.border = element_blank(), 
        panel.grid.major = element_blank(),
        panel.grid.minor = element_blank(),
        axis.title.x = element_blank(),
        axis.title.y = element_blank(),
        axis.ticks = element_blank(),
        axis.text.y = element_blank(),
        axis.text.x = element_blank(),
        axis.line = element_line(colour = "black")) +
  scale_fill_gradient(low = "white", high = "dodgerblue4", 
                      guide = "colourbar",
                      name = "log(Chinese OOF-like flows + 1)") +
  coord_equal() +
  ggtitle("Chinese OOF-like flows, 2000-2014") +
  annotate("text", x = -140, y = -50, 
           label = "Source: Dreher et al. 2017a.",
           cex = 2.55) 

ggsave("../figures/oof-map.jpeg")



