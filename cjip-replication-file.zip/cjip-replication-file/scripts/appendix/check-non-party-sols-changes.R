## Reload CHISOLS
chisols_lead <- read.csv("~/Dropbox/Data/CHISOLS/Final/chisolsll4_0/CHISOLSll4_0.csv")

## Quick check to see how 
non_party <- chisols_lead %>%
  group_by(statename) %>%
  arrange(begyr, begmo, begday) %>%
  mutate(affiliation_lag = lag(affiliation, 1)) %>%
  arrange(statename, begyr, begmo, begday) %>%
  filter(affiliation == "Non-party" & affiliation_lag == "Non-party")

sum(non_party$solschange, na.rm = T)
mean(non_party$solschange, na.rm = T)


  