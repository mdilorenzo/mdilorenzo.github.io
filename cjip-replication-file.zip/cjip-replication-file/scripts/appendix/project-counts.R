#------------------------------------------------------------
# Count models for appendix of:
# "Political Turnover and Chinese Development Cooperation"
# 03-29-2018
# Matthew DiLorenzo and Mengfan Cheng
#------------------------------------------------------------


library(tidyverse)
library(MASS)
library(sandwich)
library(lmtest)
library(stargazer)
library(plm)
source("~/Dropbox/r/basic-custom-functions.R")

setwd("~/Dropbox/working-papers/china-aid-turnover/data/")

dat <- read.csv("china-aid-turnover-data.csv",
                stringsAsFactors = FALSE)

## For table output
dat <- dat %>%
  rename(election = election_year)

dat <- dat %>%
  mutate(civil_conflicts = ifelse(civil_conflicts > 0, 1, 0))

## Make panel data frame
pdat <- pdata.frame(dat %>% arrange(iso3c, year),
                    index = c("iso3c", "year"))

#-------------------------------------------------------
# Regression table 1
#-------------------------------------------------------

hist(log(pdat$n_chinese_projects + 1))

m1 <- plm(I(log(n_chinese_projects + 1)) ~ 
            sols_change_dummy +
            other_leader_trans +
            regtrans_alt +
            civil_conflicts +
            dem +
            ln_gdp +
            n_disasters +
            taiwan_recognition +
            ln_china_total_finance_t1,
          data = pdat,
          method = "within",
          effect = "twoways")

m2 <- update(m1,
             I(log(n_chinese_oda_projects + 1)) ~ .)

m3 <- update(m1,
             I(log(n_chinese_oof_projects + 1)) ~ .)

m4 <- update(m1,
             I(log(n_chinese_grants + 1)) ~ .)

m5 <- update(m1,
             I(log(n_chinese_loans + 1)) ~ .)


## Collect the five model objects in a list
china_models_amt <- list(m1, m2, m3, m4, m5)

## Get country-clustered estimated standard errors
china_clust_ses_amt <- lapply(china_models_amt,
                              function(x) 
                                sqrt(
                                  diag(
                                    vcovHC(x, 
                                           method = "arellano",
                                           type = "HC1")
                                  )
                                )
)


## Get number of countries for table output
china_countries_n <- sapply(china_models_amt,
                            function(x)
                              pdim(x)$nT$n)


china_dv_labels <- c("All finance",
                     "ODA-like",
                     "OOF-like",
                     "Grants",
                     "Loans")

covariates <- c("SOLS change",
                "Other leader change",
                "Regime change",
                "Civil conflict",
                "Democracy",
                #"US ally",
                "GDP (log)",
                "Natural disasters",
                "Taiwan recognition")


setwd("~/Dropbox/working-papers/china-aid-turnover/tables/appendix/")
sink("china-count-models-table-1.tex")
stargazer(china_models_amt,
          se = china_clust_ses_amt,
          dep.var.labels = china_dv_labels,
          covariate.labels = covariates,
          label = "appx-count-models",
          title = "Domestic changes and Chinese projects, 2000-2014 (Logged count of projects in outcome)",
          omit = c("year", "continent", "iso3c", "_t1"),
          p.auto = TRUE,
          t.auto = TRUE,
          digits = 3,
          column.sep.width = c("0pt"),
          notes.append = TRUE,
          notes.align = "l",
          notes.label = "",
          #single.row = TRUE,
          keep.stat = c("n", "f", "rsq"),
          add.lines = list(c("N. countries", china_countries_n)),
          font.size = "footnotesize",
          notes = c(
            "Two-tailed tests. Estimated standard errors clustered by recipient in parentheses.", 
            "Country- and year-fixed effects, lagged outcome (one-year) included in all models."),
          #float.env = "sidewaystable",
          model.names = FALSE,
          model.numbers = TRUE,
          no.space = TRUE,
          df = FALSE)
sink()

