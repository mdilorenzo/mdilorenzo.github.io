#------------------------------------------------------------
# Statistical models for:
# "Political Turnover and Chinese Development Cooperation"
# 07-18-2017
# Matthew DiLorenzo and Mengfan Cheng
#------------------------------------------------------------


library(tidyverse)
library(MASS)
library(sandwich)
library(lmtest)
library(stargazer)
source("~/Dropbox/r/basic-custom-functions.R")

setwd("~/Dropbox/working-papers/china-aid-turnover/data/")

dat <- read.csv("china-aid-turnover-data.csv",
                stringsAsFactors = FALSE)

## For table output
dat <- dat %>%
  rename(election = election_year)

dat <- dat %>%
  mutate(civil_conflicts = ifelse(civil_conflicts > 0, 1, 0))


#-------------------------------------------------------
# Table of summary statistics
#-------------------------------------------------------

summary_data <- dat %>%
  dplyr::select(sols_change_dummy,
                other_leader_trans,
                regtrans_alt,
                civil_conflicts,
                dem,
                us_ally,
                ln_gdp,
                n_disasters,
                taiwan_recognition,
                china_s2un_t1)

var_labels <- c("CHISOLS",
                "Lead. change",
                "Reg. change",
                "Civil war",
                "Dem.",
                "US ally",
                "GDP (log)",
                "Disasters",
                "Taiwan rec.",
                "China voting")

cor_matrix <- cor(summary_data, use = "pairwise.complete.obs")
rownames(cor_matrix) <- var_labels
colnames(cor_matrix) <- var_labels


# cor_matrix[col(cor_matrix) == row(cor_matrix) | upper.tri(cor_matrix)] <- NA 
# cor_matrix <- cor_matrix[-1, -ncol(cor_matrix)]

sink("~/Dropbox/working-papers/china-aid-turnover/tables/appendix/correlation-matrix.tex")
stargazer(cor_matrix,
          label = "correlation-matrix",
          title = "Correlation matrix for key independent variables",
          font.size = "scriptsize",
          column.sep.width = c("0pt"))
sink()


