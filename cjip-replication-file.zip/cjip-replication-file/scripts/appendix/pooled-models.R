#------------------------------------------------------------
# Pooled regression models
# "Political Turnover and Chinese Development Cooperation"
# 04-02-2018
# Matthew DiLorenzo and Mengfan Cheng
#------------------------------------------------------------

library(tidyverse)
library(MASS)
library(sandwich)
library(lmtest)
library(stargazer)
library(plm)

source("~/Dropbox/r/basic-custom-functions.R")

setwd("~/Dropbox/working-papers/china-aid-turnover/data/")

dat <- read.csv("china-aid-turnover-data.csv",
                stringsAsFactors = FALSE)

## For table output
dat <- dat %>%
  rename(election = election_year)

dat <- dat %>%
  mutate(civil_conflicts = ifelse(civil_conflicts > 0, 1, 0))


test <- dat %>%
  group_by(statename) %>%
  summarise(n_change = mean(taiwan_recognition, na.rm = T))




#-------------------------------------------------------
# Regression table 1
#-------------------------------------------------------

## Make panel data frame
pdat <- pdata.frame(dat %>% arrange(iso3c, year),
                    index = c("iso3c", "year"))

m1 <- plm(ln_china_total_finance ~ 
            sols_change_dummy +
            other_leader_trans +
            regtrans_alt +
            civil_conflicts +
            dem +
            ln_gdp +
            n_disasters +
            taiwan_recognition +
            ln_china_total_finance_t1,
          data = pdat,
          method = "pooling")

m2 <- update(m1,
             ln_china_oda ~ . - ln_china_total_finance_t1 + 
               ln_china_oda_t1)

m3 <- update(m1,
             ln_china_oof ~ . - ln_china_total_finance_t1 + 
               ln_china_oof_t1)

m4 <- update(m1,
             ln_china_grants ~ . - ln_china_total_finance_t1 + 
               ln_china_grants_t1)

m5 <- update(m1,
             ln_china_loans ~ . - ln_china_total_finance_t1 + 
               ln_china_loans_t1)

## Collect the five model objects in a list
china_models_amt <- list(m1, m2, m3, m4, m5)


## Get country-clustered estimated standard errors
china_clust_ses_amt <- lapply(china_models_amt,
                              function(x) 
                                sqrt(
                                  diag(
                                    vcovHC(x, 
                                           method = "arellano",
                                           type = "HC1")
                                  )
                                )
)


## Get number of countries for table output
china_countries_n <- sapply(china_models_amt,
                            function(x)
                              pdim(x)$nT$n)

## Prepare a table in LaTeX 
china_dv_labels <- c("All finance (log)",
                     "ODA-like (log)",
                     "OOF-like (log)",
                     "Grants (log)",
                     "Loans (log)")

covariates <- c("SOLS change",
                "Other leader change",
                "Regime change",
                "Civil conflict",
                "Democracy",
                #"US ally",
                "GDP (log)",
                "Natural disasters",
                "Taiwan recognition")

setwd("~/Dropbox/working-papers/china-aid-turnover/tables/appendix/")

stargazer(china_models_amt,
          se = china_clust_ses_amt,
          dep.var.labels = china_dv_labels,
          covariate.labels = covariates,
          label = "china-pooled-models",
          title = "Domestic changes and Chinese finance, 2000-2014",
          omit = c("year", "continent", "iso3c", "_t1"),
          p.auto = TRUE,
          t.auto = TRUE,
          digits = 3,
          column.sep.width = c("0pt"),
          notes.append = TRUE,
          notes.align = "l",
          notes.label = "",
          keep.stat = c("n", "f", "rsq"),
          add.lines = list(c("N. countries", china_countries_n)),
          font.size = "footnotesize",
          notes = c(
            "Two-tailed tests. Estimated standard errors clustered by recipient in parentheses."),
          model.names = FALSE,
          model.numbers = TRUE,
          no.space = TRUE,
          out = "china-pooled-table-1.tex",
          df = FALSE)


