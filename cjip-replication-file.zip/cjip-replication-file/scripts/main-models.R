#------------------------------------------------------------
# Statistical models for:
# "Political Turnover and Chinese Development Cooperation"
# Forthcoming in The Chinese Journal of International Politics
# 12-12-2018
# Matthew DiLorenzo (ODU) and Mengfan Cheng (AidData/William & Mary)
#------------------------------------------------------------

## This script reproduces the statistical tables and figures for the article. For the code to reproduce Figure 1 and the maps in the appendix, see "china-aid-figures.R"

library(tidyverse)
library(MASS)
library(sandwich)
library(lmtest)
library(stargazer)
library(plm)

## Set directory
setwd("~/Dropbox/working-papers/china-aid-turnover/data/")

dat <- read.csv("china-aid-turnover-data.csv",
                stringsAsFactors = FALSE)

## For table output
dat <- dat %>%
  rename(election = election_year)

dat <- dat %>%
  mutate(civil_conflicts = ifelse(civil_conflicts > 0, 1, 0))

## Fix missing values for US aid 
dat$ln_us_aid[is.na(dat$ln_us_aid)] <- 0

#-------------------------------------------------------
# Table of summary statistics
#-------------------------------------------------------

summary_data <- dat %>%
  dplyr::select(ln_china_total_finance,
                ln_china_oda,
                ln_china_oof,
                ln_china_grants,
                ln_china_loans,
                sols_change_dummy,
                other_leader_trans,
                regtrans_alt,
                civil_conflicts,
                dem,
                us_ally,
                ln_gdp,
                china_s2un_t1,
                n_disasters,
                natural_resource_rent,
                ln_us_aid,
                taiwan_recognition)

var_labels <- c("Total Chinese finance (log)",
                "Total Chinese ODA-like finance (log)",
                "Total Chinese OOF-like finance (log)",
                "Total Chinese grant amounts (log)",
                "Total Chinese loan amounts (log)",
                "SOLS change",
                "Other leader change",
                "Regime change",
                "Civil conflict",
                "Democracy",
                "US ally",
                "GDP (constant 2000 USD, log)",
                "UNGA voting similarity to China",
                "Natural disasters",
                "Natural resource rents",
                "US aid (log)",
                "Taiwan recognition")

stargazer(
  summary_data,
  covariate.labels = var_labels,
  label = "summary-stats",
  font.size = "footnotesize",
  title = "Descriptive statistics for key variables",
  out = c(
    "~/Dropbox/working-papers/china-aid-turnover/tables/summary-stats.tex",
    "~/Dropbox/working-papers/china-aid-turnover/tables/summary-stats.html")
)



#-------------------------------------------------------
# Regression table 1
#-------------------------------------------------------

## Make panel data frame
pdat <- pdata.frame(dat %>% arrange(iso3c, year),
                    index = c("iso3c", "year"))

m1 <- plm(ln_china_total_finance ~ 
            sols_change_dummy +
            other_leader_trans +
            regtrans_alt +
            civil_conflicts +
            dem +
            ln_gdp +
            n_disasters +
            natural_resource_rent +
            taiwan_recognition +
            ln_us_aid +
            ln_china_total_finance_t1,
          data = pdat,
          method = "within",
          effect = "twoways")

m2 <- update(m1,
             ln_china_oda ~ . - ln_china_total_finance_t1 + 
               ln_china_oda_t1)

100 * (exp(coef(m2)) - 1)

m3 <- update(m1,
             ln_china_oof ~ . - ln_china_total_finance_t1 + 
               ln_china_oof_t1)

m4 <- update(m1,
             ln_china_grants ~ . - ln_china_total_finance_t1 + 
               ln_china_grants_t1)

m5 <- update(m1,
             ln_china_loans ~ . - ln_china_total_finance_t1 + 
               ln_china_loans_t1)

## Collect the five model objects in a list
china_models_amt <- list(m1, m2, m3, m4, m5)


## Get country-clustered estimated standard errors
china_clust_ses_amt <- lapply(china_models_amt,
                              function(x) 
                                sqrt(
                                  diag(
                                    vcovHC(x, 
                                           method = "arellano",
                                           type = "HC1")
                                  )
                                )
)


## Get number of countries for table output
china_countries_n <- sapply(china_models_amt,
                            function(x)
                              pdim(x)$nT$n)

summary(m1)
## Prepare a table in LaTeX 
china_dv_labels <- c("All finance (log)",
                     "ODA-like (log)",
                     "OOF-like (log)",
                     "Grants (log)",
                     "Loans (log)")

covariates <- c("SOLS change",
                "Other leader change",
                "Regime change",
                "Civil conflict",
                "Democracy",
                "GDP (log)",
                "Natural disasters",
                "Natural resource rents",
                "Taiwan recognition",
                "US aid (log)")

setwd("~/Dropbox/working-papers/china-aid-turnover/tables/")
sink("china-final-table-1.tex")
stargazer(china_models_amt,
          se = china_clust_ses_amt,
          dep.var.labels = china_dv_labels,
          covariate.labels = covariates,
          label = "china-final-table-1",
          title = "Domestic changes and Chinese finance, 2000-2014",
          omit = c("year", "continent", "iso3c", "_t1"),
          p.auto = TRUE,
          t.auto = TRUE,
          digits = 3,
          column.sep.width = c("0pt"),
          notes.append = TRUE,
          notes.align = "l",
          notes.label = "",
          keep.stat = c("n", "f", "rsq"),
          add.lines = list(c("N. countries", china_countries_n)),
          font.size = "footnotesize",
          notes = c(
            "Two-tailed tests. Estimated standard errors clustered by recipient in parentheses.", 
            "Country- and year-fixed effects, lagged outcome (one-year) included in all models."),
          model.names = FALSE,
          model.numbers = TRUE,
          no.space = TRUE,
          out = "china-final-table-1.html",
          df = FALSE)
sink()


#-------------------------------------------------------------
# Figure 1: US ally status and China voting alignment
#-------------------------------------------------------------

unique(dat$statename[dat$us_ally == 1])

s1 <- plm(ln_china_total_finance ~ 
            sols_change_dummy*us_ally +
            other_leader_trans*us_ally +
            regtrans_alt*us_ally +
            civil_conflicts +
            dem +
            ln_gdp +
            n_disasters +
            natural_resource_rent +
            taiwan_recognition +
            ln_us_aid +
            ln_china_total_finance_t1,
          data = pdat,
          method = "within",
          effect = "time")

s2 <- update(s1,
             ln_china_oda ~ . - ln_china_total_finance_t1 + 
               ln_china_oda_t1)

s3 <- update(s1,
             ln_china_oof ~ . - ln_china_total_finance_t1 + 
               ln_china_oof_t1)

s4 <- update(s1,
             ln_china_grants ~ . - ln_china_total_finance_t1 + 
               ln_china_grants_t1)

s5 <- update(s1,
             ln_china_loans ~ . - ln_china_total_finance_t1 + 
               ln_china_loans_t1)


## Including only outcomes relevant for hypotheses (not non-concessional DVs)
s_models <- list(s1, s2, s4)


## Get country-clustered estimated standard errors
s_clust_ses_amt <- lapply(s_models,
                              function(x) 
                                sqrt(
                                  diag(
                                    vcovHC(x, 
                                           method = "arellano",
                                           type = "HC1")
                                  )
                                )
)


## Calculate significance of interaction term
mcce_ci_calc <- function(var1, var2, var2.value, 
                         model,
                         model_vcov = vcov(model)){
  
  b1_var <- model_vcov[var1, var1]
  
  int_var <- names(coef(model))[
    grepl(var1, names(coef(model))) & grepl(var2, names(coef(model)))
    ]
  
  b3_var <- model_vcov[int_var, int_var]
  b1b3_covar <- model_vcov[var1, int_var] 
  
  se <- sqrt(b1_var + (var2.value^2)*b3_var + 2*var2.value*b1b3_covar)
  MCCE <- summary(model)$coefficients[var1, 1] + 
    var2.value*summary(model)$coefficients[int_var, 1]
  
  return(c(var2.value = var2.value, 
           beta = MCCE, 
           std.error = se, 
           ci.95.lower = MCCE - 1.96 * se, 
           ci.95.upper = MCCE + 1.96 * se,
           ci.90.lower = MCCE - 1.645 * se, 
           ci.90.upper = MCCE + 1.645 * se))
  
}


results <- lapply(s_models, function(x) {
  rbind(mcce_ci_calc("sols_change_dummy", "us_ally", 0, x,
                     model_vcov = vcovHC(x, 
                                         method = "arellano",
                                         type = "HC1")),
        mcce_ci_calc("sols_change_dummy", "us_ally", 1, x,
                     model_vcov = vcovHC(x, 
                                         method = "arellano",
                                         type = "HC1")))
})

## Bind results
results <- do.call(rbind.data.frame, results)


## Add model names

results$model <- rep(c("All", "ODA-like", "Grants"), each = 2)


## Convert to factor
results$model <- factor(results$model,
                        levels = unique(results$model))


setwd("~/Dropbox/working-papers/china-aid-turnover/figures/")
p <- ggplot(results,
            aes(x = model, y = beta,
                ymin = ci.95.lower, ymax = ci.95.upper,
                group = var2.value,
                colour = factor(var2.value))) +
  geom_linerange(position = position_dodge(width = .5),
                 size = 1) +
  geom_point(position = position_dodge(width = .5),
             size = 5,
             pch = 16) +
  geom_linerange(aes(x = model, ymin = ci.90.lower,
                     ymax = ci.90.upper),
                 position = position_dodge(width = .5),
                 size = 3) +
  theme(panel.border = element_rect(colour = "black", fill = NA, size = 1),
        panel.background = element_blank(),
        panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),
        plot.caption = element_text(hjust = 0.5),
        axis.text.x = element_text(size = 12)) + #,
  labs(x = "\n Finance type (log) \n",
       y = "Estimated coefficient on SOLS change dummy",
       caption = "Note: 90% and 95% confidence intervals.") +
  geom_hline(yintercept = 0, lty = "dashed") +
  scale_color_manual(name = "Alliance status",
                     labels = c("Non-US ally",
                                "US ally"),
                     values = c("grey65", "black")) 


ggsave(filename = "us-ally-interaction-results.jpeg",
       plot = p, 
       scale = 1, width = 6.98, height = 5.19, 
       units = c("in"),
       dpi = 300)










u1 <- plm(ln_china_total_finance ~ 
            sols_change_dummy*china_s2un_t1 +
            other_leader_trans*china_s2un_t1 +
            regtrans_alt*china_s2un_t1 +
            civil_conflicts +
            dem +
            ln_gdp +
            n_disasters +
            natural_resource_rent +
            taiwan_recognition +
            ln_us_aid +
            ln_china_total_finance_t1,
          data = pdat,
          method = "within",
          effect = "twoways")

u2 <- update(u1,
             ln_china_oda ~ . - ln_china_total_finance_t1 + 
               ln_china_oda_t1)

u3 <- update(u1,
             ln_china_oof ~ . - ln_china_total_finance_t1 + 
               ln_china_oof_t1)

u4 <- update(u1,
             ln_china_grants ~ . - ln_china_total_finance_t1 + 
               ln_china_grants_t1)

u5 <- update(u1,
             ln_china_loans ~ . - ln_china_total_finance_t1 + 
               ln_china_loans_t1)


u_models <- list(u1, u2, u4)

u_models_clust <- lapply(u_models,
                         function(x) 
                           sqrt(
                             diag(
                               vcovHC(x, 
                                      method = "arellano",
                                      type = "HC1")
                             )
                           )
)



u <- mean(dat$china_s2un_t1, na.rm = T)
dev <- sd(dat$china_s2un_t1, na.rm = T)


results <-lapply(u_models, function(x) {
  rbind(mcce_ci_calc("sols_change_dummy", "china_s2un_t1", 1, x,
                     model_vcov = vcov(x,
                                       method = "arellano",
                                       type = "HC1")),
        mcce_ci_calc("sols_change_dummy", "china_s2un_t1", u - 2*dev, x,
                     model_vcov = vcov(x,
                                       method = "arellano",
                                       type = "HC1")))
})



results <- do.call(rbind.data.frame, results)
results$model <- rep(c("All", "ODA-like", "Grants"),
                     each = 2)

results$model <- factor(results$model,
                        levels = unique(results$model))





setwd("~/Dropbox/working-papers/china-aid-turnover/figures/")
p <- ggplot(results,
            aes(x = model, y = beta,
                ymin = ci.95.lower, ymax = ci.95.upper,
                group = -var2.value,
                colour = factor(-var2.value))) +
  geom_linerange(position = position_dodge(width = .5),
                 size = 1) +
  geom_point(position = position_dodge(width = .5),
             size = 5,
             pch = 16) +
  geom_linerange(aes(x = model, ymin = ci.90.lower,
                     ymax = ci.90.upper),
                 position = position_dodge(width = .5),
                 size = 3) +
  theme(panel.border = element_rect(colour = "black", fill = NA, size = 1),
        panel.background = element_blank(),
        panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),
        plot.caption = element_text(hjust = 0.5),
        axis.text.x = element_text(size = 12)) + #,
  labs(x = "\n Finance type (log) \n",
       y = "Estimated coefficient on SOLS change dummy",
       caption = "Note: 90% and 95% confidence intervals.") +
  geom_hline(yintercept = 0, lty = "dashed") +
  scale_color_manual(name = "Voting alignment \n with China",
                     labels = c("Exact match",
                                "Mean - 2SD"),
                     values = c("grey65", "black")) 

ggsave(filename = "un-voting-interaction-results.jpeg",
       plot = p, 
       scale = 1, width = 6.98, height = 5.19, 
       units = c("in"),
       dpi = 300)



#-------------------------------------------------------------
# Figure 2: Regime type as moderating variable
#-------------------------------------------------------------

d1 <- plm(ln_china_total_finance ~ 
            sols_change_dummy*dem +
            other_leader_trans*dem +
            regtrans_alt*dem +
            civil_conflicts +
            us_ally +
            ln_gdp +
            n_disasters +
            natural_resource_rent +
            taiwan_recognition +
            ln_us_aid +
            ln_china_total_finance_t1,
          data = pdat,
          method = "within",
          effect = "twoways")

d2 <- update(d1,
             ln_china_oda ~ . - ln_china_total_finance_t1 + 
               ln_china_oda_t1)

d3 <- update(d1,
             ln_china_oof ~ . - ln_china_total_finance_t1 + 
               ln_china_oof_t1)

d4 <- update(d1,
             ln_china_grants ~ . - ln_china_total_finance_t1 + 
               ln_china_grants_t1)

d5 <- update(d1,
             ln_china_loans ~ . - ln_china_total_finance_t1 + 
               ln_china_loans_t1)


d_models <- list(d1, d2, d3, d4, d5)

results <-lapply(d_models, function(x) {
  rbind(mcce_ci_calc("sols_change_dummy", "dem", 0, x,
                     model_vcov = vcov(x,
                                       method = "arellano",
                                       type = "HC1")),
        mcce_ci_calc("sols_change_dummy", "dem", 1, x,
                     model_vcov = vcov(x,
                                       method = "arellano",
                                       type = "HC1")))
})

results <- do.call(rbind.data.frame, results)
results$model <- rep(c("All", "ODA-like", "OOF-like", "Grants", "Loans"), each = 2)

results$model <- factor(results$model,
                        levels = unique(results$model))



setwd("~/Dropbox/working-papers/china-aid-turnover/figures/")
p <- ggplot(results,
            aes(x = model, y = beta,
                ymin = ci.95.lower, ymax = ci.95.upper,
                group = var2.value,
                colour = factor(var2.value))) +
  geom_linerange(position = position_dodge(width = .5),
                 size = 1) +
  geom_point(position = position_dodge(width = .5),
             size = 5,
             pch = 16) +
  geom_linerange(aes(x = model, ymin = ci.90.lower,
                     ymax = ci.90.upper),
                 position = position_dodge(width = .5),
                 size = 3) +
  theme(panel.border = element_rect(colour = "black", fill = NA, size = 1),
        panel.background = element_blank(),
        panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),
        plot.caption = element_text(hjust = 0.5),
        axis.text.x = element_text(size = 12)) + #,
  #text = element_text(family = "Garamond")) +
  labs(x = "\n Finance type (log) \n",
       y = "Estimated coefficient on SOLS change dummy",
       caption = "Note: 90% and 95% confidence intervals.") +
  geom_hline(yintercept = 0, lty = "dashed") +
  scale_color_manual(name = "",
                     labels = c("Non-democracy",
                                "Democracy"),
                     values = c("grey65", "black"))

ggsave(filename = "democracy-interaction-results.jpeg",
       plot = p, 
       scale = 1, width = 6.98, height = 5.19, 
       units = c("in"),
       dpi = 300)




## Histogram of distance from China
hist(dat$china_s2un_t1)

ggplot(dat,
       aes(x = china_s2un_t1)) +
  geom_histogram(bins = 50) +
  labs(x = "Affinity to China in UN General Assembly",
       y = "Number of country-year observations") +
  theme(panel.border = element_rect(colour = "black", fill = NA, size = 1),
        panel.background = element_blank(),
        panel.grid.major = element_blank(), 
        panel.grid.minor = element_blank(),
        plot.caption = element_text(hjust = 0.5),
        axis.text.x = element_text(size = 12))

ggsave(filename = "../figures/china-voting-histogram.pdf",
       scale = 1, width = 6.98, height = 5.19, 
       units = c("in"),
       dpi = 300)








