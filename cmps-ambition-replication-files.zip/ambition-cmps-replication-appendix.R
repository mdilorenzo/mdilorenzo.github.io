# Statistical models and results in Online Appendix of:
# "Presidential Political Ambition and US Foreign Conflict Behavior, 1816-2010"
# Last updated 05/31/2016

# This script contains the code to reproduce all of the estimates in the tables and figures reported in the appendix of our article.

require(MASS)
require(sandwich)
require(lmtest)
require(clusterSEs)
library(stargazer)
require(dplyr)
require(tidyr)
require(tikzDevice)
require(foreign)

# Set working directory
setwd("~/Dropbox/Article Manuscripts/ambition_cmps/ambition-cmps-revision/")

# setwd("~/Downloads/ambition-cmps-replication-file/")

dat <- read.csv("ambition-cmps-data.csv")

#############################################
# APPENDIX A: Summary Statistics
#############################################
summary_data <- dat %>% select(year, pq, code, ambition, recession, age_quarterly, cinc2_interpolated, post22, mids_init, mids_init_dummy, hh_mids_init_dummy, mids_target_dummy, past_mids_leader, peace_quarters, rivalries)

stargazer(summary_data)

rm(summary_data)

################################################
# APPENDIX B: Histograms of Dependent Variables
################################################

#tikz("dv_hists.tex")
par(mfrow=c(1,3))
barplot(table(dat$mids_init_dummy), main="MIDs Initiated", xlab="MIDs Initiated", ylab="Frequency")
barplot(table(dat$hh_mids_init_dummy), main="Hostile MIDs Initiated", xlab="Hostile MIDs Initiated", ylab="Frequency")
barplot(table(dat$mids_target_dummy), main="MIDs Targeted", xlab="MIDs Targeted", ylab="Frequency")
#dev.off()



######################################################################
## APPENDIX D: Alternative Dependent Variable: High-Hostility MIDs
######################################################################
# To look at any of these models individually in the R console, use the summary() command. For example, to look at a model object called m1, use summary(m1).
# Model 1
m1<-glm(hh_mids_init_dummy ~ ambition, data=dat, family=binomial(link="logit"), na.action="na.omit")

# Model 2
m2<-glm(hh_mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + post22, data=dat, family=binomial(link="logit"), na.action="na.omit")

# Model 3
m3<-glm(hh_mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + post22 + past_mids_leader + peace_quarters + rivalries, data=dat, family=binomial(link="logit"), na.action="na.omit")

# Model 4
m4<-glm(hh_mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + post22 + factor(decade), data=dat, family=binomial(link="logit"))

# Model 5
m5<-glm(hh_mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + post22 + past_mids_leader + peace_quarters + rivalries + factor(decade), data=dat, family=binomial(link="logit"), na.action="na.omit")

# Model 6
m6<-glm(hh_mids_init_dummy ~ ambition + pq + cinc2_interpolated + recession +post22 +  past_mids_leader + peace_quarters + rivalries + factor(code), data=dat, family=binomial(link="logit"), na.action="na.omit")

# Model 7
m7<-glm(hh_mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + post22 + past_mids_leader + peace_quarters + rivalries + factor(year), data=dat, family=binomial(link="logit"), na.action="na.omit")


# Output in LaTeX format
stargazer(m1, m2, m3, m4, m5, m6, m7,
          title="Political Ambition and High-Hostility MID Initiations",
          omit=c("decade","code","year"))



#################################################################################
## APPENDIX E: Alternative Dependent Variable: Count Models for MID Initiations
#################################################################################

# Test for dispersion in two base models
test1<-glm(mids_init ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + post22, data=dat, family="poisson", na.action="na.omit")
test2<-glm(mids_init ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + post22 + past_mids_leader + peace_quarters + rivalries, data=dat, family="poisson",  na.action="na.omit")
dispersiontest(test1)
dispersiontest(test2)


# Model 1
m1<-glm(mids_init ~ ambition, data=dat,  family="poisson", na.action="na.omit")

# Model 2
m2<-glm(mids_init ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + post22, data=dat, family="poisson")
summary(m2)

# Model 3
m3<-glm(mids_init ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + post22 + past_mids_leader + peace_quarters + rivalries, data=dat, family="poisson")

# Model 4
m4<-glm(mids_init ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + post22 + factor(decade), family="poisson", data=dat)

# Model 5
m5<-glm(mids_init ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + post22 + past_mids_leader + peace_quarters + rivalries + factor(decade),family="poisson", data=dat,  na.action="na.omit")

# Model 6
m6<-glm(mids_init ~ ambition + pq + cinc2_interpolated + recession +post22 +  past_mids_leader + peace_quarters + rivalries + factor(code), family="poisson", data=dat,  na.action="na.omit")

# Model 7
m7<-glm(mids_init ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + post22 + past_mids_leader + peace_quarters + rivalries + factor(year), family="poisson", data=dat,  na.action="na.omit")


# Output in LaTeX format
stargazer(m1, m2, m3, m4, m5, m6, m7,
          title="Political Ambition and Count of MID Initiations, Poisson Regression",
          omit=c("decade","code","year"))









######################################################################
## APPENDIX F: Bootstrap Clustering Standard Errors on Presidents
######################################################################

# Model 1
m1<-glm(mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + post22, data=dat, family=binomial(link="logit"), na.action="na.omit")

clust.bs.m1 <- cluster.bs.glm(m1, dat, ~ code, report=T)

# Model 2
m2<-glm(mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + post22 + past_mids_leader + peace_quarters + rivalries, data=dat, family=binomial(link="logit"), na.action="na.omit")

clust.bs.m2 <- cluster.bs.glm(m2, dat, ~ code, report=T)

# Export to TeX format
stargazer(clust.bs.m1,
          title="Initiation Models with President-clustered Standard Errors")

stargazer(clust.bs.m2,
          title="Initiation Models with President-clustered Standard Errors")





######################################################################
## APPENDIX G: Ambition and MID Hostility
######################################################################

mids<-read.csv("MIDB_4.01.csv",
               na.strings = "-9")

# Reduce to US only
us_disputes<-mids[mids$ccode==2,]

ambition <-read.csv("ambition-cmps-data.csv") %>%
  select(ambition, 
         qstartmonth, 
         qendmonth, 
         year, 
         pq,
         age_quarterly, 
         cinc2_interpolated,
         past_mids_leader,
         peace_quarters,
         rivalries,
         post22,
         recession)


# Creating year-month version of ambition data
month_ambition <- c()
for(i in 1:nrow(ambition)){
  three_months <- cbind(ambition = rep(ambition$ambition[i], 3),
                        StMon = ambition$qstartmonth[i]:ambition$qendmonth[i],
                        StYear = rep(ambition$year[i], 3),
                        recession = rep(ambition$recession[i], 3),
                        pq = rep(ambition$pq[i], 3),
                        age_quarterly = rep(ambition$age_quarterly[i], 3),
                        cinc2_interpolated = rep(ambition$cinc2_interpolated[i], 3),
                        past_mids_leader = rep(ambition$past_mids_leader[i], 3),
                        peace_quarters = rep(ambition$peace_quarters[i], 3),
                        rivalries = rep(ambition$rivalries[i], 3),
                        post22 = rep(ambition$post22[i], 3))
  month_ambition <- rbind(month_ambition, three_months)
}

month_ambition <- data.frame(month_ambition)

# Fixing dates for us_disputes
us_disputes$StDay[is.na(us_disputes$StDay)] <- 1
us_disputes$EndDay[is.na(us_disputes$EndDay)] <- 1

# Merging by year-month.
us_disputes <- left_join(us_disputes, month_ambition, by = c("StMon","StYear"))

# Model 1
mid_model_1 <- lm(HostLev ~ ambition,
                  data = us_disputes)
mid_model_1_rvm <- vcovHC(mid_model_1, type = "HC1")
summary(mid_model_1)
coeftest(mid_model_1, vcov = mid_model_1_rvm)

# Model 2
mid_model_2 <- lm(HostLev ~ ambition + 
                    pq + 
                    age_quarterly + 
                    cinc2_interpolated + 
                    post22 +
                    recession + 
                    past_mids_leader + 
                    peace_quarters +
                    rivalries,
                  data = us_disputes)
mid_model_2_rvm <- vcovHC(mid_model_2, type = "HC1")
summary(mid_model_2)
coeftest(mid_model_2, vcov = mid_model_2_rvm)

robust_se_m1 <- sqrt(diag(mid_model_1_rvm))
robust_se_m2 <- sqrt(diag(mid_model_2_rvm))

# Make variable labels
cov.labels <- c("Ambition",
                "Time in Office",
                "Age",
                "CINC (Quarterly Interpolations)",
                "Recession",
                "Post-Truman Dummy",
                "Previous MIDs",
                "Peace Quarters",
                "International Rivalries")

# Export to TeX with heteroskedasticity-consistent standard errors
stargazer(mid_model_1, mid_model_2,
          covariate.labels = cov.labels,
          dep.var.labels = "MID Hostility",
          se = list(c(robust_se_m1, robust_se_m2)))





######################################################################
## APPENDIX I: Political Ambitions During Recessions
######################################################################

# MODELS FOR INTERACTION WITH RECESSIONS

# Model 1
int1<-glm(mids_init_dummy ~ ambition*recession, data=dat, family=binomial(link="logit"), na.action="na.omit")
summary(int1)

# Model 2
int2<-glm(mids_init_dummy ~ ambition*recession + pq + age_quarterly + cinc2_interpolated + post22, data=dat, family=binomial(link="logit"), na.action="na.omit")
summary(int2)

# Model 3
int3<-glm(mids_init_dummy ~ ambition*recession + pq + age_quarterly + cinc2_interpolated + post22 + past_mids_leader + peace_quarters + rivalries, data=dat, family=binomial(link="logit"), na.action="na.omit")
summary(int3)

# Model 4
int0<-glm(mids_init_dummy ~ ambition, data=dat[dat$recession==1,], family=binomial(link="logit"), na.action="na.omit")
summary(int0)

# Model 5
int0_no<-glm(mids_init_dummy ~ ambition, data=dat[dat$recession==0,], family=binomial(link="logit"), na.action="na.omit")
summary(int0_no)

# Model 6
int4<-glm(mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + post22, data=dat[dat$recession==1,], family=binomial(link="logit"), na.action="na.omit")
summary(int4)

# Model 7
int4_no<-glm(mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + post22, data=dat[dat$recession==0,], family=binomial(link="logit"), na.action="na.omit")
summary(int4_no)

# Model 8
int5<-glm(mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + post22 + past_mids_leader + peace_quarters + rivalries, data=dat[dat$recession==1,], family=binomial(link="logit"), na.action="na.omit")
summary(int5)

# Model 9
int5_no<-glm(mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + post22 + past_mids_leader + peace_quarters + rivalries, data=dat[dat$recession==0,], family=binomial(link="logit"), na.action="na.omit")
summary(int5_no)

stargazer(int1, int2, int3, int0, int0_no, int4, int4_no, int5, int5_no,
          title="Political Ambition, Recessions, and Conflict Behavior")


