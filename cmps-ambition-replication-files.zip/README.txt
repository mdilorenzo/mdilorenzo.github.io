This replication file contains files for the article "Presidential Political Ambition and US Foreign Conflict Behavior, 1816-2010." It includes the following files:

ambition-cmps-data.csv - This is the primary data set used in our analysis.

ambition-cmps-replication-codebook.pdf - This document describes our key variables.

ambition-cmps-replication-script.R - This R script provides code to reproduce all of the estimates and figures in the main text.

ambition-cmps-replication-appendix.R - This R script provides code to reproduce all of the estimates and figures in the Online Appendix.

zeigler-replication-initiation.dta - This is the initiation data from the replication file for Zeigler et al. (2014).

MIDB_4.01.csv - This is the participant-level version of the MID data (v. 4.01) from the Correlates of War project to needed to reproduce the MID-level analysis in Section G of the Online Appendix.