# Statistical models and results in main text of:
# "Presidential Political Ambition and US Foreign Conflict Behavior, 1816-2010"
# Last updated 05/10/2016

# This script contains the code to reproduce all of the estimates in the tables and figures reported in the main text of our article. The code for Tables 1 through 4 appears first, then code for Figure 1.

require(MASS)
require(stargazer)
require(dplyr)
require(tidyr)
require(tikzDevice)
require(foreign)

# Set working directory (change as needed)
setwd("~/Dropbox/Article Manuscripts/ambition_cmps/ambition-cmps-revision/")

# setwd("~/Downloads/ambition-cmps-replication-file/")

# Read in data
dat<-read.csv("ambition-cmps-data.csv")

# Calculate percentage of MIDs US was involved in.
mids<-read.csv("MIDB_4.01.csv")
all_disputes<-unique(mids$DispNum3)
us_disputes<-unique(mids$DispNum3[mids$ccode==2])
length(us_disputes)/length(all_disputes)
rm(mids, us_disputes, all_disputes)

###########################################
### MODELS FOR TABLE 1 (INITIATION MODELS)
###########################################
# To look at any of these models individually in the R console, use the summary() command. For example, to look at a model object called m1, use summary(m1).
## Model 1
m1<-glm(mids_init_dummy ~ ambition + 
          pq + 
          age_quarterly + 
          cinc2_interpolated + 
          recession + 
          post22, data=dat, family=binomial(link="logit"))

# Model 2
m2 <- update(m1, . ~ . + past_mids_leader + peace_quarters + rivalries)

# Model 3
m3<-update(m2, . ~ . + factor(decade))


# Create labels for table output
cov.labels <- c("Ambition",
                "Time in Office",
                "Age",
                "CINC (Quarterly Interpolations)",
                "Recession",
                "Post-Truman Dummy",
                "Previous MIDs",
                "Peace Quarters",
                "International Rivalries")

# Output in TeX format
stargazer(m1, m2, m3,
          title="Political Ambition and MID Initiations, 1816-2010",
          dep.var.labels = "MID Initiation (Dummy)",
          label = "logit_1",
          covariate.labels = cov.labels,
          add.lines = list(c("Decade Dummies", "No", "No", "Yes")),
          omit=c("decade","year"))




########################################
### MODELS FOR TABLE 2 (TARGET MODELS)
########################################

## Model 1
tm1<-glm(mids_target_dummy ~ ambition + 
          pq + 
          age_quarterly + 
          cinc2_interpolated + 
          recession + 
          post22, data=dat, family=binomial(link="logit"))

## Model 2
tm2 <- update(tm1, . ~ . + past_mids_leader + peace_quarters + rivalries)

## Model 3
tm3<-update(tm2, . ~ . + factor(decade))


# Output in LaTeX format
stargazer(tm1, tm2, tm3, 
          title="Political Ambition and Probability of Being MID Target",
          label = "logit_1_target",
          dep.var.labels = "Target of MID (Dummy)",
          model.names = T,
          covariate.labels = cov.labels,
          add.lines = list(c("Decade Dummies", "No", "No", "Yes")),
          omit=c("decade","year"))



###################################################
### MODELS FOR TABLE 3 (ROBUSTNESS CHECKS MODELS)
###################################################

# First create a version of the ambition variable that treats pre-22 Amendment cases as 1 except for the last quarter that the president was in office

# Create a variable that gives each president's maximum time in office
max_time <- dat %>%
  group_by(code) %>%
  summarise(max_quarter = max(pq))

# Merge into main data
dat <- left_join(dat, max_time, by="code")
dat$ambition_pre22_1<-ifelse(dat$post22==1, dat$ambition, ifelse(dat$pq==dat$max_quarter,0,1))

# Anywhere that we originally coded a president as having ambition during this time should also be coded as 1
dat$ambition_pre22_1[dat$post22==0 & dat$ambition==1]<-1

# Check
check <- dat %>% 
  select(code, pq, ambition_pre22_1) %>% 
  arrange(code, pq)

rm(check)
dat<-dat[,!colnames(dat) %in% "max_quarter"]


# Model 1
pre22_1_post22_control<-glm(mids_init_dummy ~ ambition_pre22_1 + pq + age_quarterly + cinc2_interpolated + recession + post22 + past_mids_leader + peace_quarters + rivalries, data=dat, family=binomial(link="logit"), na.action="na.omit")

# Model 2
pre22_1_fe<-glm(mids_init_dummy ~ ambition_pre22_1 + pq + age_quarterly + cinc2_interpolated + recession + post22 + past_mids_leader + peace_quarters + rivalries +factor(decade), data=dat, family=binomial(link="logit"), na.action="na.omit")

# Model 3
revision_domain<-glm(mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + past_mids_leader + peace_quarters + rivalries, data=dat[dat$year>=1978 & dat$year<=2000,], family=binomial(link="logit"), na.action="na.omit")

# Model 4
pre_22_subset<-glm(mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + past_mids_leader + peace_quarters + rivalries, data=dat[dat$post22==0,], family=binomial(link="logit"), na.action="na.omit")

# Model 5
pre_22_subset_fe<-glm(mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + past_mids_leader + peace_quarters + rivalries + factor(decade), data=dat[dat$post22==0,], family=binomial(link="logit"), na.action="na.omit")

# Model 6
post_22_subset<-glm(mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + past_mids_leader + peace_quarters + rivalries, data=dat[dat$post22==1,], family=binomial(link="logit"), na.action="na.omit")

# Model 7
post_22_subset_fe<-glm(mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + past_mids_leader + peace_quarters + rivalries + factor(decade), data=dat[dat$post22==1,], family=binomial(link="logit"), na.action="na.omit")

# Output in TeX format
stargazer(pre22_1_post22_control, 
          pre22_1_fe, 
          revision_domain, 
          pre_22_subset, 
          pre_22_subset_fe, 
          post_22_subset, 
          post_22_subset_fe, 
          title="Alternative Coding Decisions and Temporal Domains",
          omit=c("decade"))


###################################################
### MODELS FOR TABLE 4 (ZEIGLER ET AL. REPLICATION)
###################################################

# Note: we obtained the replication data directly from the authors of the Zeigler et al. (2014) article. It should also be available from the Journal of Conflict Resolution website here:
# http://jcr.sagepub.com/content/58/4/658

zeig<-as.data.frame(read.dta("zeigler-replication-initiation.dta"))

us_only<-zeig[zeig$ccode1==2,]

# Model 1
z1<-glm(cwinit ~ tl2,
         data=us_only,
         family=binomial(link="logit"),
         na.action="na.omit")

# Model 2
z2 <- update(z1, . ~ . + distance + polity2receiver + relcap + majpow2)

stargazer(z1, z2, title="Term Limits and Conflict Initiation Using \\possessivecite{Zeigler2014} Directed-Dyadic Data Set, United States Only")

rm(zeig, us_only)


############################################
##### FIGURE 1, UPPER PANELS (ALL MIDS)
############################################

# Bootstrapping predicted probabilities with Model 1 in Table 1
set.seed(741391) # From random.org in [1,1000000] 741391

# No recession, pre-22 period
ambition_0 <- c(0, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),0,0)
ambition_1 <- c(1, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),0,0)

bootstrapped_coefficients <- replicate(1000, {
  obs<-sample(seq(1, nrow(dat)), nrow(dat), replace=TRUE)
  bs<-dat[obs,]
  model<-glm(mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + post22, data=bs, family=binomial(link="logit"), na.action="na.omit")
  a <- exp(model$coefficients[1] + sum(ambition_0*model$coefficients[2:7]))
  b <- exp(model$coefficients[1] + sum(ambition_1*model$coefficients[2:7]))
  pred_prob_0 <- a/(1+a)
  pred_prob_1 <- b/(1+b)
  pred_prob_1 - pred_prob_0
})


# Recession, pre-22 period
ambition_0 <- c(0, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),1,0)
ambition_1 <- c(1, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),1,0)

bootstrapped_coefficients_2 <- replicate(1000, {
  obs<-sample(seq(1, nrow(dat)), nrow(dat), replace=TRUE)
  bs<-dat[obs,]
  model<-glm(mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + post22, data=bs, family=binomial(link="logit"), na.action="na.omit")
  a <- exp(model$coefficients[1] + sum(ambition_0*model$coefficients[2:7]))
  b <- exp(model$coefficients[1] + sum(ambition_1*model$coefficients[2:7]))
  pred_prob_0 <- a/(1+a)
  pred_prob_1 <- b/(1+b)
  pred_prob_1 - pred_prob_0
})

# No recession, post-22 period
ambition_0 <- c(0, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),0,1)
ambition_1 <- c(1, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),0,1)

bootstrapped_coefficients_3 <- replicate(1000, {
  obs<-sample(seq(1, nrow(dat)), nrow(dat), replace=TRUE)
  bs<-dat[obs,]
  model<-glm(mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + post22, data=bs, family=binomial(link="logit"), na.action="na.omit")
  a <- exp(model$coefficients[1] + sum(ambition_0*model$coefficients[2:7]))
  b <- exp(model$coefficients[1] + sum(ambition_1*model$coefficients[2:7]))
  pred_prob_0 <- a/(1+a)
  pred_prob_1 <- b/(1+b)
  pred_prob_1 - pred_prob_0
})


# Recession, post-22 period
ambition_0 <- c(0, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),1,1)
ambition_1 <- c(1, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),1,1)

bootstrapped_coefficients_4 <- replicate(1000, {
  obs<-sample(seq(1, nrow(dat)), nrow(dat), replace=TRUE)
  bs<-dat[obs,]
  model<-glm(mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + post22, data=bs, family=binomial(link="logit"), na.action="na.omit")
  a <- exp(model$coefficients[1] + sum(ambition_0*model$coefficients[2:7]))
  b <- exp(model$coefficients[1] + sum(ambition_1*model$coefficients[2:7]))
  pred_prob_0 <- a/(1+a)
  pred_prob_1 <- b/(1+b)
  pred_prob_1 - pred_prob_0
})

# Collecting means in a vector
x<-c(mean(bootstrapped_coefficients), mean(bootstrapped_coefficients_2), mean(bootstrapped_coefficients_3), mean(bootstrapped_coefficients_4))
y<- c(1,2,3,4)

# Plot
tikz("pred_prob_ambition_model1.tex",width=5,height=5)
par(oma=c(0,3,0,0))
plot(x, y,
     xlim=c(-.025,.3),
     pch=16,
     main="Model 2 in Table \\ref{logit_1} \n (Changing Ambition from 0 to 1)",
     xlab="Change in Predicted Probability",
     ylab="",
     yaxt="n")
segments(0,0,0,4.5, lty="dotted")

segments(quantile(bootstrapped_coefficients, c(0.025, 0.975))[1],y[1],quantile(bootstrapped_coefficients, c(0.025, 0.975))[2], y[1], lwd=3)
segments(quantile(bootstrapped_coefficients, c(0.025, 0.975))[1],y[2],quantile(bootstrapped_coefficients_2, c(0.025, 0.975))[2], y[2], lwd=3)
segments(quantile(bootstrapped_coefficients_3, c(0.025, 0.975))[1],y[3],quantile(bootstrapped_coefficients_3, c(0.025, 0.975))[2], y[3], lwd=3)
segments(quantile(bootstrapped_coefficients_4, c(0.025, 0.975))[1],y[4],quantile(bootstrapped_coefficients_4, c(0.025, 0.975))[2], y[4], lwd=3)

segments(quantile(bootstrapped_coefficients, c(0.05, 0.95))[1],y[1],quantile(bootstrapped_coefficients, c(0.05, 0.95))[2], y[1], lwd=6)
segments(quantile(bootstrapped_coefficients, c(0.05, 0.95))[1],y[2],quantile(bootstrapped_coefficients_2, c(0.05, 0.95))[2], y[2], lwd=6)
segments(quantile(bootstrapped_coefficients_3, c(0.05, 0.95))[1],y[3],quantile(bootstrapped_coefficients_3, c(0.05, 0.95))[2], y[3], lwd=6)
segments(quantile(bootstrapped_coefficients_4, c(0.05, 0.95))[1],y[4],quantile(bootstrapped_coefficients_4, c(0.05, 0.95))[2], y[4], lwd=6)

axis(2, at=c(4,3,2,1), labels=c("Recession,\n Post-1951","No Recession,\n Post-1951","Recession,\n Pre-1951","No Recession,\n Pre-1951"),las=1,cex=.15)

dev.off()



# Point estimates for Model 1 in Table 1 (discussed in text)
model<-glm(mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + post22, data=dat, family=binomial(link="logit"), na.action="na.omit")
coefs<-model$coefficients

# No recession, pre-22 period
ambition_0 <- c(0, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),0,0)
ambition_1 <- c(1, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),0,0)

p0<-exp(coefs[1]+sum(ambition_0*coefs[2:7]))/(1+exp(coefs[1]+sum(ambition_0*coefs[2:7])))
pa<-exp(coefs[1]+sum(ambition_1*coefs[2:7]))/(1+exp(coefs[1]+sum(ambition_1*coefs[2:7])))

(pa-p0)/p0*100
# 55.5% increase (0.095 to 0.148)

# Recession, pre-22 period
ambition_0 <- c(0, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),1,0)
ambition_1 <- c(1, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),1,0)

p0<-exp(coefs[1]+sum(ambition_0*coefs[2:7]))/(1+exp(coefs[1]+sum(ambition_0*coefs[2:7])))
pa<-exp(coefs[1]+sum(ambition_1*coefs[2:7]))/(1+exp(coefs[1]+sum(ambition_1*coefs[2:7])))

(pa-p0)/p0*100
# 55.5% increase (0.095 to 0.148)


# No recession, post-22 period
ambition_0 <- c(0, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),0,1)
ambition_1 <- c(1, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),0,1)

p0<-exp(coefs[1]+sum(ambition_0*coefs[2:7]))/(1+exp(coefs[1]+sum(ambition_0*coefs[2:7])))
pa<-exp(coefs[1]+sum(ambition_1*coefs[2:7]))/(1+exp(coefs[1]+sum(ambition_1*coefs[2:7])))

(pa-p0)/p0*100
# 55.5% increase (0.095 to 0.148)



# Recession, post-22 period
ambition_0 <- c(0, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),1,1)
ambition_1 <- c(1, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),1,1)

p0<-exp(coefs[1]+sum(ambition_0*coefs[2:7]))/(1+exp(coefs[1]+sum(ambition_0*coefs[2:7])))
pa<-exp(coefs[1]+sum(ambition_1*coefs[2:7]))/(1+exp(coefs[1]+sum(ambition_1*coefs[2:7])))

(pa-p0)/p0*100
# 55.5% increase (0.095 to 0.148)

















# Bootstrapping predicted probabilities with Model 2 in Table 1

# No recession, pre-22 period
ambition_0 <- c(0, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),0,0,mean(dat$past_mids_leader), mean(dat$peace_quarters), mean(dat$rivalries))
ambition_1 <- c(1, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),0,0,mean(dat$past_mids_leader), mean(dat$peace_quarters), mean(dat$rivalries))

bootstrapped_coefficients <- replicate(1000, {
  obs<-sample(seq(1, nrow(dat)), nrow(dat), replace=TRUE)
  bs<-dat[obs,]
  model<-glm(mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + post22 + past_mids_leader + peace_quarters + rivalries, data=bs, family=binomial(link="logit"), na.action="na.omit")
  a <- exp(model$coefficients[1] + sum(ambition_0*model$coefficients[2:10]))
  b <- exp(model$coefficients[1] + sum(ambition_1*model$coefficients[2:10]))
  pred_prob_0 <- a/(1+a)
  pred_prob_1 <- b/(1+b)
  pred_prob_1 - pred_prob_0
})


# Recession, pre-22 period
ambition_0 <- c(0, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),1,0,mean(dat$past_mids_leader), mean(dat$peace_quarters), mean(dat$rivalries))
ambition_1 <- c(1, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),1,0,mean(dat$past_mids_leader), mean(dat$peace_quarters), mean(dat$rivalries))

bootstrapped_coefficients_2 <- replicate(1000, {
  obs<-sample(seq(1, nrow(dat)), nrow(dat), replace=TRUE)
  bs<-dat[obs,]
  model<-glm(mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + post22 + past_mids_leader + peace_quarters + rivalries, data=bs, family=binomial(link="logit"), na.action="na.omit")
  a <- exp(model$coefficients[1] + sum(ambition_0*model$coefficients[2:10]))
  b <- exp(model$coefficients[1] + sum(ambition_1*model$coefficients[2:10]))
  pred_prob_0 <- a/(1+a)
  pred_prob_1 <- b/(1+b)
  pred_prob_1 - pred_prob_0
})


# No recession, post-22 period
ambition_0 <- c(0, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),0,1,mean(dat$past_mids_leader), mean(dat$peace_quarters), mean(dat$rivalries))
ambition_1 <- c(1, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),0,1,mean(dat$past_mids_leader), mean(dat$peace_quarters), mean(dat$rivalries))

bootstrapped_coefficients_3 <- replicate(1000, {
  obs<-sample(seq(1, nrow(dat)), nrow(dat), replace=TRUE)
  bs<-dat[obs,]
  model<-glm(mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + post22 + past_mids_leader + peace_quarters + rivalries, data=bs, family=binomial(link="logit"), na.action="na.omit")
  a <- exp(model$coefficients[1] + sum(ambition_0*model$coefficients[2:10]))
  b <- exp(model$coefficients[1] + sum(ambition_1*model$coefficients[2:10]))
  pred_prob_0 <- a/(1+a)
  pred_prob_1 <- b/(1+b)
  pred_prob_1 - pred_prob_0
})


# Recession, post-22 period
ambition_0 <- c(0, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),1,1,mean(dat$past_mids_leader), mean(dat$peace_quarters), mean(dat$rivalries))
ambition_1 <- c(1, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),1,1,mean(dat$past_mids_leader), mean(dat$peace_quarters), mean(dat$rivalries))

bootstrapped_coefficients_4 <- replicate(1000, {
  obs<-sample(seq(1, nrow(dat)), nrow(dat), replace=TRUE)
  bs<-dat[obs,]
  model<-glm(mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + post22 + past_mids_leader + peace_quarters + rivalries, data=bs, family=binomial(link="logit"), na.action="na.omit")
  a <- exp(model$coefficients[1] + sum(ambition_0*model$coefficients[2:10]))
  b <- exp(model$coefficients[1] + sum(ambition_1*model$coefficients[2:10]))
  pred_prob_0 <- a/(1+a)
  pred_prob_1 <- b/(1+b)
  pred_prob_1 - pred_prob_0
})


# Collect means in a vector
x<-c(mean(bootstrapped_coefficients), mean(bootstrapped_coefficients_2), mean(bootstrapped_coefficients_3), mean(bootstrapped_coefficients_4))
y<- c(1,2,3,4)

# Plot
tikz("pred_prob_ambition_model2.tex",width=5,height=5)
par(oma=c(0,4,0,0))
plot(x, y,
     xlim=c(-.025,.25),
     pch=16,
     main="Model 3 in Table \\ref{logit_1} \n (Changing Ambition from 0 to 1)",
     xlab="Change in Predicted Probability",
     ylab="",
     yaxt="n")
segments(0,0,0,4.5, lty="dotted")

segments(quantile(bootstrapped_coefficients, c(0.025, 0.975))[1],y[1],quantile(bootstrapped_coefficients, c(0.025, 0.975))[2], y[1], lwd=3)
segments(quantile(bootstrapped_coefficients, c(0.025, 0.975))[1],y[2],quantile(bootstrapped_coefficients_2, c(0.025, 0.975))[2], y[2], lwd=3)
segments(quantile(bootstrapped_coefficients_3, c(0.025, 0.975))[1],y[3],quantile(bootstrapped_coefficients_3, c(0.025, 0.975))[2], y[3], lwd=3)
segments(quantile(bootstrapped_coefficients_4, c(0.025, 0.975))[1],y[4],quantile(bootstrapped_coefficients_4, c(0.025, 0.975))[2], y[4], lwd=3)

segments(quantile(bootstrapped_coefficients, c(0.05, 0.95))[1],y[1],quantile(bootstrapped_coefficients, c(0.05, 0.95))[2], y[1], lwd=6)
segments(quantile(bootstrapped_coefficients, c(0.05, 0.95))[1],y[2],quantile(bootstrapped_coefficients_2, c(0.05, 0.95))[2], y[2], lwd=6)
segments(quantile(bootstrapped_coefficients_3, c(0.05, 0.95))[1],y[3],quantile(bootstrapped_coefficients_3, c(0.05, 0.95))[2], y[3], lwd=6)
segments(quantile(bootstrapped_coefficients_4, c(0.05, 0.95))[1],y[4],quantile(bootstrapped_coefficients_4, c(0.05, 0.95))[2], y[4], lwd=6)

axis(2, at=c(4,3,2,1), labels=c("Recession,\n Post-1951","No Recession,\n Post-1951","Recession,\n Pre-1951","No Recession,\n Pre-1951"),las=1,cex=.15)

dev.off()








# FIGURE 1, BOTTOM PANELS (HIGH-HOSTILITY MIDS)

# Bootstrapping predicted probabilities with Model 1 in Table 1, with high-hostility MIDs
set.seed(741391) # From random.org in [1,1000000] 741391
# No recession, pre-22 period
ambition_0 <- c(0, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),0,0)
ambition_1 <- c(1, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),0,0)

bootstrapped_coefficients <- replicate(1000, {
  obs<-sample(seq(1, nrow(dat)), nrow(dat), replace=TRUE)
  bs<-dat[obs,]
  model<-glm(hh_mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + post22, data=bs, family=binomial(link="logit"), na.action="na.omit")
  a <- exp(model$coefficients[1] + sum(ambition_0*model$coefficients[2:7]))
  b <- exp(model$coefficients[1] + sum(ambition_1*model$coefficients[2:7]))
  pred_prob_0 <- a/(1+a)
  pred_prob_1 <- b/(1+b)
  pred_prob_1 - pred_prob_0
})


# Recession, pre-22 period
ambition_0 <- c(0, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),1,0)
ambition_1 <- c(1, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),1,0)

bootstrapped_coefficients_2 <- replicate(1000, {
  obs<-sample(seq(1, nrow(dat)), nrow(dat), replace=TRUE)
  bs<-dat[obs,]
  model<-glm(hh_mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + post22, data=bs, family=binomial(link="logit"), na.action="na.omit")
  a <- exp(model$coefficients[1] + sum(ambition_0*model$coefficients[2:7]))
  b <- exp(model$coefficients[1] + sum(ambition_1*model$coefficients[2:7]))
  pred_prob_0 <- a/(1+a)
  pred_prob_1 <- b/(1+b)
  pred_prob_1 - pred_prob_0
})


# No recession, post-22 period
ambition_0 <- c(0, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),0,1)
ambition_1 <- c(1, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),0,1)

bootstrapped_coefficients_3 <- replicate(1000, {
  obs<-sample(seq(1, nrow(dat)), nrow(dat), replace=TRUE)
  bs<-dat[obs,]
  model<-glm(hh_mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + post22, data=bs, family=binomial(link="logit"), na.action="na.omit")
  a <- exp(model$coefficients[1] + sum(ambition_0*model$coefficients[2:7]))
  b <- exp(model$coefficients[1] + sum(ambition_1*model$coefficients[2:7]))
  pred_prob_0 <- a/(1+a)
  pred_prob_1 <- b/(1+b)
  pred_prob_1 - pred_prob_0
})


# Recession, post-22 period
ambition_0 <- c(0, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),1,1)
ambition_1 <- c(1, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),1,1)

bootstrapped_coefficients_4 <- replicate(1000, {
  obs<-sample(seq(1, nrow(dat)), nrow(dat), replace=TRUE)
  bs<-dat[obs,]
  model<-glm(hh_mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + post22, data=bs, family=binomial(link="logit"), na.action="na.omit")
  a <- exp(model$coefficients[1] + sum(ambition_0*model$coefficients[2:7]))
  b <- exp(model$coefficients[1] + sum(ambition_1*model$coefficients[2:7]))
  pred_prob_0 <- a/(1+a)
  pred_prob_1 <- b/(1+b)
  pred_prob_1 - pred_prob_0
})


# Collect means in a vector
x<-c(mean(bootstrapped_coefficients), mean(bootstrapped_coefficients_2), mean(bootstrapped_coefficients_3), mean(bootstrapped_coefficients_4))
y<- c(1,2,3,4)

# Plot
tikz("pred_prob_ambition_model1_hh.tex",width=5,height=5)
par(oma=c(0,3,0,0), mar=rep(4,4))
plot(x, y,
     xlim=c(-.025,.3),
     pch=16,
     main="Model 2 in Table \\ref{logit_1}, \n MID Hostility Level $\\geq4$ \n (Changing Ambition from 0 to 1)",
     xlab="Change in Predicted Probability",
     ylab="",
     yaxt="n",
     col="maroon")
segments(0,0,0,4.5, lty="dotted")

segments(quantile(bootstrapped_coefficients, c(0.025, 0.975))[1],y[1],quantile(bootstrapped_coefficients, c(0.025, 0.975))[2], y[1], lwd=3, col="maroon")
segments(quantile(bootstrapped_coefficients, c(0.025, 0.975))[1],y[2],quantile(bootstrapped_coefficients_2, c(0.025, 0.975))[2], y[2], lwd=3, col="maroon")
segments(quantile(bootstrapped_coefficients_3, c(0.025, 0.975))[1],y[3],quantile(bootstrapped_coefficients_3, c(0.025, 0.975))[2], y[3], lwd=3, col="maroon")
segments(quantile(bootstrapped_coefficients_4, c(0.025, 0.975))[1],y[4],quantile(bootstrapped_coefficients_4, c(0.025, 0.975))[2], y[4], lwd=3, col="maroon")

segments(quantile(bootstrapped_coefficients, c(0.05, 0.95))[1],y[1],quantile(bootstrapped_coefficients, c(0.05, 0.95))[2], y[1], lwd=6, col="maroon")
segments(quantile(bootstrapped_coefficients, c(0.05, 0.95))[1],y[2],quantile(bootstrapped_coefficients_2, c(0.05, 0.95))[2], y[2], lwd=6, col="maroon")
segments(quantile(bootstrapped_coefficients_3, c(0.05, 0.95))[1],y[3],quantile(bootstrapped_coefficients_3, c(0.05, 0.95))[2], y[3], lwd=6, col="maroon")
segments(quantile(bootstrapped_coefficients_4, c(0.05, 0.95))[1],y[4],quantile(bootstrapped_coefficients_4, c(0.05, 0.95))[2], y[4], lwd=6, col="maroon")

axis(2, at=c(4,3,2,1), labels=c("Recession,\n Post-1951","No Recession,\n Post-1951","Recession,\n Pre-1951","No Recession,\n Pre-1951"),las=1,cex=.15)

dev.off()





# Bootstrapping predicted probabilities with Model 2 in Table 1, high-hostility MIDs

# No recession, pre-22 period
ambition_0 <- c(0, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),0,0,mean(dat$past_mids_leader), mean(dat$peace_quarters), mean(dat$rivalries))
ambition_1 <- c(1, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),0,0,mean(dat$past_mids_leader), mean(dat$peace_quarters), mean(dat$rivalries))

bootstrapped_coefficients <- replicate(1000, {
  obs<-sample(seq(1, nrow(dat)), nrow(dat), replace=TRUE)
  bs<-dat[obs,]
  model<-glm(hh_mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + post22 + past_mids_leader + peace_quarters + rivalries, data=bs, family=binomial(link="logit"), na.action="na.omit")
  a <- exp(model$coefficients[1] + sum(ambition_0*model$coefficients[2:10]))
  b <- exp(model$coefficients[1] + sum(ambition_1*model$coefficients[2:10]))
  pred_prob_0 <- a/(1+a)
  pred_prob_1 <- b/(1+b)
  pred_prob_1 - pred_prob_0
})




# Recession, pre-22 period
ambition_0 <- c(0, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),1,0,mean(dat$past_mids_leader), mean(dat$peace_quarters), mean(dat$rivalries))
ambition_1 <- c(1, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),1,0,mean(dat$past_mids_leader), mean(dat$peace_quarters), mean(dat$rivalries))

bootstrapped_coefficients_2 <- replicate(1000, {
  obs<-sample(seq(1, nrow(dat)), nrow(dat), replace=TRUE)
  bs<-dat[obs,]
  model<-glm(hh_mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + post22 + past_mids_leader + peace_quarters + rivalries, data=bs, family=binomial(link="logit"), na.action="na.omit")
  a <- exp(model$coefficients[1] + sum(ambition_0*model$coefficients[2:10]))
  b <- exp(model$coefficients[1] + sum(ambition_1*model$coefficients[2:10]))
  pred_prob_0 <- a/(1+a)
  pred_prob_1 <- b/(1+b)
  pred_prob_1 - pred_prob_0
})



# No recession, post-22 period
ambition_0 <- c(0, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),0,1,mean(dat$past_mids_leader), mean(dat$peace_quarters), mean(dat$rivalries))
ambition_1 <- c(1, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),0,1,mean(dat$past_mids_leader), mean(dat$peace_quarters), mean(dat$rivalries))

bootstrapped_coefficients_3 <- replicate(1000, {
  obs<-sample(seq(1, nrow(dat)), nrow(dat), replace=TRUE)
  bs<-dat[obs,]
  model<-glm(hh_mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + post22 + past_mids_leader + peace_quarters + rivalries, data=bs, family=binomial(link="logit"), na.action="na.omit")
  a <- exp(model$coefficients[1] + sum(ambition_0*model$coefficients[2:10]))
  b <- exp(model$coefficients[1] + sum(ambition_1*model$coefficients[2:10]))
  pred_prob_0 <- a/(1+a)
  pred_prob_1 <- b/(1+b)
  pred_prob_1 - pred_prob_0
})


# Recession, post-22 period
ambition_0 <- c(0, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),1,1,mean(dat$past_mids_leader), mean(dat$peace_quarters), mean(dat$rivalries))
ambition_1 <- c(1, mean(dat$pq), mean(dat$age_quarterly), mean(dat$cinc2_interpolated),1,1,mean(dat$past_mids_leader), mean(dat$peace_quarters), mean(dat$rivalries))

bootstrapped_coefficients_4 <- replicate(1000, {
  obs<-sample(seq(1, nrow(dat)), nrow(dat), replace=TRUE)
  bs<-dat[obs,]
  model<-glm(hh_mids_init_dummy ~ ambition + pq + age_quarterly + cinc2_interpolated + recession + post22 + past_mids_leader + peace_quarters + rivalries, data=bs, family=binomial(link="logit"), na.action="na.omit")
  a <- exp(model$coefficients[1] + sum(ambition_0*model$coefficients[2:10]))
  b <- exp(model$coefficients[1] + sum(ambition_1*model$coefficients[2:10]))
  pred_prob_0 <- a/(1+a)
  pred_prob_1 <- b/(1+b)
  pred_prob_1 - pred_prob_0
})


# Collect means in a vector
x<-c(mean(bootstrapped_coefficients), mean(bootstrapped_coefficients_2), mean(bootstrapped_coefficients_3), mean(bootstrapped_coefficients_4))
y<- c(1,2,3,4)

# Plot
tikz("pred_prob_ambition_model2_hh.tex",width=5,height=5)
par(oma=c(0,4,0,0))
plot(x, y,
     xlim=c(-.025,.25),
     pch=16,
     main="Model 3 in Table \\ref{logit_1}, \n MID Hostility Level $\\geq4$ \n (Changing Ambition from 0 to 1)",
     xlab="Change in Predicted Probability",
     ylab="",
     yaxt="n",
     col="maroon")
segments(0,0,0,4.5, lty="dotted")


segments(quantile(bootstrapped_coefficients, c(0.025, 0.975))[1],y[1],quantile(bootstrapped_coefficients, c(0.025, 0.975))[2], y[1], lwd=3, col="maroon")
segments(quantile(bootstrapped_coefficients, c(0.025, 0.975))[1],y[2],quantile(bootstrapped_coefficients_2, c(0.025, 0.975))[2], y[2], lwd=3, col="maroon")
segments(quantile(bootstrapped_coefficients_3, c(0.025, 0.975))[1],y[3],quantile(bootstrapped_coefficients_3, c(0.025, 0.975))[2], y[3], lwd=3, col="maroon")
segments(quantile(bootstrapped_coefficients_4, c(0.025, 0.975))[1],y[4],quantile(bootstrapped_coefficients_4, c(0.025, 0.975))[2], y[4], lwd=3, col="maroon")

segments(quantile(bootstrapped_coefficients, c(0.05, 0.95))[1],y[1],quantile(bootstrapped_coefficients, c(0.05, 0.95))[2], y[1], lwd=6, col="maroon")
segments(quantile(bootstrapped_coefficients, c(0.05, 0.95))[1],y[2],quantile(bootstrapped_coefficients_2, c(0.05, 0.95))[2], y[2], lwd=6, col="maroon")
segments(quantile(bootstrapped_coefficients_3, c(0.05, 0.95))[1],y[3],quantile(bootstrapped_coefficients_3, c(0.05, 0.95))[2], y[3], lwd=6, col="maroon")
segments(quantile(bootstrapped_coefficients_4, c(0.05, 0.95))[1],y[4],quantile(bootstrapped_coefficients_4, c(0.05, 0.95))[2], y[4], lwd=6, col="maroon")

axis(2, at=c(4,3,2,1), labels=c("Recession,\n Post-1951","No Recession,\n Post-1951","Recession,\n Pre-1951","No Recession,\n Pre-1951"),las=1,cex=.15)

dev.off()





