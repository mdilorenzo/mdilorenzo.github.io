#------------------------------------------------------------------------------
# Controls for aid and civil conflict in: 
# "Leader Survival, Sources of Political Insecurity, and International Conflict"
# Last updated 05-08-2018
# Matt DiLorenzo

library(MASS)
library(car)
library(lmtest)
library(multiwayvcov)
library(tidyverse)
library(foreign)

## Set directory
setwd("~/Dropbox/article-manuscripts/leaders-prq/final/")

## Load custom functions
source("scripts/basic-custom-functions.R")

## Load data
load("replication-data/lsndic-data-lagged-ivs-archigos-4.RData")

## Rename peace years variable for sake of table output
leaders <- leaders %>%
  rename(peace_yrs_mid = peace_years_mid)


# Merge in AidData
############################################
aid <- read.csv("replication-data/aux/aiddata2_1_donor_recipient_year_purpose.csv")

require(doBy)
aid_sum <- summaryBy(commitment_usd_constant_sum ~ recipient_iso3 + year, 
                     data = aid, FUN = sum)


library(countrycode)
aid_sum$ccode <- countrycode(aid_sum$recipient_iso3, 
                             "iso3c", "cown", warn = TRUE)

aid_sum <- aid_sum %>% 
  dplyr::select(ccode, year, commitment_usd_constant_sum.sum) %>%
  rename(aid_commitments = commitment_usd_constant_sum.sum)

leaders <- left_join(leaders, aid_sum, by = c("ccode", "year"))


# Creating version that replaces missing values with zero
leaders$aid_commitments_missing_as_zero <- leaders$aid_commitments
leaders$aid_commitments_missing_as_zero[
  is.na(leaders$aid_commitments_missing_as_zero)
  ] <- 0


leaders$ln_aid_commitments <- log(leaders$aid_commitments + 1)
leaders$ln_aid_commitments_missing_as_zero <- log(leaders$aid_commitments_missing_as_zero + 1)


leaders <- leaders %>%
  rename(peace_yrs_mid = peace_years_mid)


#  Civil war involvement in previous year
############################################
# Using the UCDP/PRIO Armed Conflict Data, internal armed conflict only (type==3)
prio <- read.dta("replication-data/aux/UCDP_Armed_Conflict_2014.dta")
prio <- prio[prio$type == 3, ]

# Creating civil conflict counter
prio$civil_conflict_t1 <- 1
civil <- aggregate(civil_conflict_t1 ~ gwnoa + year, data = prio, FUN = 'sum')
civil$year <- civil$year + 1 # year lag

civil <- civil %>%
  dplyr::select(civil_conflict_t1, gwnoa, year) %>%
  rename(ccode = gwnoa) %>%
  mutate(ccode = as.numeric(ccode))


leaders <- left_join(leaders, civil, by = c("ccode","year"))
leaders$civil_conflict_t1[is.na(leaders$civil_conflict_t1)] <- 0


## Correlation matrix
leaders %>% select(ln_deaths_t1, 
                   lwc_r, 
                   lwc_i,
                   lwc_r_75,
                   lwc_i_75,
                   small,
                   cinc,
                   ln_land, 
                   ln_realgdp,
                   pop, 
                   leader_tenure, 
                   peace_yrs_mid,
                   ln_aid_commitments, 
                   civil_conflict_t1) %>%
  cor(use = "pairwise.complete.obs") %>%
  stargazer()


########### Model 1

fit_1 <- glm.nb(mids_init ~ ln_deaths_t1 * lwc_r + 
                  ln_deaths_t1 * lwc_i +
                  cinc + ln_land + ln_realgdp + pop + 
                  leader_tenure + peace_yrs_mid +
                  + ln_aid_commitments + civil_conflict_t1 +
                  factor(year),
                data = leaders, na.action = "na.omit")

mcce_ci_calc("ln_deaths_t1","lwc_i", var2.value = 1, model = fit_1)
mcce_ci_calc("ln_deaths_t1","lwc_r", var2.value = 1, model = fit_1)



###########  Model 2

fit_2 <- glm.nb(mids_init ~ ln_deaths_t1 * lwc_r_75 + 
                  ln_deaths_t1 * lwc_i_75 +
                  cinc + ln_land + ln_realgdp + pop + 
                  leader_tenure + peace_yrs_mid +
                  + ln_aid_commitments + civil_conflict_t1 +
                  factor(year),
                data = leaders, na.action = "na.omit")

mcce_ci_calc("ln_deaths_t1","lwc_i_75", 
             var2.value = 1, model = fit_2)
mcce_ci_calc("ln_deaths_t1","lwc_r_75", 
             var2.value = 1, model = fit_2)

linearHypothesis(fit_2,
                 c("ln_deaths_t1:lwc_r_75 - ln_deaths_t1:lwc_i_75 = 0"),
                 test="F")





########### Model 3 (missing aid data coded as zero)

fit_3 <- glm.nb(mids_init ~ ln_deaths_t1 * lwc_r + 
                  ln_deaths_t1 * lwc_i +
                  cinc + ln_land + ln_realgdp + pop + 
                  leader_tenure + peace_yrs_mid +
                  + ln_aid_commitments_missing_as_zero + civil_conflict_t1 +
                  factor(year),
                data = leaders, na.action = "na.omit")
summary(fit_3)

mcce_ci_calc("ln_deaths_t1", "lwc_i", var2.value = 1, model = fit_3)
mcce_ci_calc("ln_deaths_t1", "lwc_r", var2.value = 1, model = fit_3)


###########  Model 4 (missing aid data coded as zero)

fit_4 <- glm.nb(mids_init ~ ln_deaths_t1 * lwc_r_75 + 
                  ln_deaths_t1 * lwc_i_75 +
                  cinc + ln_land + ln_realgdp + pop + 
                  leader_tenure + peace_yrs_mid +
                  + ln_aid_commitments_missing_as_zero + civil_conflict_t1 +
                  factor(year),
                data = leaders, na.action = "na.omit")

mcce_ci_calc("ln_deaths_t1", "lwc_i_75", var2.value = 1, model = fit_4)
mcce_ci_calc("ln_deaths_t1", "lwc_r_75", var2.value = 1, model = fit_4)


linearHypothesis(fit_4,
                 c("ln_deaths_t1:lwc_r_75 - ln_deaths_t1:lwc_i_75 = 0"),
                 test = "F")


## Make table ----------------------------------------------------------------
cov_labels <- c("Deaths (log)",
                "Large-Coalition, Regular Removal (LC-R)",
                "Large-Coalition, Irregular Removal (LC-I)",
                "Large-Coalition, Regular Removal (LC-R, W$\\geq$0.75)",
                "Large-Coalition, Irregular Removal (LC-I, W$\\geq$0.75)",
                "CINC",
                "Land area (km$^2$, log)",
                "Real GDP (log)",
                "Population",
                "Leader Tenure",
                "Peace Years",
                "Aid Commitments (log)",
                "Aid Commitments (log, missing = zero)",
                "Civil Conflict",
                "Disaster Deaths (log) $\\times$ LC-R",
                "Disaster Deaths (log) $\\times$ LC-I",
                "Disaster Deaths (log) $\\times$ LC-R (W$\\geq$0.75)",
                "Disaster Deaths (log) $\\times$ LC-I (W$\\geq$0.75)")

library(stargazer)
stargazer(fit_1, fit_2, fit_3, fit_4,
          covariate.labels = cov_labels,
          omit = c("year", "Intercept"),
          title = "Controlling for Aid and Civil Conflict")

