#------------------------------------------------------------------------------
# Controls for aid and civil conflict in: 
# "Leader Survival, Sources of Political Insecurity, and International Conflict"
# Last updated 05-08-2018
# Matt DiLorenzo

library(MASS)
library(car)
library(lmtest)
library(multiwayvcov)
library(tidyverse)
library(foreign)

## Set directory
setwd("~/Dropbox/article-manuscripts/leaders-prq/final/")

## Load custom functions
source("scripts/basic-custom-functions.R")

## Load data
load("replication-data/lsndic-data-lagged-ivs-archigos-4.RData")

## Rename peace years variable for sake of table output
leaders <- leaders %>%
  rename(peace_yrs_mid = peace_years_mid)


## Function to get confidence intervals for interaction effect from zinb model
mcce_ci_calc <- function(var1, int_var, var2.value, model){
  b1_var <- vcov(model)[var1, var1]
  b3_var <- vcov(model)[int_var, int_var]
  b1b3_covar <- vcov(model)[var1, int_var] 
  
  se <- sqrt(b1_var + (var2.value^2)*b3_var + 2*var2.value*b1b3_covar)
  MCCE <-coef(model)[var1] + 
    var2.value*coef(model)[int_var]
  
  return(c(var2.value = var2.value, 
           beta = MCCE, 
           std.error = se, 
           ci.95.lower = MCCE-1.96*se, 
           ci.95.upper= MCCE+1.96*se,
           ci.90.lower = MCCE-1.645*se, 
           ci.90.upper= MCCE+1.645*se,
           ci.80.lower = MCCE-1.282*se, 
           ci.80.upper= MCCE+1.282*se))
}



# Zero-inflated negative binomial regression
###############################################
require(pscl)
require(MASS)
require(boot)


############### Model 1
fit_1_data <- leaders %>%
  select(mids_init, ln_deaths_t1, lwc_r, lwc_i, cinc,
         ln_land, ln_realgdp, pop, leader_tenure, peace_yrs_mid, year) %>%
  na.exclude()


fit_1 <- zeroinfl(mids_init ~ ln_deaths_t1 * lwc_r + 
                    ln_deaths_t1 * lwc_i +
                  cinc + ln_land + ln_realgdp + I(log(pop + 1)) + 
                  leader_tenure + peace_yrs_mid + factor(year) | cinc,
                data = fit_1_data, dist = "negbin")




mcce_ci_calc("count_ln_deaths_t1", "count_ln_deaths_t1:lwc_i", 
             var2.value = 1, model = fit_1)
mcce_ci_calc("count_ln_deaths_t1", "count_ln_deaths_t1:lwc_r", 
             var2.value = 1, model = fit_1)




############## Model 2

fit_2_data <- leaders %>%
  select(mids_init, ln_deaths_t1, lwc_r_75, lwc_i_75, cinc,
         ln_land, ln_realgdp, pop, leader_tenure, peace_yrs_mid, year) %>%
  na.exclude()


fit_2 <- zeroinfl(mids_init ~ ln_deaths_t1 * lwc_r_75 + 
                    ln_deaths_t1 * lwc_i_75 +
                    cinc + ln_land + ln_realgdp + I(log(pop + 1)) + 
                    leader_tenure + peace_yrs_mid + factor(year) | cinc,
                  data = fit_2_data, dist = "negbin")


mcce_ci_calc("count_ln_deaths_t1", "count_ln_deaths_t1:lwc_i_75", 
             var2.value = 1, model = fit_2)
mcce_ci_calc("count_ln_deaths_t1", "count_ln_deaths_t1:lwc_r_75", 
             var2.value = 1, model = fit_2)


stargazer(fit_1, fit_2,
          title="Zero-inflated Negative Binomial Regression Models",
          omit = c("year"),
          label="zinb_models")
