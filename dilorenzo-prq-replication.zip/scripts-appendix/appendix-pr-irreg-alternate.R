# Alternate estimates of probability of irregular removal --------------------
# Matthew DiLorenzo
# Last updated 05-07-2018

require(MASS)
library(stargazer)
library(car)
library(lmtest)
library(multiwayvcov)
require(tidyverse)

## Set directory
setwd("~/Dropbox/article-manuscripts/leaders-prq/final/")

## Load custom functions
source("scripts/basic-custom-functions.R")

## Load data
load("replication-data/lsndic-data-lagged-ivs-archigos-4.RData")

## Rename peace years variable for sake of table output
leaders <- leaders %>%
  rename(peace_yrs_mid = peace_years_mid)


## Merge number of irregular removals as alternate version
n_irreg <- read.csv(
  "replication-data/aux/n-irreg-removals.csv"
)

leaders <- left_join(leaders, n_irreg)

leaders$any_irreg <- ifelse(leaders$pr_irreg_t20 > 0.25, 1, 0)

leaders$lwc_i_alt <- ifelse(
  leaders$any_irreg == 1 & leaders$large_coalition == 1,
  1, 0)

leaders$lwc_r_alt <- ifelse(
  leaders$any_irreg == 0 & leaders$large_coalition == 1,
  1, 0)

## Load custom functions
source("~/Dropbox/r/basic-custom-functions.R")



## Model 1
fit_1 <- glm.nb(mids_init ~ ln_deaths_t1 * lwc_i_alt +
                  ln_deaths_t1 * lwc_r_alt + 
                  cinc + ln_land + ln_realgdp + pop + 
                  leader_tenure + peace_yrs_mid + 
                  factor(year), 
                data = leaders, 
                na.action = "na.omit")

library(xtable)
cbind.data.frame(
  mcce_ci_calc("ln_deaths_t1", "lwc_i_alt", var2.value = 1, model = fit_1),
  mcce_ci_calc("ln_deaths_t1", "lwc_r_alt", var2.value = 1, model = fit_1)
) %>%
  t() %>%
  xtable

stargazer(fit_1,
          omit = c("year"))
