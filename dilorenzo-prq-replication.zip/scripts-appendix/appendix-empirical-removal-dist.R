## Generate table of empirical distribution of removal types in appendix

library(stargazer)
library(tidyverse)

## Set directory
setwd("~/Dropbox/article-manuscripts/leaders-prq/final/")

## Load custom functions
source("scripts/basic-custom-functions.R")

## Load data
load("replication-data/lsndic-data-lagged-ivs-archigos-4.RData")

## Rename peace years variable for sake of table output
leaders <- leaders %>%
  rename(peace_yrs_mid = peace_years_mid)

last_years <- leaders %>% filter(!exit=="(n_year)")

last_years$removal_type <- ifelse(
  last_years$lwc_i == 1, 
  "Large Coalition, Irregular Removal",
  ifelse(last_years$lwc_r ==1, 
         "Large Coalition, Regular Removal",
         ifelse(last_years$small_r ==1,
                "Small Coalition, Regular Removal",
                "Small Coalition, Irregular Removal")))


exit_table <- table(last_years$removal_type, last_years$exit)
exit_table <- round(prop.table(exit_table, 1), 2)

exit_table <- exit_table[, -1]

stargazer(exit_table,
          title = paste0("Empirical Distribution of Regime and",
                         " Removal Type, W$\\geq0.5$ Threshold"),
          label = "empirical_removal")


# For the W>=0.75 threshold
last_years$small_i_75 <- ifelse(last_years$W<0.75 & last_years$xrreg < 3, 1, 0)
last_years$small_r_75 <- ifelse(last_years$W<0.75 & last_years$xrreg == 3, 1, 0)
last_years$removal_type <- ifelse(
  last_years$lwc_i_75 == 1, 
  "Large Coalition, Irregular Removal",
  ifelse(last_years$lwc_r_75 ==1, 
         "Large Coalition, Regular Removal",
         ifelse(last_years$small_r_75 ==1,
                "Small Coalition, Regular Removal",
                "Small Coalition, Irregular Removal")))

exit_table <- table(last_years$removal_type, last_years$exit)
exit_table <- round(prop.table(exit_table, 1), 2)
exit_table
exit_table <- exit_table[,-1]

stargazer(exit_table,
          title = paste0("Empirical Distribution of Regime and",
                         " Removal Type, W$\\geq0.75$ Threshold"),
          label = "empirical_removal")