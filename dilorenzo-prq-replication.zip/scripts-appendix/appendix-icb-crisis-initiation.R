## This script is for the appendix table that uses ICB crises as an alternative dependent variable in "Leader Survival, Sources of Political Insecurity, and International Conflict"
## Last updated 02/20/2016

library(MASS)
library(car)
library(lmtest)
library(multiwayvcov)
library(tidyverse)
library(foreign)

## Set directory
setwd("~/Dropbox/article-manuscripts/leaders-prq/final/")

## Load custom functions
source("scripts/basic-custom-functions.R")

## Load data
load("replication-data/lsndic-data-lagged-ivs-archigos-4.RData")

## Rename peace years variable for sake of table output
leaders <- leaders %>%
  rename(peace_yrs_mid = peace_years_mid)



########### Model 1
fit_1 <- glm.nb(icb_crises_init ~ ln_deaths_t1 * lwc_r + 
                  ln_deaths_t1 * lwc_i +
                  cinc + ln_land + ln_realgdp + pop + 
                  leader_tenure + peace_yrs_mid +
                  factor(year),
                data = leaders, na.action = "na.omit")

mcce_ci_calc("ln_deaths_t1","lwc_i", var2.value = 1, model = fit_1)
mcce_ci_calc("ln_deaths_t1","lwc_r", var2.value = 1, model = fit_1)



########### Model 2
fit_2 <- glm.nb(icb_crises_init ~ ln_deaths_t1 * lwc_r_75 + 
                  ln_deaths_t1 * lwc_i_75 +
                  cinc + ln_land + ln_realgdp + pop + 
                  leader_tenure + peace_yrs_mid +
                  factor(year),
                data = leaders, na.action = "na.omit")

mcce_ci_calc("ln_deaths_t1","lwc_i_75", var2.value = 1, model = fit_2)
mcce_ci_calc("ln_deaths_t1","lwc_r_75", var2.value = 1, model = fit_2)


## Make table ----------------------------------------------------------------
cov_labels <- c("Deaths (log)",
                "Large-Coalition, Regular Removal (LC-R)",
                "Large-Coalition, Irregular Removal (LC-I)",
                "Large-Coalition, Regular Removal (LC-R, W$\\geq$0.75)",
                "Large-Coalition, Irregular Removal (LC-I, W$\\geq$0.75)",
                "CINC",
                "Land area (km$^2$, log)",
                "Real GDP (log)",
                "Population",
                "Leader Tenure",
                "Peace Years",
                "Disaster Deaths (log) $\\times$ LC-R",
                "Disaster Deaths (log) $\\times$ LC-I",
                "Disaster Deaths (log) $\\times$ LC-R (W$\\geq$0.75)",
                "Disaster Deaths (log) $\\times$ LC-I (W$\\geq$0.75)")

library(stargazer)
stargazer(fit_1, fit_2,
          covariate.labels = cov_labels,
          omit = c("year", "Intercept"),
          title = "")

