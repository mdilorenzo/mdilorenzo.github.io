#------------------------------------------------------------------------------
# Title: Note on replication files
# Author: Matt DiLorenzo
# Institution: Old Dominion University
# Contact: mdiloren@odu.edu
# Date: August 12, 2018
#
# Description: This folder contains the replication data, code, and appendix for:
# "Leader Survival, Sources of Political Insecurity, and International Conflict"
# Forthcoming in Political Research Quarterly
# -----------------------------------------------------------------------------

This folder contains the following subfolders:
- figures: Figures in the main text of the article.

- online-appendix: PDF of online appendix.
- replication-data: Replication data file in RData format ("lsndic-data-lagged-ivs-archigos-4.RData") needed to reproduce estimates in main text and appendix.
	- aux: Subfolder that contains supplementary data sets merged in for appendix.
- scripts:
	- basic-custom-functions.R: Contains custom function for calculating confidence intervals for interaction terms.	- expected-counts.R: Script to reproduce Figure 2 in main text.	- models.R: Script to reproduce all statistical models in main text.
- scripts-appendix: Scripts to reproduce all analyses in online appendix.
- tables: Raw table output that I used to generate tables that appear in the article.