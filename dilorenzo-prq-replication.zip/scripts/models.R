#------------------------------------------------------------------------------
# Title: Main models
# Author: Matt DiLorenzo
# Institution: Old Dominion University
# Date: Sat Aug  4 15:02:28 2018
# Description: This script contains the code to reproduce the statistical
# estimates in the main text of "Leader Survival, Sources of Political
# Insecurity, and International Conflict," ***except for Figure 2***.
# Forthcoming in Political Research Quarterly.
# For code to replicate Figure 2, see "expected-counts.R" script
# -----------------------------------------------------------------------------

## Load required packages
library(tidyverse)
library(readxl)
library(countrycode)
library(foreign)
library(stargazer)
library(xtable)
require(MASS)
library(car)

## Set directory
setwd("~/Dropbox/article-manuscripts/leaders-prq/final/")

## Load custom functions
source("scripts/basic-custom-functions.R")

## Load data
load("replication-data/lsndic-data-lagged-ivs-archigos-4.RData")

## Rename peace years variable for sake of table output
leaders <- leaders %>%
  rename(peace_yrs_mid = peace_years_mid)


#------------------------------------------------------------------------------
# Statistical models
#------------------------------------------------------------------------------

## Model 0a
fit_0a <- glm.nb(mids_init ~ ln_deaths_t1 * lwc_r + 
                   ln_deaths_t1 * lwc_i +
                   cinc + ln_land + ln_realgdp + pop, 
                 data = leaders, 
                 na.action = "na.omit")

linearHypothesis(fit_0a,
                 c("ln_deaths_t1:lwc_r - ln_deaths_t1:lwc_i = 0"),
                 test="F")


## Model 0b
fit_0b <- glm.nb(mids_init ~ ln_deaths_t1 * lwc_r_75 + 
                   ln_deaths_t1 * lwc_i_75 +
                   cinc + ln_land + ln_realgdp + pop, 
                 data = leaders, 
                 na.action = "na.omit")

linearHypothesis(fit_0b,
                 c("ln_deaths_t1:lwc_r_75 - ln_deaths_t1:lwc_i_75 = 0"),
                 test="F")

## Model 1
fit_1 <- glm.nb(mids_init ~ ln_deaths_t1 * lwc_r + 
                  ln_deaths_t1 * lwc_i +
                  cinc + ln_land + ln_realgdp + pop + 
                  leader_tenure + peace_yrs_mid +
                  factor(year), 
                data = leaders, 
                na.action = "na.omit")

mcce_ci_calc("ln_deaths_t1", "lwc_i", var2.value = 1, model = fit_1)
mcce_ci_calc("ln_deaths_t1", "lwc_r", var2.value = 1, model = fit_1)



linearHypothesis(fit_1,
                 c("ln_deaths_t1 = 0", "ln_deaths_t1:lwc_i = 0"),
                 test="F")
linearHypothesis(fit_1,
                 c("ln_deaths_t1 = 0", "ln_deaths_t1:lwc_r = 0"),
                 test="F")
linearHypothesis(fit_1,
                 c("ln_deaths_t1:lwc_r - ln_deaths_t1:lwc_i = 0"),
                 test="F")


##  Model 2
fit_2 <- glm.nb(mids_init ~ ln_deaths_t1 * lwc_r_75 + 
                  ln_deaths_t1 * lwc_i_75 + 
                  cinc + ln_land + ln_realgdp + pop + 
                  leader_tenure + peace_yrs_mid +
                  factor(year),
                data = leaders,
                na.action = "na.omit")

mcce_ci_calc("ln_deaths_t1", "lwc_i_75", var2.value = 1, fit_2)
mcce_ci_calc("ln_deaths_t1", "lwc_r_75", var2.value = 1, fit_2)

linearHypothesis(fit_2,
                 c("ln_deaths_t1 = 0", "ln_deaths_t1:lwc_i_75 = 0"),
                 test = "F")
linearHypothesis(fit_2,
                 c("ln_deaths_t1 = 0", "ln_deaths_t1:lwc_r_75 = 0"),
                 test = "F")
linearHypothesis(fit_2,
                 c("ln_deaths_t1:lwc_r_75 - ln_deaths_t1:lwc_i_75 = 0"),
                 test = "F")

## Model 3
fit_3 <- glm.nb(hh_mids_init ~ ln_deaths_t1 * lwc_r +
                  ln_deaths_t1 * lwc_i + 
                  cinc + ln_land + ln_realgdp + pop +
                  leader_tenure + peace_yrs_mid + 
                  factor(year),
                data = leaders,
                na.action = "na.omit")

mcce_ci_calc("ln_deaths_t1","lwc_i", var2.value = 1, fit_3)
mcce_ci_calc("ln_deaths_t1","lwc_r", var2.value = 1, fit_3)


linearHypothesis(fit_3,
                 c("ln_deaths_t1 = 0", "ln_deaths_t1:lwc_i = 0"),
                 test="F")
linearHypothesis(fit_3,
                 c("ln_deaths_t1 = 0", "ln_deaths_t1:lwc_r = 0"),
                 test="F")
linearHypothesis(fit_3,
                 c("ln_deaths_t1:lwc_r - ln_deaths_t1:lwc_i = 0"),
                 test="F")



# Model 4
fit_4 <- glm.nb(hh_mids_init ~ ln_deaths_t1*lwc_r_75 + 
                  ln_deaths_t1*lwc_i_75 + 
                  cinc + ln_land + ln_realgdp + pop + 
                  leader_tenure + peace_yrs_mid + 
                  factor(year),
                data = leaders,
                na.action = "na.omit")

mcce_ci_calc("ln_deaths_t1","lwc_i_75", var2.value = 1, fit_4)
mcce_ci_calc("ln_deaths_t1","lwc_r_75", var2.value = 1, fit_4)


linearHypothesis(fit_4,
                 c("ln_deaths_t1 = 0", "ln_deaths_t1:lwc_i_75 = 0"),
                 test = "F")
linearHypothesis(fit_4,
                 c("ln_deaths_t1 = 0", "ln_deaths_t1:lwc_r_75 = 0"),
                 test = "F")
linearHypothesis(fit_4,
                 c("ln_deaths_t1:lwc_r_75 - ln_deaths_t1:lwc_i_75 = 0"),
                 test = "F")



# Exporting table

## Put models in list
models <- list(fit_0a, fit_0b, fit_1, fit_2, fit_3, fit_4)

## Estimates for small-coalition regimes (baseline)
## Note that this is the same as for the lwc_i regimes but with var2.value = 0.
small_estimates <- rbind(
  mcce_ci_calc("ln_deaths_t1", "lwc_i", var2.value = 0, fit_0a),
  mcce_ci_calc("ln_deaths_t1", "lwc_i_75", var2.value = 0, fit_0b),
  mcce_ci_calc("ln_deaths_t1", "lwc_i", var2.value = 0, fit_1),
  mcce_ci_calc("ln_deaths_t1", "lwc_i_75", var2.value = 0, fit_2),
  mcce_ci_calc("ln_deaths_t1", "lwc_i", var2.value = 0, fit_3),
  mcce_ci_calc("ln_deaths_t1", "lwc_i_75", var2.value = 0, fit_4) )%>%
  as.data.frame() %>%
  dplyr::select(beta, std.error) %>%
  round(3) %>%
  t()

## Estimates for large-coalition, irregular removal
lwc_i_estimates <- rbind(
  mcce_ci_calc("ln_deaths_t1", "lwc_i", var2.value = 1, fit_0a),
  mcce_ci_calc("ln_deaths_t1", "lwc_i_75", var2.value = 1, fit_0b),
  mcce_ci_calc("ln_deaths_t1", "lwc_i", var2.value = 1, fit_1),
  mcce_ci_calc("ln_deaths_t1", "lwc_i_75", var2.value = 1, fit_2),
  mcce_ci_calc("ln_deaths_t1", "lwc_i", var2.value = 1, fit_3),
  mcce_ci_calc("ln_deaths_t1", "lwc_i_75", var2.value = 1, fit_4) )%>%
  as.data.frame() %>%
  dplyr::select(beta, std.error) %>%
  round(3) %>%
  t()

## Estimates for large-coalition, regular removal
lwc_r_estimates <- rbind(
  mcce_ci_calc("ln_deaths_t1", "lwc_r", var2.value = 1, fit_0a),
  mcce_ci_calc("ln_deaths_t1", "lwc_r_75", var2.value = 1, fit_0b),
  mcce_ci_calc("ln_deaths_t1", "lwc_r", var2.value = 1, fit_1),
  mcce_ci_calc("ln_deaths_t1", "lwc_r_75", var2.value = 1, fit_2),
  mcce_ci_calc("ln_deaths_t1", "lwc_r", var2.value = 1, fit_3),
  mcce_ci_calc("ln_deaths_t1", "lwc_r_75", var2.value = 1, fit_4)) %>%
  as.data.frame() %>%
  dplyr::select(beta, std.error) %>%
  round(3) %>%
  t()

## Bind estimates together
int_ests <- rbind(small_estimates, lwc_i_estimates, lwc_r_estimates)


rownames(int_ests) <- c("Small-Coalition",
                        "",
                        "Large-Coalition, Irregular Removal",
                        "",
                        "Large-Coalition, Regular Removal",
                        "")

## Function to add parentheses around estimated standard errors
parentheses <- function (x) {
  return (paste("(", x, ")", sep = ""))
}

## Use function to add parentheses
for(i in c(2, 4, 6)){
  int_ests[i, ] <- parentheses(int_ests[i, ])
}

## Table of just the interaction terms
stargazer(
  int_ests,
  title = paste0("Marginal Effect of Disasters on Conflict ",
                 "Initiation by Coalition Size, 1950 - 2007"),
  out = c("tables/interaction-estimates-main.tex",
          "tables/interaction-estimates-main.html")
)

## Table of everything else
stargazer(fit_0a, fit_0b, fit_1, fit_2, fit_3, fit_4,
          omit = "year",
          font.size = "footnotesize",
          notes = c("Estimated standard errors in parentheses.", 
                    "Negative binomial regression models.",
                    "All models include CINC score, land area (sq. km, log), real GDP (log), time in office, peace years, and year dummies. "),
          #float.env = "sidewaystable", ## Uncomment this for PDF
          out = c("tables/table-1-estimates-main.tex",
                  "tables/table-1-estimates-main.html"))

## Note: I add the p-value stars manually after pasting the two tables together
mcce_ci_calc("ln_deaths_t1", "lwc_i", var2.value = 1, fit_0a)
mcce_ci_calc("ln_deaths_t1", "lwc_i_75", var2.value = 1, fit_0b)
mcce_ci_calc("ln_deaths_t1", "lwc_i", var2.value = 1, fit_1)
mcce_ci_calc("ln_deaths_t1", "lwc_i_75", var2.value = 1, fit_2)
mcce_ci_calc("ln_deaths_t1", "lwc_i", var2.value = 1, fit_3)
mcce_ci_calc("ln_deaths_t1", "lwc_i_75", var2.value = 1, fit_4)

mcce_ci_calc("ln_deaths_t1", "lwc_r", var2.value = 1, fit_0a)
mcce_ci_calc("ln_deaths_t1", "lwc_r_75", var2.value = 1, fit_0b)
mcce_ci_calc("ln_deaths_t1", "lwc_r", var2.value = 1, fit_1)
mcce_ci_calc("ln_deaths_t1", "lwc_r_75", var2.value = 1, fit_2)
mcce_ci_calc("ln_deaths_t1", "lwc_r", var2.value = 1, fit_3)
mcce_ci_calc("ln_deaths_t1", "lwc_r_75", var2.value = 1, fit_4)




#------------------------------------------------------------------------------
# Earthquake models
#------------------------------------------------------------------------------

# Model 0a: Earthquake events only, base
fit_0_eq <- glm.nb(mids_init ~ eq_events_t1*lwc_r + eq_events_t1*lwc_i + 
                     cinc + ln_land + ln_realgdp + pop, 
                   data = leaders, na.action = "na.omit")

fit_1_eq <- glm.nb(mids_init ~ eq_events_t1*lwc_r + eq_events_t1*lwc_i + 
                     cinc + ln_land + ln_realgdp + pop +
                     leader_tenure + peace_yrs_mid + 
                     factor(year), 
                   data = leaders, na.action = "na.omit")

fit_2_eq <- glm.nb(hh_mids_init ~ eq_events_t1*lwc_r + eq_events_t1*lwc_i + 
                     cinc + ln_land + ln_realgdp + pop, 
                   data = leaders, na.action = "na.omit")

fit_3_eq <- glm.nb(hh_mids_init ~ eq_events_t1*lwc_r + eq_events_t1*lwc_i + 
                     cinc + ln_land + ln_realgdp + pop +
                     leader_tenure + peace_yrs_mid + 
                     factor(year), 
                   data = leaders, na.action = "na.omit")



## Estimates for small-coalition regimes (baseline)
## Note that this is the same as for the lwc_i regimes but with var2.value = 0.
small_estimates <- rbind(
  mcce_ci_calc("eq_events_t1", "lwc_i", var2.value = 0, fit_0_eq),
  mcce_ci_calc("eq_events_t1", "lwc_i", var2.value = 0, fit_1_eq),
  mcce_ci_calc("eq_events_t1", "lwc_i", var2.value = 0, fit_2_eq),
  mcce_ci_calc("eq_events_t1", "lwc_i", var2.value = 0, fit_3_eq) )%>%
  as.data.frame() %>%
  dplyr::select(beta, std.error) %>%
  round(3) %>%
  t()

## Estimates for large-coalition, irregular removal
lwc_i_estimates <- rbind(
  mcce_ci_calc("eq_events_t1", "lwc_i", var2.value = 1, fit_0_eq),
  mcce_ci_calc("eq_events_t1", "lwc_i", var2.value = 1, fit_1_eq),
  mcce_ci_calc("eq_events_t1", "lwc_i", var2.value = 1, fit_2_eq),
  mcce_ci_calc("eq_events_t1", "lwc_i", var2.value = 1, fit_3_eq) )%>%
  as.data.frame() %>%
  dplyr::select(beta, std.error) %>%
  round(3) %>%
  t()

## Estimates for large-coalition, regular removal
lwc_r_estimates <- rbind(
  mcce_ci_calc("eq_events_t1", "lwc_r", var2.value = 1, fit_0_eq),
  mcce_ci_calc("eq_events_t1", "lwc_r", var2.value = 1, fit_1_eq),
  mcce_ci_calc("eq_events_t1", "lwc_r", var2.value = 1, fit_2_eq),
  mcce_ci_calc("eq_events_t1", "lwc_r", var2.value = 1, fit_3_eq) ) %>%
  as.data.frame() %>%
  dplyr::select(beta, std.error) %>%
  round(3) %>%
  t()


## Bind estimates together
int_ests <- rbind(small_estimates, lwc_i_estimates, lwc_r_estimates)


rownames(int_ests) <- c("Small-Coalition",
                        "",
                        "Large-Coalition, Irregular Removal",
                        "",
                        "Large-Coalition, Regular Removal",
                        "")

## Add parentheses (see above for function)
for(i in c(2, 4, 6)){
  int_ests[i, ] <- parentheses(int_ests[i, ])
}



## Interaction coefficient table output
stargazer(
  int_ests,
  title = paste0("Marginal Effect of Earthquake Events ",
                 "on Conflict Initiation by Coalition Size, 1950 - 2007"),
  out = c("tables/interaction-estimates-earthquakes.tex",
          "tables/interaction-estimates-earthquakes.html"))

## Other coefficient estimates
stargazer(
  fit_0_eq, fit_1_eq, fit_2_eq, fit_3_eq,
  omit = "year",
  font.size = "footnotesize",
  notes = c(
    "Estimated standard errors in parentheses.", 
    "Negative binomial regression models.",
    "All models include CINC score, land area (sq. km, log), and real GDP (log).",
    "Models 2 and 4 include time in office, peace years, and year dummies. "
  ),
  out = c("tables/main-estimates-earthquakes.tex",
          "tables/main-estimates-earthquakes.html"))

## Note: I add the p-values manually after pasting the two tables together
mcce_ci_calc("eq_events_t1", "lwc_i", var2.value = 1, fit_0_eq)
mcce_ci_calc("eq_events_t1", "lwc_i", var2.value = 1, fit_1_eq)
mcce_ci_calc("eq_events_t1", "lwc_i", var2.value = 1, fit_2_eq)
mcce_ci_calc("eq_events_t1", "lwc_i", var2.value = 1, fit_3_eq)

mcce_ci_calc("eq_events_t1", "lwc_r", var2.value = 1, fit_0_eq)
mcce_ci_calc("eq_events_t1", "lwc_r", var2.value = 1, fit_1_eq)
mcce_ci_calc("eq_events_t1", "lwc_r", var2.value = 1, fit_2_eq)
mcce_ci_calc("eq_events_t1", "lwc_r", var2.value = 1, fit_3_eq)

## Small coalition
mcce_ci_calc("eq_events_t1", "lwc_i", var2.value = 0, fit_0_eq)
mcce_ci_calc("eq_events_t1", "lwc_i", var2.value = 0, fit_1_eq)
mcce_ci_calc("eq_events_t1", "lwc_i", var2.value = 0, fit_2_eq)
mcce_ci_calc("eq_events_t1", "lwc_i", var2.value = 0, fit_3_eq)




#------------------------------------------------------------------------------
# Small-coalition models
#------------------------------------------------------------------------------

small_r_fit <- glm.nb(mids_init ~ ln_events_t1 + ln_deaths_t1 + 
                        cinc + ln_land + ln_realgdp + pop +
                        leader_tenure + peace_yrs_mid, 
                      data = leaders[leaders$small_r == 1,], 
                      na.action = "na.omit")


small_i_fit <- glm.nb(mids_init ~ ln_events_t1 + ln_deaths_t1 + 
                        cinc + ln_land + ln_realgdp + pop +
                        leader_tenure + peace_yrs_mid, 
                      data = leaders[leaders$small_i == 1,], 
                      na.action = "na.omit")


var_names <- c("Disaster Events (log)",
               "Disaster Deaths (log)",
               "CINC",
               "Land area (sq. km.)",
               "Real GDP (log)",
               "Leader Tenure",
               "Population",
               "Peace Years")

stargazer(
  small_r_fit, small_i_fit,
  omit = "year",
  title = "Disasters, Removal Type, and Conflict in Small-Coalition Regimes",
  label = "small-coalition-models",
  covariate.labels = var_names,
  dep.var.caption = "Dependent variable: MIDs Initiated",
  dep.var.labels = "",
  column.labels = c("Regular Removal", "Irregular Removal"),
  notes.align = "l",
  notes.label = "",
  notes = c("Estimated standard errors in parentheses.", 
            "Negative binomial regression models.",
            "All models include CINC score, land area (sq. km, log),",
            "real GDP (log), population, time in office, and peace years."),
  out = c("tables/table-3-small-coalition.tex",
          "tables/table-3-small-coalition.html")
)
