# This script is for the simulations of expected counts figure
# (Figure 2) in "Leader Survival, Sources of Political Insecurity,
# and International Conflict"
# Last updated 02/17/2016

load("~/Dropbox/Dissertation/Chapters/Chapter 2 - Leader Survival, Natural Disasters, and International Conflict/Data and Scripts/lsndic-data-lagged-ivs-archigos-4.RData")

require(MASS)
library(car)
library(lmtest)
library(multiwayvcov)
library(dplyr)

########### Model 1
## Model 1
fit_1 <- glm.nb(mids_init ~ ln_deaths_t1 * lwc_r + 
                  ln_deaths_t1 * lwc_i +
                  cinc + ln_land + ln_realgdp + pop, 
                data = leaders, 
                na.action = "na.omit")

###########  Model 2
fit_2 <- glm.nb(mids_init ~ ln_deaths_t1 * lwc_r_75 + 
                  ln_deaths_t1 * lwc_i_75 +
                  cinc + ln_land + ln_realgdp + pop, 
                data = leaders, 
                na.action = "na.omit")

########### Model 3

fit_3 <- glm.nb(mids_init ~ eq_events_t1*lwc_r + eq_events_t1*lwc_i + 
                  cinc + ln_land + ln_realgdp + pop, 
                data = leaders, 
                na.action = "na.omit")

# Get simulated coefficients
sim_coefs_fit_1 <- mvrnorm(n = 10000, mu = coef(fit_1), Sigma = vcov(fit_1))
sim_coefs_fit_2 <- mvrnorm(n = 10000, mu = coef(fit_2), Sigma = vcov(fit_2))
sim_coefs_fit_3 <- mvrnorm(n = 10000, mu = coef(fit_3), Sigma = vcov(fit_3))



# Create vectors of means for Model 1
lci_cinc_mean <- mean(leaders$cinc[leaders$lwc_i == 1], 
                      na.rm = TRUE)

lci_ln_land_mean <- mean(leaders$ln_land[leaders$lwc_i == 1], 
                         na.rm = TRUE)

lci_ln_realgdp_mean <- mean(leaders$ln_realgdp[leaders$lwc_i == 1], 
                            na.rm = TRUE)

lci_pop_mean <- mean(leaders$pop[leaders$lwc_i == 1], 
                     na.rm = TRUE)

lci_ln_deaths_t1_mean <- mean(leaders$ln_deaths_t1[leaders$lwc_i == 1], 
                              na.rm = TRUE)

lci_ln_deaths_t1_sd <- sd(leaders$ln_deaths_t1[leaders$lwc_i == 1], 
                          na.rm = TRUE)


lcr_cinc_mean <- mean(leaders$cinc[leaders$lwc_r == 1], 
                      na.rm = TRUE)
lcr_ln_land_mean <- mean(leaders$ln_land[leaders$lwc_r == 1], 
                         na.rm = TRUE)
lcr_ln_realgdp_mean <- mean(leaders$ln_realgdp[leaders$lwc_r == 1], 
                            na.rm = TRUE)
lcr_pop_mean <- mean(leaders$pop[leaders$lwc_r == 1], 
                     na.rm = TRUE)

lcr_ln_deaths_t1_mean <- mean(leaders$ln_deaths_t1[leaders$lwc_r==1], na.rm = TRUE)
lcr_ln_deaths_t1_sd <- sd(leaders$ln_deaths_t1[leaders$lwc_r==1], na.rm = TRUE)


# From mean to 1 st. dev. above. Large-coalition, irregular removal
lci_v1 <- c(lci_ln_deaths_t1_mean, 0, 1, lci_cinc_mean, lci_ln_land_mean, lci_ln_realgdp_mean, lci_pop_mean, 0, lci_ln_deaths_t1_mean)

lci_v2 <- c(lci_ln_deaths_t1_mean + lci_ln_deaths_t1_sd, 0, 1, lci_cinc_mean, lci_ln_land_mean, lci_ln_realgdp_mean, lci_pop_mean, 0, lci_ln_deaths_t1_mean + lci_ln_deaths_t1_sd)

# Large-coalition, regular removal
lcr_v1 <- c(lcr_ln_deaths_t1_mean, 0, 1, lcr_cinc_mean, lcr_ln_land_mean, lcr_ln_realgdp_mean, lcr_pop_mean, 0, lcr_ln_deaths_t1_mean)

lcr_v2 <- c(lcr_ln_deaths_t1_mean + lcr_ln_deaths_t1_sd, 0, 1, lcr_cinc_mean, lcr_ln_land_mean, lcr_ln_realgdp_mean, lcr_pop_mean, 0, lcr_ln_deaths_t1_mean + lcr_ln_deaths_t1_sd)






# Create vectors of means for Model 2
lci_75_cinc_mean <- mean(leaders$cinc[leaders$lwc_i_75 == 1], 
                         na.rm = TRUE)

lci_75_ln_land_mean <- mean(leaders$ln_land[leaders$lwc_i_75 == 1], 
                            na.rm = TRUE)

lci_75_ln_realgdp_mean <- mean(leaders$ln_realgdp[leaders$lwc_i_75 == 1], 
                               na.rm = TRUE)

lci_75_pop_mean <- mean(leaders$pop[leaders$lwc_i_75 == 1], 
                        na.rm = TRUE)


lci_75_ln_deaths_t1_mean <- mean(leaders$ln_deaths_t1[leaders$lwc_i_75 == 1], 
                                 na.rm = TRUE)

lci_75_ln_deaths_t1_sd <- sd(leaders$ln_deaths_t1[leaders$lwc_i_75 == 1], 
                             na.rm = TRUE)


lcr_75_cinc_mean <- mean(leaders$cinc[leaders$lwc_r_75 == 1], 
                         na.rm = TRUE)
lcr_75_ln_land_mean <- mean(leaders$ln_land[leaders$lwc_r_75 == 1], 
                            na.rm = TRUE)
lcr_75_ln_realgdp_mean <- mean(leaders$ln_realgdp[leaders$lwc_r_75 == 1], 
                               na.rm = TRUE)
lcr_75_pop_mean <- mean(leaders$pop[leaders$lwc_r_75 == 1], 
                        na.rm = TRUE)

lcr_75_ln_deaths_t1_mean <- mean(leaders$ln_deaths_t1[leaders$lwc_r_75 == 1], 
                                 na.rm = TRUE)
lcr_75_ln_deaths_t1_sd <- sd(leaders$ln_deaths_t1[leaders$lwc_r_75 == 1], 
                             na.rm = TRUE)


# From mean to 1 st. dev. above. Large-coalition, irregular removal
lci_75_v1 <- c(lci_75_ln_deaths_t1_mean, 0, 1, lci_75_cinc_mean, lci_75_ln_land_mean, lci_75_ln_realgdp_mean, lci_75_pop_mean, 0, lci_75_ln_deaths_t1_mean)

lci_75_v2 <- c(lci_75_ln_deaths_t1_mean + lci_75_ln_deaths_t1_sd, 0, 1, lci_75_cinc_mean, lci_75_ln_land_mean, lci_75_ln_realgdp_mean, lci_75_pop_mean, 0, lci_75_ln_deaths_t1_mean + lci_75_ln_deaths_t1_sd)

# Large-coalition, regular removal
lcr_75_v1 <- c(lcr_75_ln_deaths_t1_mean, 0, 1, lcr_75_cinc_mean, lcr_75_ln_land_mean, lcr_75_ln_realgdp_mean, lcr_75_pop_mean, 0, lcr_75_ln_deaths_t1_mean)

lcr_75_v2 <- c(lcr_75_ln_deaths_t1_mean + lcr_75_ln_deaths_t1_sd, 0, 1, lcr_75_cinc_mean, lcr_75_ln_land_mean, lcr_75_ln_realgdp_mean, lcr_75_pop_mean, 0, lcr_75_ln_deaths_t1_mean + lcr_75_ln_deaths_t1_sd)








# Create vectors of means for Model 3 (Earthquakes) other vectors stay the same

# From 0 to 1 earthquake large-coalition, irregular removal
lci_eq_v1 <- c(0, 0, 1, lci_cinc_mean, lci_ln_land_mean, lci_ln_realgdp_mean, lci_pop_mean, 0, 0)
lci_eq_v2 <- c(1, 0, 1, lci_cinc_mean, lci_ln_land_mean, lci_ln_realgdp_mean, lci_pop_mean, 0, 1)

# From 0 to 1 earthquake large-coalition, regular removal
lcr_eq_v1 <- c(0, 0, 1, lcr_cinc_mean, lcr_ln_land_mean, lcr_ln_realgdp_mean, lcr_pop_mean, 0, 0)
lcr_eq_v2 <- c(1, 0, 1, lcr_cinc_mean, lcr_ln_land_mean, lcr_ln_realgdp_mean, lcr_pop_mean, 0, 1)



lci_change_fit_1 <- c()
lcr_change_fit_1 <- c()
lci_75_change_fit_2 <- c()
lcr_75_change_fit_2 <- c()
lci_eq_change_fit_3 <- c()
lcr_eq_change_fit_3 <- c()

for(i in 1:nrow(sim_coefs_fit_1)){
  
  # Model 1
  lci_count_0 <- exp(
    sim_coefs_fit_1[i, 1] + sum(sim_coefs_fit_1[i, 2:10]*lci_v1[1:9])
  )
  
  lci_count_mean <- exp(sim_coefs_fit_1[i, 1] + sum(sim_coefs_fit_1[i, 2:10]*lci_v2[1:9]))
  lci_change_fit_1[i] <- lci_count_mean - lci_count_0 
  
  lcr_count_0 <- exp(sim_coefs_fit_1[i, 1] + sum(sim_coefs_fit_1[i, 2:10]*lcr_v1[1:9]))
  lcr_count_mean <- exp(sim_coefs_fit_1[i, 1] + sum(sim_coefs_fit_1[i, 2:10]*lcr_v2[1:9]))
  lcr_change_fit_1[i] <- lcr_count_mean - lcr_count_0 
  
  # Model 2
  lci_count_0 <- exp(sim_coefs_fit_2[i, 1] + sum(sim_coefs_fit_2[i, 2:10]*lci_75_v1[1:9]))
  lci_count_mean <- exp(sim_coefs_fit_2[i, 1] + sum(sim_coefs_fit_2[i, 2:10]*lci_75_v2[1:9]))
  lci_75_change_fit_2[i] <- lci_count_mean - lci_count_0 
  
  lcr_count_0 <- exp(sim_coefs_fit_2[i, 1] + sum(sim_coefs_fit_2[i, 2:10]*lcr_75_v1[1:9]))
  lcr_count_mean <- exp(sim_coefs_fit_2[i, 1] + sum(sim_coefs_fit_2[i, 2:10]*lcr_75_v2[1:9]))
  lcr_75_change_fit_2[i] <- lcr_count_mean - lcr_count_0
  
  
  # Model 3
  lci_count_0 <- exp(sim_coefs_fit_3[i, 1] + sum(sim_coefs_fit_3[i, 2:10]*lci_eq_v1[1:9]))
  lci_count_mean <- exp(sim_coefs_fit_3[i, 1] + sum(sim_coefs_fit_3[i, 2:10]*lci_eq_v2[1:9]))
  lci_eq_change_fit_3[i] <- lci_count_mean - lci_count_0 
  
  lcr_count_0 <- exp(sim_coefs_fit_3[i, 1] + sum(sim_coefs_fit_3[i, 2:10]*lcr_eq_v1[1:9]))
  lcr_count_mean <- exp(sim_coefs_fit_3[i, 1] + sum(sim_coefs_fit_3[i, 2:10]*lcr_eq_v2[1:9]))
  lcr_eq_change_fit_3[i] <- lcr_count_mean - lcr_count_0 
  
}



quantile(lci_change_fit_1, c(0.025, 0.975))
quantile(lci_change_fit_1, c(0.05, 0.95))
quantile(lci_change_fit_1, c(0.1, 0.9))

quantile(lcr_change_fit_1, c(0.025, 0.975))
quantile(lcr_change_fit_1, c(0.05, 0.95))
quantile(lcr_change_fit_1, c(0.1, 0.9))


quantile(lci_75_change_fit_2, c(0.025, 0.975))
quantile(lci_75_change_fit_2, c(0.05, 0.95))
quantile(lci_75_change_fit_2, c(0.1, 0.9))

quantile(lcr_75_change_fit_2, c(0.025, 0.975))
quantile(lcr_75_change_fit_2, c(0.05, 0.95))
quantile(lcr_75_change_fit_2, c(0.1, 0.9))

quantile(lci_eq_change_fit_3, c(0.025, 0.975))
quantile(lci_eq_change_fit_3, c(0.05, 0.95))
quantile(lci_eq_change_fit_3, c(0.1, 0.9))

quantile(lcr_eq_change_fit_3, c(0.025, 0.975))
quantile(lcr_eq_change_fit_3, c(0.05, 0.95))
quantile(lcr_eq_change_fit_3, c(0.1, 0.9))


lci_means <- c(mean(lci_change_fit_1), mean(lci_75_change_fit_2), mean(lci_eq_change_fit_3))
lcr_means <- c(mean(lcr_change_fit_1), mean(lcr_75_change_fit_2), mean(lcr_eq_change_fit_3))


y1 <- c(3, 2, 1)
y2 <- c(2.7, 1.7, .7)

# All for the plot
require(tikzDevice)
tikz("~/Dropbox/article-manuscripts/leaders-prq/simulated-expected-counts-final.tex")

par(oma = c(4, 5, 0, 0), mar = rep(3, 4))

plot(lci_means,y1,
     xlim=c(-0.01,.18),
     ylim=c(0.5,3.25),
     pch=16,
     main = "Change in Expected Count of MIDs for \n Large-Coalition Leaders",
     xlab = "Change in Expect Count of MIDs",
     ylab = "",
     yaxt = 'n',
     cex=1.5)

axis(2, at=c(3,2,1), labels=c("Model 1","Model 2 \n (W $\\geq$ 0.75)","Model 7 \n (Earthquake)"),las=1,cex=.15)
segments(0,0,0,3.5, lty="dotted")
points(lcr_means, y2, pch=5, cex=1.5)
segments(quantile(lci_change_fit_1, c(0.025, 0.975))[1], 
         y1[1],
         quantile(lci_change_fit_1, c(0.025, 0.975))[2],
         y1[1],
         lwd=2)
segments(quantile(lci_change_fit_1, c(0.05, 0.95))[1],
         y1[1],
         quantile(lci_change_fit_1, c(0.05, 0.95))[2],
         y1[1],
         lwd=5)
segments(quantile(lci_change_fit_1, c(0.1, 0.9))[1], 
         y1[1],
         quantile(lci_change_fit_1, c(0.1, 0.9))[2],
         y1[1],
         lwd=10)

segments(quantile(lcr_change_fit_1, c(0.025, 0.975))[1],
         y2[1],
         quantile(lcr_change_fit_1, c(0.025, 0.975))[2],
         y2[1],
         lwd=2)
segments(quantile(lcr_change_fit_1, c(0.05, 0.95))[1], 
         y2[1],
         quantile(lcr_change_fit_1, c(0.05, 0.95))[2],
         y2[1],
         lwd=5)
segments(quantile(lcr_change_fit_1, c(0.1, 0.9))[1], 
         y2[1],
         quantile(lcr_change_fit_1, c(0.1, 0.9))[2],
         y2[1],
         lwd=10)

segments(quantile(lci_75_change_fit_2, c(0.025, 0.975))[1], 
         y1[2],
         quantile(lci_75_change_fit_2, c(0.025, 0.975))[2],
         y1[2],
         lwd=2)
segments(quantile(lci_75_change_fit_2, c(0.05, 0.95))[1], 
         y1[2],
         quantile(lci_75_change_fit_2, c(0.05, 0.95))[2],
         y1[2],
         lwd=5)
segments(quantile(lci_75_change_fit_2, c(0.1, 0.9))[1], 
         y1[2],
         quantile(lci_75_change_fit_2, c(0.1, 0.9))[2],
         y1[2],
         lwd=10)

segments(quantile(lcr_75_change_fit_2, c(0.025, 0.975))[1], 
         y2[2],
         quantile(lcr_75_change_fit_2, c(0.025, 0.975))[2],
         y2[2],
         lwd=2)
segments(quantile(lcr_75_change_fit_2, c(0.05, 0.95))[1],
         y2[2],
         quantile(lcr_75_change_fit_2, c(0.05, 0.95))[2],
         y2[2],
         lwd=5)
segments(quantile(lcr_75_change_fit_2, c(0.1, 0.9))[1],
         y2[2],
         quantile(lcr_75_change_fit_2, c(0.1, 0.9))[2],
         y2[2],
         lwd=10)


segments(quantile(lci_eq_change_fit_3, c(0.025, 0.975))[1], 
         y1[3],
         quantile(lci_eq_change_fit_3, c(0.025, 0.975))[2],
         y1[3],
         lwd=2)
segments(quantile(lci_eq_change_fit_3, c(0.05, 0.95))[1],
         y1[3],
         quantile(lci_eq_change_fit_3, c(0.05, 0.95))[2],
         y1[3], 
         lwd=5)
segments(quantile(lci_eq_change_fit_3, c(0.1, 0.9))[1],
         y1[3],
         quantile(lci_eq_change_fit_3, c(0.1, 0.9))[2],
         y1[3], 
         lwd=10)

segments(quantile(lcr_eq_change_fit_3, c(0.025, 0.975))[1],
         y2[3],
         quantile(lcr_eq_change_fit_3, c(0.025, 0.975))[2],
         y2[3],
         lwd=2)
segments(quantile(lcr_eq_change_fit_3, c(0.05, 0.95))[1],
         y2[3],
         quantile(lcr_eq_change_fit_3, c(0.05, 0.95))[2],
         y2[3],
         lwd=5)
segments(quantile(lcr_eq_change_fit_3, c(0.1, 0.9))[1],
         y2[3],
         quantile(lcr_eq_change_fit_3, c(0.1, 0.9))[2],
         y2[3],
         lwd=10)

legend(0.1, 3.25, 
       c("Irregular Removal", "Regular Removal"),
       pch=c(16, 5),
       cex=1,
       bty="n")

dev.off()





# Expected counts for individual models before characterizing uncertainty
# Model 1
a <- exp(coef(fit_1)[1]+sum(coef(fit_1)[2:10]*lci_v1[1:9]))
b <- exp(coef(fit_1)[1]+sum(coef(fit_1)[2:10]*lci_v2[1:9]))

(b-a)/a*100

a <- exp(coef(fit_1)[1]+sum(coef(fit_1)[2:10]*lcr_v1[1:9]))
b <- exp(coef(fit_1)[1]+sum(coef(fit_1)[2:10]*lcr_v2[1:9]))

(b-a)/a*100


# Model 2
a <- exp(coef(fit_2)[1]+sum(coef(fit_2)[2:10]*lci_75_v1[1:9]))
b <- exp(coef(fit_2)[1]+sum(coef(fit_2)[2:10]*lci_75_v2[1:9]))

(b-a)/a*100

a <- exp(coef(fit_2)[1]+sum(coef(fit_2)[2:10]*lcr_75_v1[1:9]))
b <- exp(coef(fit_2)[1]+sum(coef(fit_2)[2:10]*lcr_75_v2[1:9]))

(b-a)/a*100



# Model 3
a <- exp(coef(fit_3)[1] + sum(coef(fit_3)[2:10]*lci_eq_v1[1:9]))
b <- exp(coef(fit_3)[1]+sum(coef(fit_3)[2:10]*lci_eq_v2[1:9]))

(b-a)/a*100

a <- exp(coef(fit_3)[1]+sum(coef(fit_3)[2:10]*lcr_eq_v1[1:9]))
b <- exp(coef(fit_3)[1]+sum(coef(fit_3)[2:10]*lcr_eq_v2[1:9]))

(b-a)/a*100
