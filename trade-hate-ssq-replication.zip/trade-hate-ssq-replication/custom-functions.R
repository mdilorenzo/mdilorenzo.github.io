## Calculate significance of interaction term
mcce_ci_calc <- function(var1, var2, var2.value, 
                         model,
                         model_vcov = vcov(model)){
  
  b1_var <- model_vcov[var1, var1]
  
  int_var <- names(coef(model))[
    grepl(var1, names(coef(model))) & grepl(var2, names(coef(model)))
  ]
  
  b3_var <- model_vcov[int_var, int_var]
  b1b3_covar <- model_vcov[var1, int_var] 
  
  se <- sqrt(b1_var + (var2.value^2)*b3_var + 2*var2.value*b1b3_covar)
  MCCE <- summary(model)$coefficients[var1, 1] + 
    var2.value*summary(model)$coefficients[int_var, 1]
  
  return(c(var2.value = var2.value, 
           beta = MCCE, 
           std.error = se, 
           ci.95.lower = MCCE - 1.96 * se, 
           ci.95.upper = MCCE + 1.96 * se,
           ci.90.lower = MCCE - 1.645 * se, 
           ci.90.upper = MCCE + 1.645 * se))
  
}
