#-----------------------------------------------------------------------
# Title: Statistical models for "Trade Layoffs and Hate in the United States"
# Author: Matt DiLorenzo
# Contact: mdiloren@odu.edu
# Institution: Old Dominion University
# Date: Monday December 28, 2020
# Description: This script replicates the models in the main text and
# appendix of the paper.
# ----------------------------------------------------------------------

library(tidyverse)
library(readxl)
library(countrycode)
library(foreign)
library(stargazer)
library(xtable)
library(plm)

## Set working directory to replication folder
setwd("~/Dropbox/working-papers/hate-globalization/data")

## Load custom functions
source("custom-functions.R")

dat <- read.csv("analysis-data-11282020.csv",
                stringsAsFactors = FALSE)

dat$state_county <- paste0(dat$NAME_1, "-", dat$NAME_2)

## Make pdata.frame
pdat <- pdata.frame(dat,
                    index = c("state_county", "year"))


#-----------------------------------------------------------------------
# Descriptive statistics
#-----------------------------------------------------------------------

summary_data <- dat %>%
  mutate(log_all_hate = log(all_foreign_hate_incidents + 1)) %>% 
  dplyr::select(
    log_all_hate,
    total_hate_2,
    total_trade_layoffs_t1,
    log_ipopulation_est,
    nighttime_lights_t1,
    pct_white_t1,
    republican_last,
    unemployment_rate
  )


table_names <- c(
  "log(Hate incidents + 1)",
  "Number of hate groups",
  "Trade layoffs",
  "Population (log, interpolated)",
  "Nighttime luminosity",
  "Percent white population",
  "Percent voting Republican in most recent election",
  "Unemployment rate"
)

getwd()
stargazer(summary_data,
          covariate.labels = table_names,
          title = "Descriptive statistics for key variables",
          label = "descriptives",
          font.size = "scriptsize",
          summary.stat = c("n", "mean", "sd", "min", "median", "max"),
          out = "../tables/descriptives.tex")



## Correlation matrix for IVs

cor_matrix <- dat %>%
  dplyr::select(total_trade_layoffs_t1,
                log_ipopulation_est,
                nighttime_lights_t1,
                pct_white_t1,
                unemployment_rate,
                republican_last
  ) %>%
  set_names(c("Trade layoffs",
              "Population",
              "Nighttime light",
              "Pct. white",
              "Unemployment rate",
              "Pct. Republican"
  )) %>%
  cor(.,
      use = "pairwise.complete.obs")


cor_matrix

stargazer(cor_matrix,
          title = "Correlations between key independent variables",
          label = "cor-matrix",
          font.size = "tiny",
          out = c("../tables/cor-matrix.tex",
                  "../tables/cor-matrix.html"))


#-----------------------------------------------------------------------
# Table 1
#-----------------------------------------------------------------------

pool_1 <- plm(I(log(all_foreign_hate_incidents + 1)) ~ 
                
                ## Key variable
                total_trade_layoffs_t1 +

                ## Lagged DV
                I(log(all_foreign_hate_incidents_t1 + 1)) +
                
                ## Very within counties over time
                log_ipopulation_est + 
                nighttime_lights_t1 +
                pct_white_t1 +
                unemployment_rate_t1 +
                republican_last +
                
                ## Dummies
                factor(NAME_1) +
                factor(year) - 1,
              
              data = pdat,
              model = "pooling")


fd_1 <- update(pool_1, model = "fd")


pool_2 <- plm(total_hate_2 ~ 
                
                ## Key variable
                total_trade_layoffs_t1 +

                ## Lagged DV
                total_hate_2_t1 +
                
                ## Very within counties over time
                log_ipopulation_est + 
                nighttime_lights_t1 +
                pct_white_t1 +
                unemployment_rate_t1 +
                republican_last +
                
                ## Dummies 
                factor(NAME_1) +
                factor(year) - 1,
              
              data = pdat,
              model = "pooling")

fd_2 <- update(pool_2, model = "fd")

table_1_models <- list(pool_1, fd_1, pool_2, fd_2)

## Get PCSEs
for(i in 1:length(table_1_models)){
  
  table_1_models[[i]]$vcov <- vcovBK(table_1_models[[i]], type = "HC1")
  
}

table_1_n_units <- sapply(table_1_models,
                     function(x)
                       pdim(x)$nT$n)



stargazer(
  table_1_models,
  omit = c("factor", "foreign", "Constant", "hate"),
  covariate.labels = c(
    "Trade layoffs",
    "Population (log, interpolated)",
    "Nighttime luminosity",
    "Percent white population",
    "Unemployment rate",
    "Percent voting Republican in most recent election"
  ),
  p.auto = TRUE,
  dep.var.labels = c("Hate crimes",
                     "Hate groups"),
  dep.var.labels.include = TRUE,
  title = "Hate crimes, hate groups, and trade layoffs",
  label = "table-1",
  add.lines = list(
    c("N. counties", table_1_n_units),
    c("First-differenced?", "N", "Y", "N", "Y")
  ),
  font.size = "scriptsize",
  no.space = TRUE,
  notes.append = TRUE,
  notes.align = "l",
  notes.label = "",
  notes = c(
    "Note: Panel-corrected standard errors in parentheses.",
    "Year dummies and lagged (1-period) outcome included in all models.",
    "State dummies included in Models 1 and 3."
  ),
  digits = 3,
  omit.stat = c("f", "rsq", "adj.rsq"),
  out = c("../tables/table-1-models.tex",
          "../tables/table-1-models.html")
)



#-----------------------------------------------------------------------
# Table 2: Interaction models
#-----------------------------------------------------------------------


## Interaction models
interaction_fit_crime <- plm(
  I(log(all_foreign_hate_incidents + 1)) ~ 
    
    ## Key variable
    total_trade_layoffs_t1 * change_pct_white_t1 +
    
    ## Lagged DV
    I(log(all_foreign_hate_incidents_t1 + 1)) +
    
    ## Vary within counties
    log_ipopulation_est +
    nighttime_lights_t1 +
    unemployment_rate_t1 +
    republican_last,
  
  data = pdat,
  model = "within",
  effect = "twoways"
)

interaction_fit_groups <- plm(
  total_hate_2 ~ 
    
    ## Key variable
    (total_trade_layoffs_t1 * change_pct_white_t1) + 
    
    ## Lagged DV
    total_hate_2_t1 +
    
    ## Vary within counties
    log_ipopulation_est +
    nighttime_lights_t1 +
    unemployment_rate_t1 + 
    republican_last,
  
  data = pdat,
  model = "within",
  effect = "twoways"
)



interaction_models <- list(interaction_fit_crime, interaction_fit_groups)

## Get PCSEs
for(i in 1:length(interaction_models)){
  
  interaction_models[[i]]$vcov <- vcovBK(interaction_models[[i]], 
                                         type = "HC1")
  
}

interaction_n_units <- sapply(interaction_models,
                              function(x)
                                pdim(x)$nT$n)



## Interaction models table
stargazer(
  interaction_models,
  omit = c("factor", "foreign", "Constant", "hate"),
  covariate.labels = c(
    "Trade layoffs",
    "Change in percent white population",
    "Population (log, interpolated)",
    "Nighttime luminosity",
    "Unemployment rate",
    "Percent voting Republican in most recent election",
    "Trade layoffs $\\times$ Change in percent white population"),
  p.auto = TRUE,
  dep.var.labels = c("Hate crimes",
                     "Hate groups"),
  dep.var.labels.include = TRUE,
  title = "Conditioning effects of changing demographics",
  label = "interaction-table",
  add.lines = list(
    c("County FEs", "Y", "Y"),
    c("N. counties", 
      interaction_n_units)
  ),
  font.size = "scriptsize",
  no.space = TRUE,
  notes.append = TRUE,
  notes.align = "l",
  notes.label = "",
  notes = c(
    "Note: Panel regression models.",
    "Panel-corrected standard errors in parentheses.",
    "Year dummies and lagged (1-period) outcome included in all models."
  ),
  digits = 3,
  omit.stat = c("f", "rsq", "adj.rsq"),
  out = c("../tables/interaction-models.tex",
          "../tables/interaction-models.html")
)



## Make marginal effects plots
range_white_values <- seq(
  min(dat$change_pct_white_t1, na.rm = T),
  max(dat$change_pct_white_t1, na.rm = T),
  length.out = 25
)

regular_white_values <- c(
  mean(dat$change_pct_white_t1, na.rm = T) - 2 * sd(dat$change_pct_white_t1, 
                                                    na.rm = T),
  mean(dat$change_pct_white_t1, na.rm = T) + 2 * sd(dat$change_pct_white_t1, 
                                                    na.rm = T)
)

range_white_values <- c(range_white_values,
                        regular_white_values)

## List of key variables for models
key_ivs <- c("total_trade_layoffs_t1")

## Placeholder
all_results <- list()

for(i in 1:length(interaction_models)){
  
  model_results <- c()
  
  for(j in 1:length(range_white_values)){
    
    model_results <- rbind(model_results,
                           c(
                             mcce_ci_calc("total_trade_layoffs_t1", 
                                          "change_pct_white_t1", 
                                          range_white_values[j], 
                                          interaction_models[[i]]),
                             model_number = i,
                             key_variable = "total_trade_layoffs_t1"
                           ))
    
    
    
  }
  
  model_results <- as.data.frame(model_results)
  
  all_results[[i]] <- model_results
  
}

## Combine
me_results <- do.call(rbind, all_results) %>%
  as.data.frame()


## Make numeric
me_results[ , 1:7] <- apply(me_results[ , 1:7], 2, factor2numeric)

## Labels for y-axis
iv_long <- c("trade layoffs")

## Titles
dv_long <- c("DV: log(Hate crime incidents + 1)",
             "DV: Number of hate groups present in county")


## Make plots
for(i in 1:length(interaction_models)){
  
  the_plot <- ggplot(me_results %>% 
                       subset(
                         model_number == i),
                     aes(x = var2.value,
                         y = beta,
                         ymin = ci.95.lower,
                         ymax = ci.95.upper)) +
    xlim(regular_white_values) +
    ylim(c(-.02, 0.02)) +
    geom_line() +
    geom_ribbon(alpha = .25) +
    geom_hline(yintercept = 0, lty = "dashed") +
    labs(x = "\n Change in percentage of white population (t-1)",
         y = paste0("Marginal effect of trade layoffs"),
         title = dv_long[i]) +
    theme_aiddata_plain()
  
  the_plot
  
  ggsave(filename = paste0("../figures/final-int-model-", i, ".jpeg" ), 
         plot = the_plot, 
         scale = .575)
  
}








#-----------------------------------------------------------------------
# ADH alternative measure models
#-----------------------------------------------------------------------

## Use world total import shock

fd_world_1 <- update(
  fd_1, 
  . ~ world_import_shock_3yravg_1000s + . - total_trade_layoffs_t1
)


fd_world_2 <- update(
  fd_2, 
  . ~ world_import_shock_3yravg_1000s + . - total_trade_layoffs_t1
)



## Use Chinese import shock
fd_china_1 <- update(
  fd_1, 
  . ~ china_import_shock_3yravg_1000s + . - total_trade_layoffs_t1
)


fd_china_2 <- update(
  fd_2, 
  . ~ china_import_shock_3yravg_1000s + . - total_trade_layoffs_t1
)




adh_models <- list(fd_world_1, fd_world_2, fd_china_1, fd_china_2)




## Alternative measure of import vulnerability
stargazer(
  adh_models,
  omit = c("factor", "foreign", "Constant", "hate"),
  covariate.labels = c(
    "Import shock$_{\\text{3-year avg.}}$",
    "China shock$_{\\text{3-year avg.}}$",
    "Population (log, interpolated)",
    "Nighttime luminosity",
    "Percent white population",
    "Unemployment rate",
    "Percent voting Republican in most recent election"),
  p.auto = TRUE,
  dep.var.labels = rep(c("Hate crimes",
                     "Hate groups"), 2),
  dep.var.labels.include = TRUE,
  title = "Hate crimes, hate groups, and import competition",
  label = "adh-models",
  font.size = "scriptsize",
  no.space = TRUE,
  notes.append = TRUE,
  notes.align = "l",
  notes.label = "",
  notes = c(
    "Note: Estimated standard errors in parentheses.",
    "Year dummies and lagged (1-period) outcome included in all models."
  ),
  digits = 3,
  #omit.table.layout = "n",
  omit.stat = c("f", "rsq", "adj.rsq"),
  out = c("../tables/appendix-adh-models.tex")
)



#-----------------------------------------------------------------------
# Appendix: Alternative measure of "threat": Change in Asian population
#-----------------------------------------------------------------------

interaction_fit_asian_crime <- plm(
  I(log(all_foreign_hate_incidents + 1)) ~ 
    
    ## Key variable
    total_trade_layoffs_t1 * change_pct_asian_t1 +
    
    ## Lagged DV
    I(log(all_foreign_hate_incidents_t1 + 1)) +
    
    ## Vary within counties
    log_ipopulation_est +
    nighttime_lights_t1 +
    unemployment_rate +
    republican_last,
  
  data = pdat,
  model = "within",
  effect = "twoways"
)

interaction_fit_asian_groups <- plm(
  total_hate_2 ~ 
    
    ## Key variable
    (total_trade_layoffs_t1 * change_pct_asian_t1) + 
    
    ## Lagged DV
    total_hate_2_t1 +
    
    ## Vary within counties
    log_ipopulation_est +
    nighttime_lights_t1 +
    unemployment_rate + 
    republican_last,
  
  data = pdat,
  model = "within",
  effect = "twoways"
)



interaction_models_asian <- list(interaction_fit_asian_crime, 
                                 interaction_fit_asian_groups)

## Get PCSEs
for(i in 1:length(interaction_models_asian)){
  
  interaction_models_asian[[i]]$vcov <- vcovBK(
    interaction_models_asian[[i]], 
    type = "HC1"
  )
  
}

interaction_n_units_asian <- sapply(interaction_models_asian,
                                    function(x)
                                      pdim(x)$nT$n)



## Interaction models table
stargazer(
  interaction_models_asian,
  omit = c("factor", "foreign", "Constant", "hate"),
  covariate.labels = c(
    "Trade layoffs",
    "Change in percent Asian population",
    "Population (log, interpolated)",
    "Nighttime luminosity",
    "Unemployment rate",
    "Percent voting Republican in most recent election",
    "Trade layoffs $\\times$ Change in percent Asian population"),
  p.auto = TRUE,
  dep.var.labels = c("Hate crimes",
                     "Hate groups"),
  dep.var.labels.include = TRUE,
  title = "Conditioning effects of changing demographics",
  label = "interaction-table-asian",
  add.lines = list(
    c("County FEs", "Y", "Y"),
    c("N. counties", 
      interaction_n_units_asian)
  ),
  font.size = "scriptsize",
  no.space = TRUE,
  notes.append = TRUE,
  notes.align = "l",
  notes.label = "",
  notes = c(
    "Note: Panel regression models.",
    "Panel-corrected standard errors in parentheses.",
    "Year dummies and lagged (1-period) outcome included in all models."
  ),
  digits = 3,
  omit.stat = c("f", "rsq", "adj.rsq"),
  out = c("../tables/interaction-models-asian.tex")
)



## Make marginal effects plots
range_asian_values <- seq(
  min(dat$change_pct_asian_t1, na.rm = T),
  max(dat$change_pct_asian_t1, na.rm = T),
  length.out = 25
)

regular_asian_values <- c(
  mean(dat$change_pct_asian_t1, na.rm = T) - 2 * sd(dat$change_pct_asian_t1, 
                                                    na.rm = T),
  mean(dat$change_pct_asian_t1, na.rm = T) + 2 * sd(dat$change_pct_asian_t1, 
                                                    na.rm = T)
)

range_asian_values <- c(range_asian_values,
                        regular_asian_values)

## List of key variables for models
key_ivs <- c("total_trade_layoffs_t1")

## Placeholder
all_results_asian <- list()

for(i in 1:length(interaction_models_asian)){
  
  model_results_asian <- c()
  
  for(j in 1:length(range_asian_values)){
    
    model_results_asian <- rbind(model_results_asian,
                                 c(
                                   mcce_ci_calc("total_trade_layoffs_t1", 
                                                "change_pct_asian_t1", 
                                                range_asian_values[j], 
                                                interaction_models_asian[[i]]),
                                   model_number = i,
                                   key_variable = "total_trade_layoffs_t1"
                                 ))
    
    
    
  }
  
  model_results_asian <- as.data.frame(model_results_asian)
  
  all_results_asian[[i]] <- model_results_asian
  
}

## Combine
me_results_asian <- do.call(rbind, all_results_asian) %>%
  as.data.frame()


## Make numeric
me_results_asian[ , 1:7] <- apply(me_results_asian[ , 1:7], 2, factor2numeric)

## Labels for y-axis
iv_long <- c("trade layoffs")

## Titles
dv_long <- c("DV: log(Hate crime incidents + 1)",
             "DV: Number of hate groups present in county")


## Make plots
for(i in 1:length(interaction_models_asian)){
  
  the_plot <- ggplot(me_results_asian %>% 
                       subset(
                         model_number == i),
                     aes(x = var2.value,
                         y = beta,
                         ymin = ci.95.lower,
                         ymax = ci.95.upper)) +
    #xlim(regular_asian_values) +
    xlim(c(-0.15, 0.1)) +
    ylim(c(-.02, 0.02)) +
    geom_line() +
    geom_ribbon(alpha = .25) +
    geom_hline(yintercept = 0, lty = "dashed") +
    labs(x = "\n Change in percentage of Asian population (t-1)",
         y = paste0("Marginal effect of trade layoffs"),
         title = dv_long[i]) +
    theme_aiddata_plain()
  
  the_plot
  
  ggsave(filename = paste0("../figures/final-int-model-asian-", i, ".jpeg" ), 
         plot = the_plot, 
         scale = .575)
  
}














#-----------------------------------------------------------------------
# Appendix: extra time-invariant controls
#-----------------------------------------------------------------------

pool_1_extend <- update(pool_1,
                        . ~ . + log_gdp_grid + log_distance)

pool_2_extend <- update(pool_2,
                        . ~ . + log_gdp_grid + log_distance)


extra_models <- list(pool_1_extend, pool_2_extend)

## Get PCSEs
for(i in 1:length(extra_models)){
  
  extra_models[[i]]$vcov <- vcovBK(extra_models[[i]], type = "HC1")
  
}

stargazer(
  pool_1_extend, pool_2_extend,
  omit = c("factor", "foreign", "Constant", "hate"),
  covariate.labels = c(
    "Trade layoffs",
    "Population (log, interpolated)",
    "Nighttime luminosity",
    "Percent white population",
    "Unemployment rate",
    "Percent voting Republican in most recent election",
    "GDP estimate (2006)",
    "Travel time to major cities"
  ),
  p.auto = TRUE,
  dep.var.labels = c("Hate crimes",
                     "Hate groups"),
  dep.var.labels.include = TRUE,
  title = "Hate crimes, hate groups, and trade layoffs (extra controls)",
  label = "extra-controls",
  font.size = "scriptsize",
  no.space = TRUE,
  notes.append = TRUE,
  notes.align = "l",
  notes.label = "",
  notes = c(
    "Note: Panel-corrected standard errors in parentheses.",
    "Year and state dummies and lagged (1-period) outcome included in all models."
  ),
  digits = 3,
  omit.stat = c("f", "rsq", "adj.rsq"),
  out = c("../tables/appendix-time-invariant-controls.tex")
)






#-----------------------------------------------------------------------
# Appendix: China import vulnerability and anti-Asian hate crimes
#-----------------------------------------------------------------------

library(lmtest)

## Model 1: State and year dummies
china_pfit_1 <- plm(asian_hate_incidents ~ 
                      
                      ## Key variable
                      china_import_shock_3yravg_1000s +
                      
                      ## Lagged DV
                      asian_hate_incidents_t1 +
                      
                      ## Very within counties over time
                      log_ipopulation_est + 
                      nighttime_lights_t1 +
                      pct_white_t1 +
                      unemployment_rate_t1 +
                      republican_last +
                      
                      ## Dummies
                      factor(NAME_1) +
                      factor(year) - 1,
                    
                    data = pdat,
                    model = "pooling")


## Model 2: County-fixed effects
china_pfit_2 <- plm(asian_hate_incidents ~ 
                      
                      ## Key variable
                      china_import_shock_3yravg_1000s +
                      
                      ## Lagged DV
                      asian_hate_incidents_t1 +
                      
                      ## Very within counties over time
                      log_ipopulation_est + 
                      nighttime_lights_t1 +
                      pct_white_t1 +
                      unemployment_rate_t1 +
                      republican_last +
                      factor(year) - 1,
                    
                    data = pdat,
                    model = "fd")


china_models <- list(china_pfit_1, china_pfit_2)

## Reestimate with "only" Asian hate incidents
only_models <- list()

for(i in 1:length(china_models)){
  
  new_model <- update(china_models[[i]],
                      only_asian_incidents ~ . - 
                        asian_hate_incidents_t1 +
                        only_asian_incidents_t1)
  
  only_models[[i]] <- new_model
  
}


all_china_models <- append(china_models, only_models)


all_china_n_units <- sapply(all_china_models,
                            function(x)
                              pdim(x)$nT$n)


stargazer(
  all_china_models, 
  omit = c("factor", "foreign", "Constant", "hate", "asian"),
  covariate.labels = c("China import vulnerability$_{\\text{3-year avg.}}$",
                       "Population (log, interpolated)",
                       "Nighttime luminosity",
                       "Percent white population",
                       "Unemployment rate",
                       "Percent voting Republican in most recent election"),
  p.auto = TRUE,
  dep.var.labels = c("Incidents involving anti-Asian bias",
                     "Incidents with exclusively anti-Asian bias"),
  title = "Anti-Asian hate crime incidents and Chinese import competition",
  label = "china-table",
  add.lines = list(
    c("County FEs", "N", "Y", "N", "Y"),
    c("N. counties", all_china_n_units)
  ),
  font.size = "scriptsize",
  no.space = TRUE,
  notes.append = TRUE,
  notes.align = "l",
  notes.label = "",
  notes = c(
    "Note: Panel regression models.",
    "Estimated standard errors in parentheses.",
    "Year dummies and lagged (1-period) outcome included in all models.",
    "State dummies included in Models 1 and 3.",
    "Temporal domain: 2006-2017."
  ),
  digits = 4,
  omit.stat = c("f", "rsq", "adj.rsq"),
  out = c("../tables/appendix-china-models.tex")
)







#-----------------------------------------------------------------------
# Mexico import vulnerability and anti-Hispanic hate crimes
#-----------------------------------------------------------------------

library(lmtest)

## Model 1: State and year dummies
mexico_pfit_1 <- plm(hispanic_hate_incidents ~ 
                       
                       ## Key variable
                       mexico_trade_layoffs_t1 +
                       
                       ## Lagged DV
                       hispanic_hate_incidents_t1 +
                       
                       ## Very within counties over time
                       log_ipopulation_est + 
                       nighttime_lights_t1 +
                       pct_white_t1 +
                       unemployment_rate_t1 +
                       republican_last +
                       
                       ## Dummies
                       factor(NAME_1) +
                       factor(year) - 1,
                     
                     data = pdat,
                     model = "pooling")

## Model 2: County-fixed effects
mexico_pfit_2 <- update(mexico_pfit_1, model = "within", effect = "twoways")

mexico_models <- list(mexico_pfit_1, mexico_pfit_2)

## Reestimate with "only" hispanic hate incidents
only_models <- list()

for(i in 1:length(mexico_models)){
  
  new_model <- update(mexico_models[[i]],
                      only_hispanic_incidents ~ . - 
                        hispanic_hate_incidents_t1 +
                        only_hispanic_incidents_t1)
  
  only_models[[i]] <- new_model
  
}

all_mexico_models <- append(mexico_models, only_models)

all_mexico_n_units <- sapply(all_mexico_models,
                             function(x)
                               pdim(x)$nT$n)

## Get PCSEs
for(i in 1:length(all_mexico_models)){
  
  all_mexico_models[[i]]$vcov <- vcovBK(all_mexico_models[[i]], type = "HC1")
  
}


stargazer(
  all_mexico_models, 
  omit = c("factor", "foreign", "Constant", "hate", "hispanic"),
  covariate.labels = c("Trade layoffs attributed to Mexico",
                       "Population (log, interpolated)",
                       "Nighttime luminosity",
                       "Percent white population",
                       "Unemployment rate",
                       "Percent voting Republican in most recent election"),
  p.auto = TRUE,
  dep.var.labels = c("Incidents involving anti-Hispanic bias",
                     "Incidents with exclusively anti-Hispanic bias"),
  title = "Anti-Hispanic hate crime incidents and Mexican import competition",
  label = "mexico-table",
  add.lines = list(
    c("County FEs", "N", "Y", "N", "Y"),
    c("N. counties", all_mexico_n_units)
  ),
  font.size = "scriptsize",
  no.space = TRUE,
  notes.append = TRUE,
  notes.align = "l",
  notes.label = "",
  notes = c(
    "Note: Panel regression models.",
    "Panel-corrected standard errors in parentheses.",
    "Year dummies and lagged (1-period) outcome included in all models.",
    "State dummies included in Models 1 and 3"
  ),
  digits = 4,
  omit.stat = c("f", "rsq", "adj.rsq"),
  out = c("../tables/mexico-models.tex")
)


#-----------------------------------------------------------------------
# Trade layoffs as percentage of working population
#-----------------------------------------------------------------------

## Calculate new measure (multiply trade layoffs by 100 because they are in 100s)
dat$trade_layoffs_pct_workers_t1 <- ((dat$total_trade_layoffs_t1 * 100) / dat$labor_force_t1) * 100

pdat$trade_layoffs_pct_workers_t1 <- ((pdat$total_trade_layoffs_t1 * 100) / pdat$labor_force_t1) * 100

dat$ln_trade_layoffs_pct_workers_t1 <- log(dat$trade_layoffs_pct_workers_t1 + 1)
pdat$ln_trade_layoffs_pct_workers_t1 <- log(pdat$trade_layoffs_pct_workers_t1 + 1)



as_pct_models <- list()

for(i in 1:length(table_1_models)){
  
  as_pct_models[[i]] <- update(table_1_models[[i]],
                               . ~ trade_layoffs_pct_workers_t1 + 
                                 . - 
                                 total_trade_layoffs_t1)
}


as_pct_n_units <- sapply(as_pct_models,
                         function(x)
                           pdim(x)$nT$n)

## Get PCSEs
for(i in 1:length(as_pct_models)){
  
  as_pct_models[[i]]$vcov <- vcovBK(as_pct_models[[i]], type = "HC1")
  
}

stargazer(
  as_pct_models, 
  omit = c("factor", "foreign", "Constant", "hate", "hispanic"),
  covariate.labels = c("Trade layoffs as percent of labor force",
                       "Population (log, interpolated)",
                       "Nighttime luminosity",
                       "Percent white population",
                       "Unemployment rate",
                       "Percent voting Republican in most recent election"),
  p.auto = TRUE,
  dep.var.labels = c("Hate crimes",
                     "Hate groups"),
  title = "Trade layoffs as a percent of the labor force",
  label = "as-pct-table",
  add.lines = list(
    c("County FEs", "N", "Y", "N", "Y"),
    c("N. counties", as_pct_n_units)
  ),
  font.size = "scriptsize",
  no.space = TRUE,
  notes.append = TRUE,
  notes.align = "l",
  notes.label = "",
  notes = c(
    "Note: Panel regression models.",
    "Panel-corrected standard errors in parentheses.",
    "Year dummies and lagged (1-period) outcome included in all models.",
    "State dummies included in Models 1 and 3."
  ),
  digits = 4,
  omit.stat = c("f", "rsq", "adj.rsq"),
  out = c("../tables/as-pct-models.tex")
)



#-----------------------------------------------------------------------
# Appendix: Pre-2014 models to avoid extending nighttime lights data
#-----------------------------------------------------------------------

pdat_pre2014 <- pdata.frame(dat %>% filter(year < 2014),
                            index = c("state_county", "year"))

pre_2014_fit_1 <- plm(I(log(all_foreign_hate_incidents + 1)) ~ 
                        
                        ## Key variable
                        total_trade_layoffs_t1 +
                        
                        ## Lagged DV
                        I(log(all_foreign_hate_incidents_t1 + 1)) +
                        
                        ## Very within counties over time
                        log_ipopulation_est + 
                        nighttime_lights_t1 +
                        pct_white_t1 +
                        unemployment_rate_t1 +
                        republican_last +
                        factor(year) - 1,
                      
                      data = pdat_pre2014,
                      model = "fd")


pre_2014_fit_2 <- plm(total_hate_2 ~ 
                        
                        ## Key variable
                        total_trade_layoffs_t1 +
                        
                        ## Lagged DV
                        total_hate_2_t1 +
                        
                        ## Very within counties over time
                        log_ipopulation_est + 
                        nighttime_lights_t1 +
                        pct_white_t1 +
                        unemployment_rate_t1 +
                        republican_last +
                        factor(year) - 1,
                      
                      data = pdat_pre2014,
                      model = "fd")


pre_2014_models <- list(pre_2014_fit_1, pre_2014_fit_2)

pre_2014_n_units <- sapply(pre_2014_models,
                           function(x)
                             pdim(x)$nT$n)

## Get PCSEs
for(i in 1:length(pre_2014_models)){
  
  pre_2014_models[[i]]$vcov <- vcovBK(pre_2014_models[[i]], type = "HC1")
  
}



stargazer(
  pre_2014_models, 
  omit = c("factor", "foreign", "Constant", "hate"),
  covariate.labels = c("Trade layoffs",
                       "Population (log, interpolated)",
                       "Nighttime luminosity",
                       "Percent white population",
                       "Unemployment rate",
                       "Percent voting Republican in most recent election"),
  p.auto = TRUE,
  dep.var.labels = c("Hate crimes",
                     "Hate groups"),
  title = "Pre-2014 models",
  label = "pre-2014-table",
  add.lines = list(
    c("County FEs", "Y", "Y"),
    c("N. counties", pre_2014_n_units)
  ),
  font.size = "scriptsize",
  no.space = TRUE,
  notes.append = TRUE,
  notes.align = "l",
  notes.label = "",
  notes = c(
    "Note: Panel regression models.",
    "Panel-corrected standard errors in parentheses.",
    "Year dummies and lagged (1-period) outcome included in all models."
  ),
  digits = 4,
  omit.stat = c("f", "rsq", "adj.rsq"),
  out = c("../tables/pre-2014-models.tex")
)



#-----------------------------------------------------------------------
# Appendix: Level of pct. white rather than change
#-----------------------------------------------------------------------


## Interaction models
interaction_fit_level_crime <- plm(
  I(log(all_foreign_hate_incidents + 1)) ~ 
    
    ## Key variable
    total_trade_layoffs_t1 * pct_white_t1 +
    
    ## Lagged DV
    I(log(all_foreign_hate_incidents_t1 + 1)) +
    
    ## Vary within counties
    log_ipopulation_est +
    nighttime_lights_t1 +
    unemployment_rate_t1 +
    republican_last,
  
  data = pdat,
  model = "within",
  effect = "twoways"
)



interaction_fit_level_groups <- plm(
  total_hate_2 ~ 
    
    ## Key variable
    (total_trade_layoffs_t1 * pct_white_t1) + 
    
    ## Lagged DV
    total_hate_2_t1 +
    
    ## Vary within counties
    log_ipopulation_est +
    nighttime_lights_t1 +
    unemployment_rate_t1 + 
    republican_last,
  
  data = pdat,
  model = "within",
  effect = "twoways"
)



interaction_level_models <- list(interaction_fit_level_crime, 
                                 interaction_fit_level_groups)

## Get PCSEs
for(i in 1:length(interaction_level_models)){
  
  interaction_level_models[[i]]$vcov <- vcovBK(interaction_level_models[[i]], 
                                               type = "HC1")
  
  
}

interaction_level_n_units <- sapply(interaction_level_models,
                                    function(x)
                                      pdim(x)$nT$n)

## Interaction models table
stargazer(
  interaction_level_models,
  omit = c("factor", "foreign", "Constant", "hate"),
  covariate.labels = c(
    "Trade layoffs$_{t-1}$",
    "Percent white population$_{t-1}$",
    "Population (log, interpolated)",
    "Nighttime luminosity$_{t-1}$",
    "Change in unemployment rate from $t-1$",
    "Percent voting Republican in most recent election",
    "Trade layoffs $\\times$ Percent white population$_{t-1}$"
  ),
  p.auto = TRUE,
  dep.var.labels = c("Hate crimes",
                     "Hate groups"),
  dep.var.labels.include = TRUE,
  title = "Conditioning effects of changing demographics",
  label = "interaction-level-table",
  add.lines = list(
    c("County FEs", "Y", "Y"),
    c("N. counties", 
      interaction_level_n_units)
  ),
  font.size = "scriptsize",
  no.space = TRUE,
  notes.append = TRUE,
  notes.align = "l",
  notes.label = "",
  notes = c(
    "Note: Panel regression models.",
    "Panel-corrected standard errors in parentheses.",
    "Year dummies and lagged (1-period) outcome included in all models."
  ),
  digits = 3,
  omit.stat = c("f", "rsq", "adj.rsq"),
  out = c("../tables/interaction-level-models.tex")
)



## Make marginal effects plots
range_white_values <- seq(
  min(dat$pct_white_t1, na.rm = T),
  max(dat$pct_white_t1, na.rm = T),
  length.out = 25
)

regular_white_values <- c(
  mean(dat$pct_white_t1, na.rm = T) - 2 * sd(dat$pct_white_t1, 
                                             na.rm = T),
  mean(dat$pct_white_t1, na.rm = T) + 2 * sd(dat$pct_white_t1, 
                                             na.rm = T)
)


range_white_values <- c(range_white_values,
                        regular_white_values)


## List of key variables for models
key_ivs <- c("total_trade_layoffs_t1")

## Placeholder
all_results <- list()

for(i in 1:length(interaction_level_models)){
  
  model_results <- c()
  
  for(j in 1:length(range_white_values)){
    
    model_results <- rbind(model_results,
                           c(
                             mcce_ci_calc("total_trade_layoffs_t1", 
                                          "pct_white_t1", 
                                          range_white_values[j], 
                                          interaction_level_models[[i]]),
                             model_number = i,
                             key_variable = "total_trade_layoffs_t1"
                           ))
    
    
    
  }
  
  model_results <- as.data.frame(model_results)
  
  all_results[[i]] <- model_results
  
}

## Combine
me_results <- do.call(rbind, all_results) %>%
  as.data.frame()


## Make numeric
me_results[ , 1:7] <- apply(me_results[ , 1:7], 2, factor2numeric)


## Titles
dv_long <- c("DV: log(Hate crime incidents + 1)",
             "DV: Number of hate groups present in county")


## Make plots
for(i in 1:length(interaction_level_models)){
  
  the_plot <- ggplot(me_results %>% 
                       subset(
                         model_number == i),
                     aes(x = var2.value,
                         y = beta,
                         ymin = ci.95.lower,
                         ymax = ci.95.upper)) +
    #xlim(regular_white_values) +
    xlim(c(50, 100)) +
    ylim(c(-.02, 0.02)) +
    geom_line() +
    geom_ribbon(alpha = .25) +
    geom_hline(yintercept = 0, lty = "dashed") +
    labs(x = "\n Change in percentage of white population (t-1)",
         y = paste0("Marginal effect of trade layoffs"),
         title = dv_long[i]) +
    theme_aiddata_plain()
  
  ggsave(filename = paste0("../figures/appendix-final-int-level-model-", i, ".jpeg" ), 
         plot = the_plot, 
         scale = 1)
  
}





#-----------------------------------------------------------------------
# Appendix: Including all types of hate groups in the DV
#-----------------------------------------------------------------------


hg_models <- table_1_models[c(3, 4)]


all_hg_models <- list()

for(i in 1:length(hg_models)){
  
  new_model <- update(hg_models[[i]],
                      total_hate ~ . - total_hate_2_t1 +
                        total_hate_t1)
  
  new_model$vcov <- vcovBK(new_model, type = "HC1")
  
  all_hg_models[[i]] <- new_model
  
}


all_hg_n_units <- sapply(all_hg_models,
                         function(x)
                           pdim(x)$nT$n)






stargazer(
  all_hg_models,
  omit = c("factor", "foreign", "Constant", "hate"),
  covariate.labels = c("Trade layoffs$_{t-1}$",
                       "Population (log, interpolated)",
                       "Nighttime luminosity",
                       "Percent white population",
                       "Unemployment rate",
                       "Percent voting Republican in most recent election"),
  p.auto = TRUE,
  dep.var.caption = "DV: Number of hate groups (all types) present in county",
  dep.var.labels.include = FALSE,
  title = "Hate group (all types) presence and trade layoffs",
  label = "appx-all-hate-table",
  add.lines = list(
    c("County FEs", "N", "Y"),
    c("N. counties", all_hg_n_units)
  ),
  font.size = "scriptsize",
  no.space = TRUE,
  notes.append = TRUE,
  notes.align = "l",
  notes.label = "",
  notes = c(
    "Note: Panel regression models.",
    "Panel-corrected standard errors in parentheses.",
    "Year dummies and lagged (1-period) outcome included in all models.",
    "State dummies included in Model 1."
  ),
  digits = 4,
  omit.stat = c("f", "rsq", "adj.rsq"),
  out = c("../tables/appendix-all-hate-group-models.tex")
)




#-----------------------------------------------------------------------
# Appendix: Anti-LGBT groups as placebo test
#-----------------------------------------------------------------------


lgbt_models <- list()

for(i in 1:length(hg_models)){
  
  new_model <- update(hg_models[[i]],
                      anti_lgbt ~ . - total_hate_2_t1 +
                        anti_lgbt_t1)
  
  new_model$vcov <- vcovBK(new_model, type = "HC1")
  
  lgbt_models[[i]] <- new_model
  
}


all_lgbt_n_units <- sapply(lgbt_models,
                           function(x)
                             pdim(x)$nT$n)




stargazer(
  lgbt_models[c(1, 3)],
  omit = c("factor", "foreign", "Constant", "hate", "lgbt"),
  covariate.labels = c("Trade layoffs$_{t-1}$",
                       "Population (log, interpolated)",
                       "Nighttime luminosity$_{t-1}$",
                       "Change in percent white population$_{t-1}$",
                       "Change in unemployment from $t-1$",
                       "Percent voting Republican in most recent election",
                       "GDP estimate (2006)",
                       "Travel time to major cities"),
  p.auto = TRUE,
  dep.var.caption = "DV: Number of hate groups (Anti-LGBT focus) present in county",
  dep.var.labels.include = FALSE,
  title = "Hate group (Anti-LGBT focus) presence and trade layoffs",
  label = "appx-lgbt",
  add.lines = list(
    c("County FEs", "N", "Y"),
    c("N. counties", all_lgbt_n_units[c(1, 3)])
  ),
  font.size = "scriptsize",
  no.space = TRUE,
  notes.append = TRUE,
  notes.align = "l",
  notes.label = "",
  notes = c(
    "Note: Panel regression models.",
    "Panel-corrected standard errors in parentheses.",
    "Year dummies and lagged (1-period) outcome included in all models.",
    "State dummies included in Model 1."
  ),
  digits = 4,
  omit.stat = c("f", "rsq", "adj.rsq"),
  out = c("../tables/appendix-lgbt-models.tex")
)




#-----------------------------------------------------------------------
# Appendix: GMM models
#-----------------------------------------------------------------------

dat$dv_1 <- log(dat$all_foreign_hate_incidents + 1)
dat$dv_2 <- dat$total_hate_2

dat.gmm <- dat %>%
  dplyr::select(
    dv_1,
    dv_2,
    total_trade_layoffs_t1,
    log_ipopulation_est,
    nighttime_lights_t1,
    pct_white_t1,
    unemployment_rate_t1,
    republican_last,
    state_county,
    year
  ) %>%
  na.exclude()

## Make pdata.frame
pgmm.pdat <- pdata.frame(dat.gmm,
                         index = c("state_county", "year"))



crimes.pgmm <- pgmm(
  dv_1 ~ 
    
    ## Key variable
    total_trade_layoffs_t1 +
    
    ## Vary within counties
    log_ipopulation_est +
    nighttime_lights_t1 +
    pct_white_t1 +
    unemployment_rate_t1 +
    republican_last +
    lag(dv_1, 1) |
    lag(dv_1, 2:99),
  
  data = pgmm.pdat,
  effect = "twoways", 
  model = "twosteps"
)


hg.pgmm <- pgmm(
  dv_2 ~ 
    
    ## Key variable
    total_trade_layoffs_t1 +
    
    ## Vary within counties
    log_ipopulation_est +
    nighttime_lights_t1 +
    pct_white_t1 +
    unemployment_rate_t1 +
    republican_last + 
    lag(dv_2, 1) |
    lag(dv_2, 2:99),
  
  data = pgmm.pdat,
  effect = "twoways", 
  model = "twosteps"
)



stargazer(
  crimes.pgmm, hg.pgmm,
  covariate.labels = c(
    "Trade layoffs",
    "Population (log, interpolated)",
    "Nighttime luminosity",
    "Percent white population",
    "Unemployment rate",
    "Percent voting Republican in most recent election",
    "Lagged hate crimes (1-period)",
    "Lagged hate groups (1-period)"),
  p.auto = TRUE,
  dep.var.labels = c("Hate crimes",
                     "Hate groups"),
  dep.var.labels.include = TRUE,
  title = "Generalized Method of Moments estimation",
  label = "gmm-table",
  font.size = "scriptsize",
  no.space = TRUE,
  notes.append = TRUE,
  notes.align = "l",
  notes.label = "",
  digits = 3,
  omit.stat = c("f", "rsq", "adj.rsq"),
  out = "../tables/appendix-gmm-models.tex"
)




