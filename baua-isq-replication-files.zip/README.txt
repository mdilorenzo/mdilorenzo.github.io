This folder contains the data sets and scripts necessary to replicate the statistical analyses in "Bypass Aid and Unrest in Autocracies" by Matthew D. DiLorenzo. Please forward any questions about these files to mdilorenzo@wm.edu or matthewdilorenzo@gmail.com.

(Last updated 06-16-2017)

The folder contains the following files:

1. baua-isq-online-appendix.pdf: This file contains the supplemental analyses and robustness checks referenced in the main article.

2. baua-custom-functions.R: This script contains code for two custom R functions in the substantive interpretation of the models in Table 2 (empiricalMarginsNB) and the implementation of the two-stage bootstrapping procedure in Table 4 and Figure 2 (twostageboot).

3. baua-isq-replication-data.RData: The data set in R format needed to replicate all statistical results in the main text and Online Appendix, except for the "plausibly exogenous" test in Section H of the Supplementary Files. Short variable descriptions are provided below. (Note: This data set is also included as a .csv file)

4. baua-main-models.R: This R script contains all code to reproduce the statistical results (tables and figures) in the main text of the article.

5. baua-appendix-models.R: This R script contains all code to reproduce the statistical results (tables and figures) in the Online Appendix.

6. plaus-exog-data.dta: This is data set in Stata 13 format for the "plausibly exogenous" test in Section H of the Supplementary Files.

7. plaus-exog-implement.do: This is a Stata do-file for the "plausibly exogenous" test in Section H of the Supplementary Files.

8. aid-scandals-final-v-1.csv: This .csv file contains the aid scandals data set used in the instrumental variables analysis. (This file is not necessary to reproduce the published results. Researchers interested in using the data should cite the article.)



Fully reproducing the results requires R and Stata. To replicate the statistical results in the main text and appendix, first set your working directory to this folder (setwd("folder/location/here") in R) and then run the scripts, including loading any necessary packages. The code to load the packages is included at the top of the scripts. To install new packages, use "install.packages("name_of_package")" in R. Replicating the results in Section H of the online appendix can be achieved by changing your working directory to the correct path in Stata at the top of "plaus-exog-implement.do" or by double clicking the "plaus-exog-data.dta" file and then running the "plaus-exog-implement.do" from line 11 onward.


Short variable descriptions in baua-isq-replication-data.RData:

Variable sources and citations are described in the main text or Appendix.

cowcode: Correlates of War country code
year: Year 
gwf_country: Country name from Geddes, Wright, Frantz (2014)
unrest: Sum of unrest events (described in text)
unrest_dummy: Dichotomous indicator of unrest events 
pct_bypass1_p_t1: Percent of aid given through bypass channels in previous year, excluding public-private partnerships (used in appendix)
bypass_pop_log: Bypass aid divided by population (natural log)
public_pop_log: Government aid divided by population (natural log)
pct_bypass2_p_t1: Percent of aid given through bypass channels in previous year
bypass2_p_t1: Proportion of aid given through bypass channels in previous year
bypass2_t_t1: Total aid through bypass channels in previous year
public_t_t1: Total aid through government channels in previous year
civil_conflict_t1: Count of civil conflicts in previous year
nd_count_t1: Count of natural disasters in previous year
gov_index_t1: Governance Index in previous year
population_t1: Total population in previous year
bypass_transform: Transformed bypass proportion for two stage models (described in text)
aid_scandals_t2_major: All major aid scandals two years prior
aid_scandals_t2_extra_continent: All aid scandals outside continent two years prior
scandals_affinity_weighted_past_10: Aid scandals weighted by Affinity two years prior
mean_global_growth_lag_2: Average global GDP growth two years prior
mean_global_inflation_lag_2: Average global inflation two years prior
total_global_disasters_lag_2: Total number of natural disasters two years prior
banks_domestic2: Measure of anti-government demonstrations from Banks (2011)
banks_domestic8: Measure of strikes from Banks (2011)
milex: Military expenditures
milex_lag: Military expenditures in previous year
interstate_crises_t1: Total Militarized Interstate Disputes in previous year
ad_bypass_total_t1: Total bypass aid using alternative AidData measure
ad_govt_total_t1: Total government aid using alternative AidData measure
ad_bypass_proportion_t1: Bypass proportion using alternative AidData measure
bypass_pct_gdp: Bypass aid (main measure) as percent of GDP
yrs_since_independence: Years since the country became independent
us_ally: Whether or not the country has an alliance with the United States (dummy)
n_maj_allies: Number of major power allies
opec_member: Whether the recipient is an OPEC member



