#-----------------------------------------------------------------------
# Title: Statistical models for "Term Limits and Environmental Treaty Commitments"
# Author: Matt DiLorenzo and Talor Stone
# Contact: mdiloren@odu.edu
# Institution: Old Dominion University
# Date: July 1, 2021
# Description: Statistical models and figures
# ----------------------------------------------------------------------

## Load packages 
## To install, use install.packages("[package name]")
library(tidyverse)
library(readxl)
library(countrycode)
library(foreign)
library(stargazer)
library(xtable)
library(readstata13)
library(MASS)
library(sandwich)


## Set working directory (set to folder path)
setwd("~/Dropbox/working-papers/term-limits-environment/replication-package/")

## Load custom functions
source("aux-functions.R")

## Load in main data file
dat <- read.csv("analysis-data.csv",
                stringsAsFactors = FALSE) 

## Generate dummies for income groups
dat$low_income <- ifelse(dat$wb_income_group == "L", 1, 0)
dat$lm_income <- ifelse(dat$wb_income_group == "LM", 1, 0)
dat$um_income <- ifelse(dat$wb_income_group == "UM", 1, 0)
dat$high_income <- ifelse(dat$wb_income_group == "H", 1, 0)


#-----------------------------------------------------------------------
# Table 1: Descriptive statistics
#-----------------------------------------------------------------------

stargazer(
  dat %>% dplyr::select(total_meas_signed,
                        total_beas_or_meas_signed,
                        term_limit,
                        rgdppc_log,
                        rgdppc_change,
                        time_democratic,
                        total_disasters_prev3_log,
                        resource_rents_pct_gdp,
                        xrcomp,
                        parcomp,
                        total_igos,
                        exec_right,
                        exec_left,
                        cso_repression,
                        presidential_democracy,
                        leader_age,
                        female),
  title = "Descriptive statistics for key variables",
  label = "descriptives",
  covariate.labels = c(
    "MEAs signed",
    "MEAs + BEAs signed",
    "Term limit",
    "Real GDP/capita (log)",
    "Percentage change in real GDP/capita",
    "Experience with democracy",
    "Disasters in prior 3 years (log)",
    "Resource rents (pct. of GDP)",
    "XRCOMP",
    "PARCOMP",
    "Total IGOs",
    "Executive right",
    "Executive left",
    "CSO repression",
    "Presidential democracy",
    "Leader age",
    "Female"
  ),
  font.size = "scriptsize",
  summary.stat = c("n", "mean", "sd", "min", "max"),
  out = c("tables/table-1.tex",
          "tables/table-1.html")
)

#-----------------------------------------------------------------------
# Table 2: Statistical models
#-----------------------------------------------------------------------

ols_1a <- lm(
  total_meas_signed ~ 
    term_limit +
    rgdppc_log +
    rgdppc_change +
    time_democratic +
    total_disasters_prev3_log + 
    resource_rents_pct_gdp +
    xrcomp + parcomp +
    total_igos +
    exec_right +
    exec_left +
    cso_repression +
    presidential_democracy +
    leader_age +
    female +
    total_meas_signed_t1 +
    factor(year) - 1,
  data = dat
)


ols_1b <- lm(
  total_meas_signed ~ 
    term_limit +
    rgdppc_log +
    rgdppc_change +
    time_democratic +
    total_disasters_prev3_log + 
    resource_rents_pct_gdp +
    xrcomp + parcomp +
    total_igos +
    exec_right +
    exec_left +
    cso_repression +
    presidential_democracy +
    leader_age +
    female +
    total_meas_signed_t1 +
    factor(cow_code) +
    factor(year) - 1,
  data = dat
)



ols_2a <- lm(
  total_beas_or_meas_signed ~ term_limit +
    rgdppc_log +
    rgdppc_change +
    time_democratic +
    total_disasters_prev3_log + 
    resource_rents_pct_gdp +
    xrcomp + parcomp +
    total_igos +
    exec_right +
    exec_left +
    cso_repression +
    presidential_democracy +
    leader_age +
    female +
    total_beas_or_meas_signed_t1 +
    factor(year) - 1,
  data = dat
)


ols_2b <- lm(
  total_beas_or_meas_signed ~ term_limit +
    rgdppc_log +
    rgdppc_change +
    time_democratic +
    total_disasters_prev3_log + 
    resource_rents_pct_gdp +
    xrcomp + parcomp +
    total_igos +
    exec_right +
    exec_left +
    cso_repression +
    presidential_democracy +
    leader_age +
    female +
    total_beas_or_meas_signed_t1 +
    factor(cow_code) +
    factor(year) - 1,
  data = dat
)




pois_1a <- glm(
  total_meas_signed ~ term_limit +
    rgdppc_log +
    rgdppc_change +
    time_democratic +
    total_disasters_prev3_log + 
    resource_rents_pct_gdp +
    xrcomp + parcomp +
    total_igos +
    exec_right +
    exec_left +
    cso_repression +
    presidential_democracy +
    leader_age +
    female +
    total_meas_signed_t1 +
    factor(year) - 1,
  family = "poisson",
  data = dat
)


pois_1b <- glm(
  total_meas_signed ~ term_limit +
    rgdppc_log +
    rgdppc_change +
    time_democratic +
    total_disasters_prev3_log + 
    resource_rents_pct_gdp +
    xrcomp + parcomp +
    total_igos +
    exec_right +
    exec_left +
    cso_repression +
    presidential_democracy +
    leader_age +
    female +
    total_meas_signed_t1 +
    factor(cow_code) +
    factor(year) - 1,
  family = "poisson",
  data = dat
)


pois_2a <- glm(
  total_beas_or_meas_signed ~ term_limit +
    rgdppc_log +
    rgdppc_change +
    time_democratic +
    total_disasters_prev3_log + 
    resource_rents_pct_gdp +
    xrcomp + parcomp +
    total_igos +
    exec_right +
    exec_left +
    cso_repression +
    presidential_democracy +
    leader_age +
    female +
    total_beas_or_meas_signed_t1 +
    factor(year) - 1,
  family = "poisson",
  data = dat
)


pois_2b <- glm(
  total_beas_or_meas_signed ~ term_limit +
    rgdppc_log +
    rgdppc_change +
    time_democratic +
    total_disasters_prev3_log + 
    resource_rents_pct_gdp +
    xrcomp + parcomp +
    total_igos +
    exec_right +
    exec_left +
    cso_repression +
    presidential_democracy +
    leader_age +
    female +
    total_beas_or_meas_signed_t1 +
    factor(cow_code) +
    factor(year) - 1,
  family = "poisson",
  data = dat
)


ols_3a <- update(ols_1a,
                 . ~ term_limit * rgdppc_log + .)

ols_3b <- update(ols_1b,
                 . ~ term_limit * rgdppc_log + .)

ols_4a <- update(ols_2a,
                 . ~ term_limit * rgdppc_log + .)

ols_4b <- update(ols_2b,
                 . ~ term_limit * rgdppc_log + .)

pois_3a <- update(pois_1a,
                . ~ term_limit * rgdppc_log + .)

pois_3b <- update(pois_1b,
                . ~ term_limit * rgdppc_log + .)

pois_4a <- update(pois_2a,
                . ~ term_limit * rgdppc_log + .)

pois_4b <- update(pois_2b,
                . ~ term_limit * rgdppc_log + .)




## Models for Table 2 (baseline results)
table_2_models <- list(ols_1a, ols_1b, ols_2a, ols_2b, 
                       pois_1a, pois_1b, pois_2a, pois_2b)

table_2_rses <- list()

for(i in 1:length(table_2_models)){
  
  table_2_rses[[i]] <- sqrt(diag(vcovHC(table_2_models[[i]], type = "HC1")))

}

## Make table

stargazer(
  table_2_models,
  se = table_2_rses,
  omit = c("factor", "t1"),
  column.labels = rep(c("MEAs", "MEAs", "MEAs + BEAs", "MEAs + BEAs"), 
                      times = 2),
  model.names = TRUE,
  dep.var.labels.include = FALSE,
  covariate.labels = c(
    "Term limit",
    "Real GDP/capita (log)",
    "Change in real GDP/capita (pct.)",
    "Experience with democracy",
    "Disasters in prior 3 years (log)",
    "Resource rents (pct. of GDP)",
    "XRCOMP",
    "PARCOMP",
    "IGO memberships",
    "Executive right",
    "Executive left",
    "CSO repression",
    "Presidential democracy",
    "Leader age",
    "Female"
  ),
  label = "table-2",
  title = "Term limits and environmental treaty participation, 1970-2011",
  no.space = TRUE,
  notes.append = TRUE,
  notes.align = "l",
  notes.label = "",
  notes = c(
    "Note: Robust (HC1) standard errors in parentheses.",
    "Year dummies included but omitted from table output."
  ),
  add.lines = list(
    c("Country dummies?", rep(c("N", "Y"), 4))
  ),
  #float.env = "sidewaystable",
  font.size = "tiny",
  out = c("tables/table-2.tex", 
          "tables/table-2.html"),
  omit.stat = c("f", "ser", "theta")
)



## Models for Table 3 (interaction with GDP)

table_3_models <- list(ols_3b, pois_3b, ols_4b, pois_4b)

table_3_rses <- list()


for(i in 1:length(table_3_models)){
  
  table_3_rses[[i]] <- sqrt(diag(vcovHC(table_3_models[[i]], type = "HC1")))
  
}

## Make table

stargazer(
  table_3_models,
  se = table_3_rses,
  omit = c("factor", "t1"),
  column.labels = rep(c("MEAs", "MEAs + BEAs"), each = 2),
  model.names = TRUE,
  dep.var.labels.include = FALSE,
  covariate.labels = c(
    "Term limit",
    "Real GDP/capita (log)",
    "Change in real GDP/capita (pct.)",
    "Experience with democracy",
    "Disasters in prior 3 years (log)",
    "Resource rents (pct. of GDP)",
    "XRCOMP",
    "PARCOMP",
    "IGO memberships",
    "Executive right",
    "Executive left",
    "CSO repression",
    "Presidential democracy",
    "Leader age",
    "Female",
    "Term limit $\\times$ Real GDP/capita"
  ),
  label = "table-3",
  title = "Term limits, wealth, and environmental treaty participation, 1970-2011",
  no.space = TRUE,
  notes.append = TRUE,
  notes.align = "l",
  notes.label = "",
  notes = c(
    "Note: Robust (HC1) standard errors in parentheses.",
    "Country- and year dummies included but omitted from table output."
  ),
  #float.env = "sidewaystable",
  font.size = "scriptsize",
  out = c("tables/table-3.tex", 
          "tables/table-3.html"),
  omit.stat = c("f", "ser", "theta")
)



unique_gdp <- unique(dat$rgdppc_log %>% round(2)) %>% .[!is.na(.)] %>% sort()

library(sandwich)
## Add install.packages("sandwich") if needed

holder_1 <- holder_2 <- holder_3 <- holder_4 <- c()

for(i in 1:length(unique_gdp)){
  
  holder_1 <- rbind(
    holder_1,
    mcce_ci_calc(
      "term_limit", "rgdppc_log", 
      var2.value = unique_gdp[i], 
      model = ols_3b, 
      model_vcov = vcovHC(ols_3b, type = "HC1")
    )
  )
  
  holder_2 <- rbind(
    holder_2,
    mcce_ci_calc(
      "term_limit", "rgdppc_log", 
      var2.value = unique_gdp[i], 
      model = ols_4b, 
      model_vcov = vcovHC(ols_4b, type = "HC1")
    )
  )
  
  holder_3 <- rbind(
    holder_3,
    mcce_ci_calc(
      "term_limit", "rgdppc_log", 
      var2.value = unique_gdp[i], 
      model = pois_3b, 
      model_vcov = vcovHC(pois_3b, type = "HC1")
    )
  )
  
  holder_4 <- rbind(
    holder_4,
    mcce_ci_calc(
      "term_limit", "rgdppc_log", 
      var2.value = unique_gdp[i], 
      model = pois_4b, 
      model_vcov = vcovHC(pois_4b, type = "HC1")
    )
  )
  
  
  
}

holder_1 <- as.data.frame(holder_1)
holder_2 <- as.data.frame(holder_2)
holder_3 <- as.data.frame(holder_3)
holder_4 <- as.data.frame(holder_4)



plot_dat_1 <- dat %>%
  mutate(var2.value = round(rgdppc_log, 2)) %>%
  dplyr::select(var2.value) %>%
  left_join(holder_1)

plot_dat_2 <- dat %>%
  mutate(var2.value = round(rgdppc_log, 2)) %>%
  dplyr::select(var2.value) %>%
  left_join(holder_2)

plot_dat_3 <- dat %>%
  mutate(var2.value = round(rgdppc_log, 2)) %>%
  dplyr::select(var2.value) %>%
  left_join(holder_3)

plot_dat_4 <- dat %>%
  mutate(var2.value = round(rgdppc_log, 2)) %>%
  dplyr::select(var2.value) %>%
  left_join(holder_4)


all_plot_data <- rbind.data.frame(
  plot_dat_1 %>% mutate(dv = "MEAs", model_fit = "OLS"), 
  plot_dat_2 %>% mutate(dv = "MEAs & BEAs", model_fit = "OLS"),
  plot_dat_3 %>% mutate(dv = "MEAs", 
                        model_fit = "Poisson"), 
  plot_dat_4 %>% mutate(dv = "MEAs & BEAs", 
                        model_fit = "Poisson")
)


ols_gdp_fig <- ggplot(all_plot_data %>% 
                        na.exclude() %>% 
                        filter(model_fit == "OLS"),
                      aes(x = var2.value, 
                          y = beta, 
                          ymin = ci.95.lower, 
                          ymax = ci.95.upper)) +
  facet_wrap(. ~ model_fit + dv) +
  geom_line() +
  geom_vline(xintercept = mean(all_plot_data$var2.value, na.rm = T),
             lty = "dashed", colour = "salmon") +
  geom_hline(yintercept = 0, lty = "dotted") +
  #xlim(c(5, 10.9)) +
  geom_ribbon(alpha = .35) +
  new_plot_theme_plain() +
  geom_rug(sides = "b") +
  labs(x = "\nReal GDP per capita (log)",
       y = "Estimated coefficient for\nterm limits\n")


pois_gdp_fig <- ggplot(all_plot_data %>% 
                       na.exclude() %>% 
                       filter(model_fit == "Poisson"),
                     aes(x = var2.value, 
                         y = beta, 
                         ymin = ci.95.lower, 
                         ymax = ci.95.upper)) +
  facet_wrap(. ~ model_fit + dv) +
  geom_line() +
  geom_vline(xintercept = mean(all_plot_data$var2.value, na.rm = T),
             lty = "dashed", colour = "salmon") +
  geom_hline(yintercept = 0, lty = "dotted") +
  #xlim(c(5, 10.9)) +
  geom_ribbon(alpha = .35) +
  new_plot_theme_plain() +
  geom_rug(sides = "b") +
  labs(x = "\nReal GDP per capita (log)",
       y = "Estimated coefficient for\nterm limits\n")


library(gridExtra)
## Use install.packages("gridExtra") if needed

ggsave(grid.arrange(ols_gdp_fig, pois_gdp_fig),
       filename = "figures/fig-1.png",
       width = 8, height = 8)


p_0 <- predict(pois_3b,
               newdata = pois_3b$model %>%
                 as.data.frame() %>%
                 rename(cow_code = `factor(cow_code)`,
                        year = `factor(year)`) %>%
                 mutate(term_limit = 0,
                        rgdppc_log = 10))


p_1 <- predict(pois_3b,
               newdata = pois_3b$model %>%
                 as.data.frame() %>%
                 rename(cow_code = `factor(cow_code)`,
                        year = `factor(year)`) %>%
                 mutate(term_limit = 1,
                        rgdppc_log = 10))


mean(p_1 - p_0)



p_0 <- predict(pois_4b,
                  newdata = pois_4b$model %>%
                    as.data.frame() %>%
                    rename(cow_code = `factor(cow_code)`,
                           year = `factor(year)`) %>%
                    mutate(term_limit = 0,
                           rgdppc_log = 10))


p_1 <- predict(pois_4b,
                  newdata = pois_4b$model %>%
                    as.data.frame() %>%
                    rename(cow_code = `factor(cow_code)`,
                           year = `factor(year)`) %>%
                    mutate(term_limit = 1,
                           rgdppc_log = 10))


mean(p_1 - p_0)


#-----------------------------------------------------------------------
# Using ordinal measure of income groups from World Bank (1987-2011)
#-----------------------------------------------------------------------

ols_group_1 <- lm(
  total_meas_signed ~ term_limit * lm_income +
    term_limit * um_income +
    term_limit * high_income +
    rgdppc_change +
    time_democratic +
    total_disasters_prev3_log + 
    resource_rents_pct_gdp +
    xrcomp + parcomp +
    total_igos +
    exec_right +
    exec_left +
    cso_repression +
    presidential_democracy +
    leader_age +
    female +
    total_meas_signed_t1 +
    factor(cow_code) +
    factor(year) - 1,
  data = dat
)



ols_group_2 <- lm(
  total_beas_or_meas_signed ~ term_limit * lm_income +
    term_limit * um_income +
    term_limit * high_income +
    rgdppc_change +
    time_democratic +
    total_disasters_prev3_log + 
    resource_rents_pct_gdp +
    xrcomp + parcomp +
    total_igos +
    exec_right +
    exec_left +
    cso_repression +
    presidential_democracy +
    leader_age +
    female +
    total_beas_or_meas_signed_t1 +
    factor(cow_code) +
    factor(year) - 1,
  data = dat
)



stargazer(
  ols_group_1, ols_group_2,
  omit = c("factor", "t1"),
  column.labels = rep(c("MEAs", "MEAs + BEAs"), 
                      times = 1),
  model.names = TRUE,
  dep.var.labels.include = FALSE,
  covariate.labels = c(
    "Term limit",
    "Lower-middle income group",
    "Upper-middle income group",
    "High income group",
    "Change in real GDP/capita (pct.)",
    "Experience with democracy",
    "Disasters in prior 3 years (log)",
    "Resource rents (pct. of GDP)",
    "XRCOMP",
    "PARCOMP",
    "IGO memberships",
    "Executive right",
    "Executive left",
    "CSO repression",
    "Presidential democray?",
    "Leader age",
    "Female",
    "Term limit $\\times$ Lower-middle income",
    "Term limit $\\times$ Upper-middle income",
    "Term limit $\\times$ High income"
  ),
  label = "appx-wb-group-interaction",
  title = "Term limits and environmental treaty participation with World Bank income classification as moderator, 1970-2011",
  no.space = TRUE,
  notes.append = TRUE,
  notes.align = "l",
  notes.label = "",
  notes = c(
    "Note: Estimated standard errors in parentheses.",
    "Country- and year dummies included but omitted from table output."
  ),
  add.lines = list(
    c("Country dummies?", rep(c("Y"), 2))
  ),
  #float.env = "sidewaystable",
  font.size = "scriptsize",
  out = c("tables/table-appx-wb.tex", 
          "tables/table-appx-wb.html"),
  omit.stat = c("f", "ser", "theta")
)


ests_1 <- rbind(
  mcce_ci_calc("term_limit", "lm_income", 
               var2.value = 0, 
               model = ols_group_1), ## To get baseline, set = 0
  mcce_ci_calc("term_limit", "lm_income", 
               var2.value = 1, 
               model = ols_group_1),
  mcce_ci_calc("term_limit", "um_income", 
               var2.value = 1, 
               model = ols_group_1),
  mcce_ci_calc("term_limit", "high_income", 
               var2.value = 1, 
               model = ols_group_1)
)


ests_2 <- rbind(
  mcce_ci_calc("term_limit", "lm_income", 
               var2.value = 0, 
               model = ols_group_2), ## To get baseline, set = 0
  mcce_ci_calc("term_limit", "lm_income", 
               var2.value = 1, 
               model = ols_group_2),
  mcce_ci_calc("term_limit", "um_income", 
               var2.value = 1, 
               model = ols_group_2),
  mcce_ci_calc("term_limit", "high_income", 
               var2.value = 1, 
               model = ols_group_2)
)


ests_1 <- as.data.frame(ests_1)
ests_2 <- as.data.frame(ests_2)

total_obs <- dim(ols_group_1$model)[1]

other_groups <- ols_group_1$model %>%
  dplyr::select(contains("_income")) %>%
  summarise_all(funs(sum(.))) 


wbi_labels <- c(
  
  paste0("Low\n(N = ", total_obs - sum(other_groups),")"),
  paste0("Lower-middle\n(N = ", other_groups[1],")"),
  paste0("Upper-middle\n(N = ", other_groups[2],")"),
  paste0("High\n(N = ", other_groups[3],")")
  
)


ests_1$income_group <- ests_2$income_group <- factor(
  wbi_labels,
  levels = wbi_labels)


group_plot_1 <- ggplot(ests_1,
                       aes(x = factor(income_group),
                           y = beta,
                           ymin = ci.95.lower,
                           ymax = ci.95.upper)) +
  geom_point() +
  geom_hline(yintercept = 0, lty = "dashed") +
  geom_errorbar(width = 0) +
  labs(x = "\nWorld Bank income group",
       y = "Estimated coefficient for term limits\n",
       title = "MEAs") +
  new_plot_theme_plain() 



group_plot_2 <- ggplot(ests_2,
                       aes(x = factor(income_group),
                           y = beta,
                           ymin = ci.95.lower,
                           ymax = ci.95.upper)) +
  geom_point() +
  geom_hline(yintercept = 0, lty = "dashed") +
  geom_errorbar(width = 0) +
  labs(x = "\nWorld Bank income group",
       y = "",
       title = "MEAs + BEAs") +
  new_plot_theme_plain() 


ggsave(grid.arrange(group_plot_1, group_plot_2, nrow = 1),
       filename = "figures/fig-wb-income-groups.png",
       scale = 1.5,
       width = 6, height = 2)




#--------------------------------------------------------
# Appendix: Reverse calculations for interaction with GDP
#--------------------------------------------------------


reverse_gdp <- rbind(
  mcce_ci_calc(
    "rgdppc_log", "term_limit", 
    var2.value = 0, 
    model = ols_3b, 
    model_vcov = vcovHC(ols_3b, type = "HC1")
  ), 
  mcce_ci_calc(
    "rgdppc_log", "term_limit", 
    var2.value = 1, 
    model = ols_3b, 
    model_vcov = vcovHC(ols_3b, type = "HC1")
  ), 
  mcce_ci_calc(
    "rgdppc_log", "term_limit", 
    var2.value = 0, 
    model = ols_4b, 
    model_vcov = vcovHC(ols_4b, type = "HC1")
  ), 
  mcce_ci_calc(
    "rgdppc_log", "term_limit", 
    var2.value = 1, 
    model = ols_4b, 
    model_vcov = vcovHC(ols_4b, type = "HC1")
  ),
  
  mcce_ci_calc(
    "rgdppc_log", "term_limit", 
    var2.value = 0, 
    model = pois_3b, 
    model_vcov = vcovHC(pois_3b, type = "HC1")
  ), 
  mcce_ci_calc(
    "rgdppc_log", "term_limit", 
    var2.value = 1, 
    model = pois_3b, 
    model_vcov = vcovHC(pois_3b, type = "HC1")
  ), 
  mcce_ci_calc(
    "rgdppc_log", "term_limit", 
    var2.value = 0, 
    model = pois_4b, 
    model_vcov = vcovHC(pois_4b, type = "HC1")
  ), 
  mcce_ci_calc(
    "rgdppc_log", "term_limit", 
    var2.value = 1, 
    model = pois_4b, 
    model_vcov = vcovHC(pois_4b, type = "HC1")
  )
)


reverse_gdp <- as.data.frame(reverse_gdp)

reverse_gdp$dv <- rep(c(rep("MEAs", 2), rep("MEAs + BEAs", 2)), 2)
reverse_gdp$model_fit <- rep(c("OLS", "Negative binomial"), each = 4)

ols_rev_gdp_fig <- ggplot(reverse_gdp %>% 
                            na.exclude() %>%
                            filter(model_fit == "OLS"),
                          aes(x = factor(var2.value), 
                              y = beta, 
                              ymin = ci.95.lower, 
                              ymax = ci.95.upper)) +
  facet_wrap(. ~ model_fit + dv) +
  geom_point(size = 3) +
  geom_errorbar(width = 0, size = 1) +
  geom_errorbar(aes(x = factor(var2.value), 
                    #y = beta, 
                    ymin = ci.90.lower, 
                    ymax = ci.90.upper),
                size = 2, width = 0) +
  geom_hline(yintercept = 0, lty = "dotted") +
  new_plot_theme_plain() +
  geom_rug(sides = "b") +
  labs(x = "\nTerm limit?",
       y = "Estimated coefficient for\nreal GDP\n")



pois_rev_gdp_fig <- ggplot(reverse_gdp %>% 
                             na.exclude() %>%
                             filter(model_fit == "Negative binomial"),
                           aes(x = factor(var2.value), 
                               y = beta, 
                               ymin = ci.95.lower, 
                               ymax = ci.95.upper)) +
  facet_wrap(. ~ model_fit + dv) +
  geom_point(size = 3) +
  geom_errorbar(width = 0, size = 1) +
  geom_errorbar(aes(x = factor(var2.value), 
                    #y = beta, 
                    ymin = ci.90.lower, 
                    ymax = ci.90.upper),
                size = 2, width = 0) +
  geom_hline(yintercept = 0, lty = "dotted") +
  new_plot_theme_plain() +
  geom_rug(sides = "b") +
  labs(x = "\nTerm limit?",
       y = "Estimated coefficient for\nreal GDP\n")

ggsave(grid.arrange(ols_rev_gdp_fig, pois_rev_gdp_fig, nrow = 2),
       filename = "figures/fig-1-reverse.png",
       width = 8, height = 8)




#-----------------------------------------------------------------------
# Appendix: Interaction with leader age
#-----------------------------------------------------------------------


ols_age_1 <- update(ols_1b,
                    . ~ term_limit * leader_age + .)

ols_age_2 <- update(ols_2b,
                    . ~ term_limit * leader_age + .)



pois_age_1 <- update(pois_1b,
                   . ~ term_limit * leader_age + .)

pois_age_2 <- update(pois_2b,
                   . ~ term_limit * leader_age + .)


a_models <- list(ols_age_1, pois_age_1, ols_age_2, pois_age_2)

a_rses <- list()

for(i in 1:length(a_models)){
  
  a_rses[[i]] <- sqrt(diag(vcovHC(a_models[[i]], type = "HC1")))
  
}



## Make table

stargazer(
  a_models,
  se = a_rses,
  omit = c("factor", "t1"),
  column.labels = rep(c("MEAs", "MEAs + BEAs"), each = 2),
  model.names = TRUE,
  dep.var.labels.include = FALSE,
  covariate.labels = c(
    "Term limit",
    "Real GDP/capita (log)",
    "Change in real GDP/capita (pct.)",
    "Experience with democracy",
    "Disasters in prior 3 years (log)",
    "Resource rents (pct. of GDP)",
    "XRCOMP",
    "PARCOMP",
    "IGO memberships",
    "Executive right",
    "Executive left",
    "CSO repression",
    "Presidential democracy",
    "Leader age",
    "Female",
    "Term limit $\\times$ Leader age"
  ),
  label = "appx-table-age",
  title = "Term limits, age, and environmental treaty participation, 1970-2011",
  no.space = TRUE,
  notes.append = TRUE,
  notes.align = "l",
  notes.label = "",
  notes = c(
    "Note: Robust (HC1) standard errors in parentheses.",
    "Country- and year dummies included but omitted from table output."
  ),
  #float.env = "sidewaystable",
  font.size = "scriptsize",
  out = c("tables/table-4.tex", 
          "tables/table-4.html"),
  omit.stat = c("f", "ser", "theta")
)



unique_age <- unique(dat$leader_age %>% round(0)) %>% .[!is.na(.)] %>% sort()

library(sandwich)

aholder_1 <- aholder_2 <- aholder_3 <- aholder_4 <- c()

for(i in 1:length(unique_age)){
  
  aholder_1 <- rbind(
    aholder_1,
    mcce_ci_calc(
      "term_limit", "leader_age", 
      var2.value = unique_age[i], 
      model = ols_age_1, 
      model_vcov = vcovHC(ols_age_1, type = "HC1")
    )
  )
  
  aholder_2 <- rbind(
    aholder_2,
    mcce_ci_calc(
      "term_limit", "leader_age", 
      var2.value = unique_age[i], 
      model = ols_age_2, 
      model_vcov = vcovHC(ols_age_2, type = "HC1")
    )
  )
  
  aholder_3 <- rbind(
    aholder_3,
    mcce_ci_calc(
      "term_limit", "leader_age", 
      var2.value = unique_age[i], 
      model = pois_age_1, 
      model_vcov = vcovHC(pois_age_1, type = "HC1")
    )
  )
  
  aholder_4 <- rbind(
    aholder_4,
    mcce_ci_calc(
      "term_limit", "leader_age", 
      var2.value = unique_age[i], 
      model = pois_age_2, 
      model_vcov = vcovHC(pois_age_2, type = "HC1")
    )
  )
  
  
}

aholder_1 <- as.data.frame(aholder_1)
aholder_2 <- as.data.frame(aholder_2)
aholder_3 <- as.data.frame(aholder_3)
aholder_4 <- as.data.frame(aholder_4)



aplot_dat_1 <- dat %>%
  mutate(var2.value = round(leader_age, 0)) %>%
  dplyr::select(var2.value) %>%
  left_join(aholder_1)


aplot_dat_2 <- dat %>%
  mutate(var2.value = round(leader_age, 0)) %>%
  dplyr::select(var2.value) %>%
  left_join(aholder_2)

aplot_dat_3 <- dat %>%
  mutate(var2.value = round(leader_age, 0)) %>%
  dplyr::select(var2.value) %>%
  left_join(aholder_3)


aplot_dat_4 <- dat %>%
  mutate(var2.value = round(leader_age, 0)) %>%
  dplyr::select(var2.value) %>%
  left_join(aholder_4)


all_plot_data_age <- rbind.data.frame(
  aplot_dat_1 %>% mutate(dv = "MEAs", model_fit = "OLS"), 
  aplot_dat_2 %>% mutate(dv = "MEAs & BEAs", model_fit = "OLS"),
  aplot_dat_3 %>% mutate(dv = "MEAs", model_fit = "Poisson"), 
  aplot_dat_4 %>% mutate(dv = "MEAs & BEAs", model_fit = "Poisson")
)


ols_age_fig <- ggplot(all_plot_data_age %>% 
                        na.exclude() %>%
                        filter(model_fit == "OLS"),
                      aes(x = var2.value, 
                          y = beta, 
                          ymin = ci.95.lower, 
                          ymax = ci.95.upper)) +
  facet_grid(. ~ model_fit + dv) +
  geom_line() +
  geom_vline(xintercept = mean(all_plot_data_age$var2.value, na.rm = T),
             lty = "dashed", colour = "salmon") +
  geom_hline(yintercept = 0, lty = "dotted") +
  geom_ribbon(alpha = .35) +
  new_plot_theme_plain() +
  geom_rug(sides = "b") +
  labs(x = "\nLeader age (in years)",
       y = "Estimated coefficient for\nterm limits\n")



pois_age_fig <- ggplot(all_plot_data_age %>% 
                       na.exclude() %>%
                       filter(model_fit == "Poisson"),
                     aes(x = var2.value, 
                         y = beta, 
                         ymin = ci.95.lower, 
                         ymax = ci.95.upper)) +
  facet_grid(. ~ model_fit + dv) +
  geom_line() +
  geom_vline(xintercept = mean(all_plot_data_age$var2.value, na.rm = T),
             lty = "dashed", colour = "salmon") +
  geom_hline(yintercept = 0, lty = "dotted") +
  geom_ribbon(alpha = .35) +
  new_plot_theme_plain() +
  geom_rug(sides = "b") +
  labs(x = "\nLeader age (in years)",
       y = "Estimated coefficient for\nterm limits\n")


ggsave(grid.arrange(ols_age_fig, pois_age_fig, nrow = 2),
       filename = "figures/fig-tl-by-age.png",
       width = 8, height = 8)





reverse_age <- rbind(
  mcce_ci_calc(
    "leader_age", "term_limit", 
    var2.value = 0, 
    model = ols_age_1, 
    model_vcov = vcovHC(ols_age_1, type = "HC1")
  ), 
  mcce_ci_calc(
    "leader_age", "term_limit", 
    var2.value = 1, 
    model = ols_age_1, 
    model_vcov = vcovHC(ols_age_1, type = "HC1")
  ), 
  mcce_ci_calc(
    "leader_age", "term_limit", 
    var2.value = 0, 
    model = ols_age_2, 
    model_vcov = vcovHC(ols_age_2, type = "HC1")
  ), 
  mcce_ci_calc(
    "leader_age", "term_limit", 
    var2.value = 1, 
    model = ols_age_2, 
    model_vcov = vcovHC(ols_age_2, type = "HC1")
  ),
  
  mcce_ci_calc(
    "leader_age", "term_limit", 
    var2.value = 0, 
    model = pois_age_1, 
    model_vcov = vcovHC(pois_age_1, type = "HC1")
  ), 
  mcce_ci_calc(
    "leader_age", "term_limit", 
    var2.value = 1, 
    model = pois_age_1, 
    model_vcov = vcovHC(pois_age_1, type = "HC1")
  ), 
  mcce_ci_calc(
    "leader_age", "term_limit", 
    var2.value = 0, 
    model = pois_age_2, 
    model_vcov = vcovHC(pois_age_2, type = "HC1")
  ), 
  mcce_ci_calc(
    "leader_age", "term_limit", 
    var2.value = 1, 
    model = pois_age_2, 
    model_vcov = vcovHC(pois_age_2, type = "HC1")
  )
)


reverse_age <- as.data.frame(reverse_age)

reverse_age$dv <- rep(c(rep("MEAs", 2), rep("MEAs + BEAs", 2)), 2)
reverse_age$model_fit <- rep(c("OLS", "Poisson"), each = 4)


ols_rev_age_fig <- ggplot(reverse_age %>% 
                            na.exclude() %>%
                            filter(model_fit == "OLS"),
                          aes(x = factor(var2.value), 
                              y = beta, 
                              ymin = ci.95.lower, 
                              ymax = ci.95.upper)) +
  facet_grid(. ~ model_fit + dv) +
  geom_point(size = 3) +
  geom_errorbar(width = 0, size = 1) +
  geom_errorbar(aes(x = factor(var2.value), 
                    #y = beta, 
                    ymin = ci.90.lower, 
                    ymax = ci.90.upper),
                size = 2, width = 0) +
  geom_hline(yintercept = 0, lty = "dotted") +
  new_plot_theme_plain() +
  geom_rug(sides = "b") +
  labs(x = "\nTerm limit?",
       y = "Estimated coefficient for\nleader age\n")


pois_rev_age_fig <- ggplot(reverse_age %>% 
                           na.exclude() %>%
                           filter(model_fit == "Poisson"),
                         aes(x = factor(var2.value), 
                             y = beta, 
                             ymin = ci.95.lower, 
                             ymax = ci.95.upper)) +
  facet_grid(. ~ model_fit + dv) +
  geom_point(size = 3) +
  geom_errorbar(width = 0, size = 1) +
  geom_errorbar(aes(x = factor(var2.value), 
                    #y = beta, 
                    ymin = ci.90.lower, 
                    ymax = ci.90.upper),
                size = 2, width = 0) +
  geom_hline(yintercept = 0, lty = "dotted") +
  new_plot_theme_plain() +
  geom_rug(sides = "b") +
  labs(x = "\nTerm limit?",
       y = "Estimated coefficient for\nleader age\n")



ggsave(grid.arrange(ols_rev_age_fig, pois_rev_age_fig, nrow = 2),
       filename = "figures/fig-age-by-tl.png",
       width = 8, height = 8)







#-----------------------------------------------------------------------
# Treaties with climate subject only
#-----------------------------------------------------------------------

## The first climate treaty is in 1992, so subsetting sample for these models

summary(dat$total_climate_meas_signed)

ct_ols_1a <- lm(
  total_climate_meas_signed ~ 
    term_limit +
    rgdppc_log +
    rgdppc_change +
    time_democratic +
    total_disasters_prev3_log + 
    resource_rents_pct_gdp +
    xrcomp + parcomp +
    total_igos +
    exec_right +
    exec_left +
    cso_repression +
    presidential_democracy +
    leader_age +
    female +
    total_climate_meas_signed_t1 +
    factor(year) - 1,
  data = dat[dat$year > 1991, ]
)


ct_ols_1b <- lm(
  total_climate_meas_signed ~ 
    term_limit +
    rgdppc_log +
    rgdppc_change +
    time_democratic +
    total_disasters_prev3_log + 
    resource_rents_pct_gdp +
    xrcomp + parcomp +
    total_igos +
    exec_right +
    exec_left +
    cso_repression +
    presidential_democracy +
    leader_age +
    female +
    total_climate_meas_signed_t1 +
    factor(cow_code) +
    factor(year) - 1,
  data = dat[dat$year > 1991, ]
)




library(sandwich)
ct_models <- list(ct_ols_1a, ct_ols_1b)
ct_rses <- list()
ct_models_gdp <- list()
ct_gdp_rses <- list()

for(i in 1:length(ct_models)){
  
  ct_models_gdp[[i]] <- update(ct_models[[i]],
                               . ~ term_limit * rgdppc_log + .)
  
  ct_rses[[i]] <- sqrt(diag(vcovHC(ct_models[[i]], type = "HC1")))
  
  ct_gdp_rses[[i]] <- sqrt(diag(vcovHC(ct_models_gdp[[i]], type = "HC1")))
  
  
}




stargazer(
  ct_models,
  se = ct_rses,
  omit = c("factor", "t1"),
  model.names = TRUE,
  dep.var.caption = "DV: Climate IEAs signed",
  dep.var.labels.include = FALSE,
  covariate.labels = c(
    "Term limit",
    "Real GDP/capita (log)",
    "Change in real GDP/capita (pct.)",
    "Experience with democracy",
    "Disasters in prior 3 years (log)",
    "Resource rents (pct. of GDP)",
    "XRCOMP",
    "PARCOMP",
    "IGO memberships",
    "Executive right",
    "Executive left",
    "CSO repression",
    "Presidential democracy",
    "Leader age",
    "Female"
  ),
  label = "appx-alt-dv-ct",
  title = "Term limits and climate IEAs, 1992-2011",
  no.space = TRUE,
  notes.append = TRUE,
  notes.align = "l",
  notes.label = "",
  add.lines = list(
    c("Country dummies?", rep(c("N", "Y"), 1))
  ),
  notes = c(
    "Note: Robust (HC1) standard errors in parentheses.",
    "Country- and year dummies included but omitted from table output."
  ),
  font.size = "scriptsize",
  out = c("tables/alt-dv-ct.tex", 
          "tables/alt-dv-ct.html"),
  omit.stat = c("f", "ser", "theta")
)



## Interaction table
stargazer(
  ct_models_gdp,
  se = ct_gdp_rses,
  dep.var.caption = "DV: Climate IEAs signed",
  omit = c("factor", "t1"),
  model.names = TRUE,
  dep.var.labels.include = FALSE,
  covariate.labels = c(
    "Term limit",
    "Real GDP/capita (log)",
    "Change in real GDP/capita (pct.)",
    "Experience with democracy",
    "Disasters in prior 3 years (log)",
    "Resource rents (pct. of GDP)",
    "XRCOMP",
    "PARCOMP",
    "IGO memberships",
    "Executive right",
    "Executive left",
    "CSO repression",
    "Presidential democracy",
    "Leader age",
    "Female",
    "Term limit $\\times$ Real GDP/capita"
  ),
  label = "appx-alt-dv-ct-gdp",
  title = "Term limits, wealth, and climate IEAs, 1992-2011",
  no.space = TRUE,
  notes.append = TRUE,
  notes.align = "l",
  notes.label = "",
  add.lines = list(
    c("Country dummies?", rep(c("N", "Y"), 1))
  ),
  notes = c(
    "Note: Robust (HC1) standard errors in parentheses.",
    "Country- and year dummies included but omitted from table output."
  ),
  font.size = "scriptsize",
  out = c("tables/alt-dv-ct-gdp.tex", 
          "tables/alt-dv-ct-gdp.html"),
  omit.stat = c("f", "ser", "theta")
)




#-----------------------------------------------------------------------
# Appendix: Domestic climate policies as alternate DV
#-----------------------------------------------------------------------
cp_ols_1a <- lm(
  n_climate_policies ~ 
    term_limit +
    rgdppc_log +
    rgdppc_change +
    time_democratic +
    total_disasters_prev3_log + 
    resource_rents_pct_gdp +
    xrcomp + parcomp +
    total_igos +
    exec_right +
    exec_left +
    cso_repression +
    presidential_democracy +
    leader_age +
    female +
    factor(year) - 1,
  data = dat
)


cp_ols_1b <- lm(
  n_climate_policies ~ 
    term_limit +
    rgdppc_log +
    rgdppc_change +
    time_democratic +
    total_disasters_prev3_log + 
    resource_rents_pct_gdp +
    xrcomp + parcomp +
    total_igos +
    exec_right +
    exec_left +
    cso_repression +
    presidential_democracy +
    leader_age +
    female +
    factor(cow_code) +
    factor(year) - 1,
  data = dat
)


cp_logit_1a <- glm(
  n_climate_policies > 0 ~ 
    term_limit +
    rgdppc_log +
    rgdppc_change +
    time_democratic +
    total_disasters_prev3_log + 
    resource_rents_pct_gdp +
    xrcomp + parcomp +
    total_igos +
    exec_right +
    exec_left +
    cso_repression +
    presidential_democracy +
    leader_age +
    female +
    factor(year) - 1,
  data = dat,
  family = binomial(link = "logit")
)


cp_logit_1b <- glm(
  n_climate_policies > 0 ~ 
    term_limit +
    rgdppc_log +
    rgdppc_change +
    time_democratic +
    total_disasters_prev3_log + 
    resource_rents_pct_gdp +
    xrcomp + parcomp +
    total_igos +
    exec_right +
    exec_left +
    cso_repression +
    presidential_democracy +
    leader_age +
    female +
    factor(cow_code) +
    factor(year) - 1,
  data = dat,
  family = binomial(link = "logit")
)


cp_models <- list(cp_ols_1a, cp_ols_1b, cp_logit_1a, cp_logit_1b)
cp_rses <- list()
cp_models_gdp <- list()
cp_gdp_rses <- list()

for(i in 1:length(cp_models)){
  
  cp_models_gdp[[i]] <- update(cp_models[[i]],
                               . ~ term_limit * rgdppc_log + .)
  
  cp_rses[[i]] <- sqrt(diag(vcovHC(cp_models[[i]], type = "HC1")))
  
  cp_gdp_rses[[i]] <- sqrt(diag(vcovHC(cp_models_gdp[[i]], type = "HC1")))
  
  
}




stargazer(
  cp_models[1:2],
  se = cp_rses[1:2],
  omit = c("factor", "t1"),
  model.names = TRUE,
  dep.var.labels.include = FALSE,
  covariate.labels = c(
    "Term limit",
    "Real GDP/capita (log)",
    "Change in real GDP/capita (pct.)",
    "Experience with democracy",
    "Disasters in prior 3 years (log)",
    "Resource rents (pct. of GDP)",
    "XRCOMP",
    "PARCOMP",
    "IGO memberships",
    "Executive right",
    "Executive left",
    "CSO repression",
    "Presidential democracy",
    "Leader age",
    "Female"
  ),
  label = "appx-alt-dv-cp",
  title = "Term limits and domestic climate policies, 2000-2011",
  no.space = TRUE,
  notes.append = TRUE,
  notes.align = "l",
  notes.label = "",
  add.lines = list(
    c("Country dummies?", rep(c("N", "Y"), 2))
  ),
  notes = c(
    "Note: Robust (HC1) standard errors in parentheses.",
    "Country- and year dummies included but omitted from table output."
  ),
  font.size = "scriptsize",
  out = c("tables/alt-dv-cp.tex", 
          "tables/alt-dv-cp.html"),
  omit.stat = c("f", "ser", "theta")
)



## Interaction table
stargazer(
  cp_models_gdp[1:2],
  se = cp_gdp_rses[1:2],
  omit = c("factor", "t1"),
  model.names = TRUE,
  dep.var.labels.include = FALSE,
  covariate.labels = c(
    "Term limit",
    "Real GDP/capita (log)",
    "Change in real GDP/capita (pct.)",
    "Experience with democracy",
    "Disasters in prior 3 years (log)",
    "Resource rents (pct. of GDP)",
    "XRCOMP",
    "PARCOMP",
    "IGO memberships",
    "Executive right",
    "Executive left",
    "CSO repression",
    "Presidential democracy",
    "Leader age",
    "Female",
    "Term limit $\\times$ Real GDP/capita"
  ),
  label = "appx-alt-dv-cp-gdp",
  title = "Term limits, wealth, and domestic climate policies, 2000-2011",
  no.space = TRUE,
  notes.append = TRUE,
  notes.align = "l",
  notes.label = "",
  add.lines = list(
    c("Country dummies?", rep(c("N", "Y"), 2))
  ),
  notes = c(
    "Note: Robust (HC1) standard errors in parentheses.",
    "Country- and year dummies included but omitted from table output."
  ),
  font.size = "scriptsize",
  out = c("tables/alt-dv-cp-gdp.tex", 
          "tables/alt-dv-cp-gdp.html"),
  omit.stat = c("f", "ser", "theta")
)



#-----------------------------------------------------------------------
# Bivariate models
#-----------------------------------------------------------------------

biv_1 <- lm(total_meas_signed  ~ term_limit,
            data = dat)

biv_2 <- lm(total_beas_or_meas_signed ~ term_limit,
            data = dat)

## Make table
stargazer(
  biv_1, biv_2,
  column.labels = c("MEAs", "MEAs + BEAs"),
  model.names = TRUE,
  dep.var.labels.include = FALSE,
  covariate.labels = c(
    "Term limit"
  ),
  label = "appendix-biv",
  title = "Term limits and environmental treaty participation, 1970-2011 (bivariate)",
  no.space = TRUE,
  notes.append = TRUE,
  notes.align = "l",
  notes.label = "",
  font.size = "footnotesize",
  notes = c(
    "Note: Estimated standard errors in parentheses."),
  out = c("tables/table-appx-biv.tex", 
          "tables/table-appx-biv.html"),
  omit.stat = c("f", "ser", "theta")
)




#-----------------------------------------------------------------------
# Ratification models
#-----------------------------------------------------------------------

ols_1a_rat <- lm(
  total_meas_ratified ~ 
    term_limit +
    rgdppc_log +
    rgdppc_change +
    time_democratic +
    total_disasters_prev3_log + 
    resource_rents_pct_gdp +
    xrcomp + parcomp +
    total_igos +
    exec_right +
    exec_left +
    cso_repression +
    presidential_democracy +
    leader_age +
    female +
    total_meas_ratified_t1 +
    factor(year) - 1,
  data = dat
)


ols_1b_rat <- lm(
  total_meas_ratified ~ 
    term_limit +
    rgdppc_log +
    rgdppc_change +
    time_democratic +
    total_disasters_prev3_log + 
    resource_rents_pct_gdp +
    xrcomp + parcomp +
    total_igos +
    exec_right +
    exec_left +
    cso_repression +
    presidential_democracy +
    leader_age +
    female +
    total_meas_ratified_t1 +
    factor(cow_code) +
    factor(year) - 1,
  data = dat
)



ols_2a_rat <- lm(
  total_beas_or_meas_ratified ~ 
    term_limit +
    rgdppc_log +
    rgdppc_change +
    time_democratic +
    total_disasters_prev3_log + 
    resource_rents_pct_gdp +
    xrcomp + parcomp +
    total_igos +
    exec_right +
    exec_left +
    cso_repression +
    presidential_democracy +
    leader_age +
    female +
    total_beas_or_meas_ratified_t1 +
    factor(year) - 1,
  data = dat
)


ols_2b_rat <- lm(
  total_beas_or_meas_ratified ~ 
    term_limit +
    rgdppc_log +
    rgdppc_change +
    time_democratic +
    total_disasters_prev3_log + 
    resource_rents_pct_gdp +
    xrcomp + parcomp +
    total_igos +
    exec_right +
    exec_left +
    cso_repression +
    presidential_democracy +
    leader_age +
    female +
    total_beas_or_meas_ratified_t1 +
    factor(cow_code) +
    factor(year) - 1,
  data = dat
)


rat_models <- list(ols_1a_rat, ols_1b_rat, ols_2a_rat, ols_2b_rat)
rat_rses <- list()

for(i in 1:length(rat_models)){
  
  rat_rses[[i]] <- sqrt(diag(vcovHC(rat_models[[i]], type = "HC1")))
  
}

## Make table

stargazer(
  rat_models,
  se = rat_rses,
  omit = c("factor", "t1"),
  column.labels = rep(c("MEAs", "MEAs", "MEAs + BEAs", "MEAs + BEAs"), 
                      times = 1),
  model.names = TRUE,
  dep.var.labels.include = FALSE,
  covariate.labels = c(
    "Term limit",
    "Real GDP/capita (log)",
    "Change in real GDP/capita (pct.)",
    "Experience with democracy",
    "Disasters in prior 3 years (log)",
    "Resource rents (pct. of GDP)",
    "XRCOMP",
    "PARCOMP",
    "IGO memberships",
    "Executive right",
    "Executive left",
    "CSO repression",
    "Presidential democracy",
    "Leader age",
    "Female"
  ),
  label = "table-appx-rat",
  title = "Term limits and environmental treaty ratification, 1970-2011",
  no.space = TRUE,
  notes.append = TRUE,
  notes.align = "l",
  notes.label = "",
  notes = c(
    "Note: Robust (HC1) standard errors in parentheses.",
    "Country- and year dummies included where indicated but omitted from table output."
  ),
  add.lines = list(
    c("Country dummies?", rep(c("N", "Y"), 4))
  ),
  #float.env = "sidewaystable",
  font.size = "scriptsize",
  out = c("tables/table-appx-rat.tex", 
          "tables/table-appx-rat.html"),
  omit.stat = c("f", "ser", "theta")
)




#--------------------------------------------------------
# Appendix: Estimate main tables on sample without reservations
#--------------------------------------------------------

dat_no_res <- read.csv("analysis-data-no-reservations.csv",
                              stringsAsFactors = FALSE) 

dat_no_res <- left_join(dat_no_res, dat %>%
                    dplyr::select(cow_code, year, presidential_democracy))

dat_no_res$low_income <- ifelse(dat_no_res$wb_income_group == "L", 1, 0)
dat_no_res$lm_income <- ifelse(dat_no_res$wb_income_group == "LM", 1, 0)
dat_no_res$um_income <- ifelse(dat_no_res$wb_income_group == "UM", 1, 0)
dat_no_res$high_income <- ifelse(dat_no_res$wb_income_group == "H", 1, 0)


## Tables 2 and 3 without reservations

no_res_table_2 <- list()
no_res_table_3 <- list()


for(i in 1:length(table_2_models)){
  
  no_res_table_2[[i]] <- update(table_2_models[[i]],
                                data = dat_no_res)
  
}

for(i in 1:length(table_3_models)){
  
  no_res_table_3[[i]] <- update(table_3_models[[i]],
                                data = dat_no_res)
  
}


## Get HCSEs
no_res_ses_table_2 <- list()
no_res_ses_table_3 <- list()

for(i in 1:length(no_res_table_2)){
  
  no_res_ses_table_2[[i]] <- sqrt(diag(vcovHC(no_res_table_2[[i]], type = "HC1")))

}

for(i in 1:length(no_res_table_3)){
  
  no_res_ses_table_3[[i]] <- sqrt(diag(vcovHC(no_res_table_3[[i]], type = "HC1")))
  
}


stargazer(
  no_res_table_2,
  se = no_res_ses_table_2,
  omit = c("factor", "t1"),
  column.labels = rep(c("MEAs", "MEAs", "MEAs + BEAs", "MEAs + BEAs"), 
                      times = 2),
  model.names = TRUE,
  dep.var.labels.include = FALSE,
  covariate.labels = c(
    "Term limit",
    "Real GDP/capita (log)",
    "Change in real GDP/capita (pct.)",
    "Experience with democracy",
    "Disasters in prior 3 years (log)",
    "Resource rents (pct. of GDP)",
    "XRCOMP",
    "PARCOMP",
    "IGO memberships",
    "Executive right",
    "Executive left",
    "CSO repression",
    "Presidential democracy",
    "Leader age",
    "Female"
  ),
  label = "table-2-no-res",
  title = "Models in Table 2 excluding treaties with reservations",
  no.space = TRUE,
  notes.append = TRUE,
  notes.align = "l",
  notes.label = "",
  notes = c(
    "Note: Robust (HC1) standard errors in parentheses.",
    "Country- and year dummies included but omitted from table output."
  ),
  add.lines = list(
    c("Country dummies?", rep(c("N", "Y"), 4))
  ),
  font.size = "tiny",
  out = c("tables/appendix-table-2-no-reservations.tex", 
          "tables/appendix-table-2-no-reservations.html"),
  omit.stat = c("f", "ser", "theta")
)



stargazer(
  no_res_table_3,
  se = no_res_ses_table_3,
  omit = c("factor", "t1"),
  column.labels = rep(c("MEAs", "MEAs + BEAs"), each = 2),
  model.names = TRUE,
  dep.var.labels.include = FALSE,
  covariate.labels = c(
    "Term limit",
    "Real GDP/capita (log)",
    "Change in real GDP/capita (pct.)",
    "Experience with democracy",
    "Disasters in prior 3 years (log)",
    "Resource rents (pct. of GDP)",
    "XRCOMP",
    "PARCOMP",
    "IGO memberships",
    "Executive right",
    "Executive left",
    "CSO repression",
    "Presidential democracy",
    "Leader age",
    "Female",
    "Term limit $\\times$ Real GDP/capita"
  ),
  label = "table-3-no-res",
  title = "Models in Table 3 excluding treaties with reservations",
  no.space = TRUE,
  notes.append = TRUE,
  notes.align = "l",
  notes.label = "",
  notes = c(
    "Note: Robust (HC1) standard errors in parentheses.",
    "Country- and year dummies included but omitted from table output."
  ),
  font.size = "scriptsize",
  out = c("tables/appendix-table-3-no-reservations.tex", 
          "tables/appendix-table-3-no-reservations.html"),
  omit.stat = c("f", "ser", "theta")
)






#--------------------------------------------------------
# Appendix: Conditional effects of competitiveness variables
#--------------------------------------------------------

ols_3b_exec <- update(ols_1b,
                      . ~ term_limit * competitive_exec + .)

ols_4b_exec <- update(ols_2b,
                      . ~ term_limit * competitive_exec + .)

pois_3b_exec <- update(pois_1b,
                       . ~ term_limit * competitive_exec + .)

pois_4b_exec <- update(pois_2b,
                       . ~ term_limit * competitive_exec + .)



ols_3b_par <- update(ols_1b,
                     . ~ term_limit * competitive_par + .)

ols_4b_par <- update(ols_2b,
                     . ~ term_limit * competitive_par + .)

pois_3b_par <- update(pois_1b,
                      . ~ term_limit * competitive_par + .)

pois_4b_par <- update(pois_2b,
                      . ~ term_limit * competitive_par + .)



exec_models <- list(ols_3b_exec, ols_4b_exec, pois_3b_exec, pois_4b_exec)

par_models <- list(ols_3b_par, ols_4b_par, pois_3b_par, pois_4b_par)

exec_holders <- list()
par_holders <- list()


for(i in 1:length(par_models)){
  
  
  exec_holders[[i]] <- rbind(
    mcce_ci_calc("term_limit", "competitive_exec", 0, model = exec_models[[i]],
                 model_vcov = vcovHC(exec_models[[i]], type = "HC1")),
    mcce_ci_calc("term_limit", "competitive_exec", 1, model = exec_models[[i]],
                 model_vcov = vcovHC(exec_models[[i]], type = "HC1"))
    
  ) %>%
    as.data.frame() %>%
    mutate(model = i)
  
  
  par_holders[[i]] <- rbind(
    mcce_ci_calc("term_limit", "competitive_par", 0, model = par_models[[i]],
                 model_vcov = vcovHC(par_models[[i]], type = "HC1")),
    mcce_ci_calc("term_limit", "competitive_par", 1, model = par_models[[i]],
                 model_vcov = vcovHC(par_models[[i]], type = "HC1"))
    
  ) %>%
    as.data.frame() %>%
    mutate(model = i)
  
  
}


par_estimates <- do.call(rbind, par_holders) %>% 
  as.data.frame() %>%
  mutate(`Competitiveness Measure` = "Participation")

exec_estimates <- do.call(rbind, exec_holders) %>% 
  as.data.frame() %>%
  mutate(`Competitiveness Measure` = "Executive Recruitment")

all_estimates <- rbind(par_estimates,
                       exec_estimates) %>%
  mutate(model = recode(model,
                        `1` = "OLS, MEAs",
                        `2` = "OLS, MEAs + BEAs",
                        `3` = "Poisson, MEAs",
                        `4` = "Poisson, MEAs + BEAs"))


ggplot(all_estimates %>% filter(grepl("OLS", model)),
       aes(x = factor(var2.value),
           y = beta,
           ymin = ci.95.lower,
           ymax = ci.95.upper)) +
  facet_grid( ~ model + `Competitiveness Measure`) +
  geom_hline(yintercept = 0, lty = "dotted") +
  geom_point(stat = "identity") +
  geom_errorbar(width = 0) +
  labs(x = "\nValue of competitiveness dummy",
       y = "Estimated coefficient for term limits\n")


ggsave(filename = "figures/appendix-competitiveness-int-ols.jpeg")

ggplot(all_estimates %>% filter(grepl("Poisson", model)),
       aes(x = factor(var2.value),
           y = beta,
           ymin = ci.95.lower,
           ymax = ci.95.upper)) +
  facet_grid( ~ model + `Competitiveness Measure`) +
  geom_hline(yintercept = 0, lty = "dotted") +
  geom_point(stat = "identity") +
  geom_errorbar(width = 0) +
  labs(x = "\nValue of competitiveness dummy",
       y = "Estimated coefficient for term limits\n")

ggsave(filename = "figures/appendix-competitiveness-int-poisson.jpeg")







#----------------------------------------------------------------------------
# Appendix: Main models with sample restricted to Cheibub et al. democracies
#----------------------------------------------------------------------------

## Table 2 Cheibub models

cheibub_models <- list()
cheibub_rses <- list()

for(i in 1:length(table_2_models)){
  
  cheibub_models[[i]] <- update(
    table_2_models[[i]],
    data = dat[dat$cheibub_democracy == 1, ]
  )
  cheibub_rses[[i]] <- sqrt(diag(vcovHC(cheibub_models[[i]], 
                                        type = "HC1")))
  
  
}


## Make Table 2 with Cheibub restriction
stargazer(
  cheibub_models,
  se = cheibub_rses,
  omit = c("factor", "t1"),
  column.labels = rep(c("MEAs", "MEAs", "MEAs + BEAs", "MEAs + BEAs"), 
                      times = 2),
  model.names = TRUE,
  dep.var.labels.include = FALSE,
  covariate.labels = c(
    "Term limit",
    "Real GDP/capita (log)",
    "Change in real GDP/capita (pct.)",
    "Experience with democracy",
    "Disasters in prior 3 years (log)",
    "Resource rents (pct. of GDP)",
    "XRCOMP",
    "PARCOMP",
    "IGO memberships",
    "Executive right",
    "Executive left",
    "CSO repression",
    "Presidential democracy",
    "Leader age",
    "Female"
  ),
  label = "table-2-cheibub",
  title = "Limiting Table 2 sample to list of democracies in Cheibub et al. (2010)",
  no.space = TRUE,
  notes.append = TRUE,
  notes.align = "l",
  notes.label = "",
  notes = c(
    "Note: Robust (HC1) standard errors in parentheses.",
    "Country- and year dummies included but omitted from table output."
  ),
  add.lines = list(
    c("Country dummies?", rep(c("N", "Y"), 4))
  ),
  #float.env = "sidewaystable",
  font.size = "tiny",
  out = c("tables/appendix-table-2-cheibub.tex", 
          "tables/appendix-table-2-cheibub.html"),
  omit.stat = c("f", "ser", "theta")
)



## Table 3 with Cheibub restriction

table_3_models_cheibub <- list()
table_3_rses_cheibub <- list()

for(i in 1:length(table_3_models)){
  
  table_3_models_cheibub[[i]] <- update(
    table_3_models[[i]], data = dat[dat$cheibub_democracy == 1, ]
  )
  
  table_3_rses_cheibub[[i]] <- sqrt(
    diag(vcovHC(table_3_models_cheibub[[i]], type = "HC1"))
  )
  
  
}


## Cheibub table
stargazer(
  table_3_models_cheibub,
  se = table_3_rses_cheibub,
  omit = c("factor", "t1"),
  column.labels = rep(c("MEAs", "MEAs + BEAs"), each = 2),
  model.names = TRUE,
  dep.var.labels.include = FALSE,
  covariate.labels = c(
    "Term limit",
    "Real GDP/capita (log)",
    "Change in real GDP/capita (pct.)",
    "Experience with democracy",
    "Disasters in prior 3 years (log)",
    "Resource rents (pct. of GDP)",
    "XRCOMP",
    "PARCOMP",
    "IGO memberships",
    "Executive right",
    "Executive left",
    "CSO repression",
    "Presidential democracy",
    "Leader age",
    "Female",
    "Term limit $\\times$ Real GDP/capita"
  ),
  label = "table-3-cheibub",
  title = "Limiting Table 2 sample to list of democracies in Cheibub et al. (2010)",
  no.space = TRUE,
  notes.append = TRUE,
  notes.align = "l",
  notes.label = "",
  notes = c(
    "Note: Robust (HC1) standard errors in parentheses.",
    "Country- and year dummies included but omitted from table output."
  ),
  font.size = "scriptsize",
  out = c("tables/appendix-table-3-cheibub.tex", 
          "tables/appendix-table-3-cheibub.html"),
  omit.stat = c("f", "ser", "theta")
)





